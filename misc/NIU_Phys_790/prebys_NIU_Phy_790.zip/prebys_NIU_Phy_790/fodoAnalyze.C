//
// Program to analyze the output of main_ring.g4bl
// Input is the text profile file.
// Requires G4BLProfile.C to be loaded prior to running.
//
#include "G4BLProfile.h"
#include <TNtuple.h>
#include <TFile.h>
#include <TH2F.h>
#include <TCanvas.h>

TCanvas *fodoAnalyze(string filename,double sMax=500000.,double xMax=2.5) {
// Load the track ntuple
  TFile ft("g4beamline.root");
  TNtuple *t = (TNtuple *) ft.FindObjectAny("AllTracks");
  G4BLProfile fp(filename);
  TNtuple *p = fp.getNtuple();
  
TCanvas *c1 = new TCanvas("Individual Tracks");
  
// Draw an empty 2D histogram as a plotting space
  TH2F plot("plot","Track Trajectories",2,0,sMax,2,-xMax,xMax);
  plot.SetStats(kFALSE);
  plot.Draw();
  
// Now superimpose the 3 sigma envelope
  p->Draw("3*sigmaX:Z","","same");
  p->Draw("-3*sigmaX:Z","","Same");
  
// Draw the first four tracks
  t->SetMarkerColor(kRed);
  t->Draw("x:z","EventID==1","same");
  t->SetMarkerColor(kBlue);
  t->Draw("x:z","EventID==2","same");
  t->SetMarkerColor(kGreen);
  t->Draw("x:z","EventID==3","same");
  t->SetMarkerColor(kViolet);
  t->Draw("x:z","EventID==4","same");
  c1->Print("four_tracks.png","png");
  plot.Draw();

  p->Draw("3*sigmaX:Z","","same");
  p->Draw("-3*sigmaX:Z","","Same");

  t->SetMarkerColor(kRed);
  t->Draw("x:z","","same");
  c1->Print("all_tracks.png","png");
  
  TH2F beta("beta","Horizontal (black) and Vertical Beta Functions",2,0.,sMax,2,0.,120000.);
  beta.SetStats(kFALSE);
  
  beta.Draw();
  p->Draw("betaX:Z","","same");
  p->SetMarkerColor(kRed);
  p->Draw("betaY:Z","","same");
  c1->Print("beta_functions.png","png");
  
  return(c1);
}
   