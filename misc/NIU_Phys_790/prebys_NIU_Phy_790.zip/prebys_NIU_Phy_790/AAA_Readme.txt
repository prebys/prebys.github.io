This directory contains all files used for Eric Prebys' guest lecture
for Phy 790 and Northern Illinois, given on March 18 and 20, 2014

Contents:
  prebys_p790_main_20140318.pptx  - main lecture.  Filled first session and
                                    half of second.
  prebys_p790_extra_20140320.pptx - extra material.  Took up second half of second
                                    class
  main_ring.madx                  - MADX file to calculate and plot lattice files
                                    form Main Ring FODO cell.  Invoke with
                                       > madx < main_ring.madx
  main_ring.g4bl                  - g4beamline simulation of the Main Ring FODO.
  G4BLProfile.C(h)                - root utility to read profile text file created by
                                    the above program and import it as an Ntuple
  fodoAnalyze.C                   - root program to analyze the output of main_ring.g4bl
                                    and make the plots that appear in the lecture
  problem_set.tex                 - LaTeX source for problem set
  problem_set.pdf                 - PDF file for problem set.

