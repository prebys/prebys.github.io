
#ifndef OTABLE_DEF_DEFINED
#define OTABLE_DEF_DEFINED

#define MAX_NUM_ESLOT 6
#define GEN_MAX_GRPS 100
#define GEN_MAX_RECS 100
#define FTABLE_MAX_RECS 100
#define GEN_DB_DATA_SIZE RING_SIZE
#define GEN_NAM_LEN 8
#define TIT_LEN 20
#define GEN_DB_DEF_VAL 0
#define SF_SLOT_DEF 1
#define MAX_NUM_SETUPS 6
#define GEN_NAM_LEN 8

#define ELEMENT_NAME   101
#define SETUP    0
#define PLTPAR    1
#define CLIMIT    2
#define DESOB     3
#define SKIP      4
#define MISCPAR   5

#define LATTICE     21

#define BPM_MAX_RECS 100
typedef struct {
  int			date;
  int			tclk;
  int			type;
  float			time;
  int			fid;
  int			lock;
  char			title[TIT_LEN];
 } __attribute__((packed)) /* Added by the PACKINATOR(tm) */ BPM_HDR_STRUCT;
/******************************************************/
/* Expand table structure for maximum multiple frames */
/* October 22, 2001                                   */
/******************************************************/
typedef struct {
  BPM_HDR_STRUCT	hdr;
  byte			stat[2][RING_SIZE];
  float			xy[2][MAX_BREAKPOINTS][RING_SIZE];
 } __attribute__((packed)) /* Added by the PACKINATOR(tm) */ BPM_TABLE_STRUCT;
typedef struct {
  BPM_HDR_STRUCT hdr;
  byte stat[2][RING_SIZE];
  float xy[2][RING_SIZE];
  }  __attribute__((packed)) /* Added by the PACKINATOR(tm) */ BPM_SINGLE_TABLE_STRUCT;
typedef struct {
  BPM_HDR_STRUCT	*rec;
  int			num_recs;
 } __attribute__((packed)) /* Added by the PACKINATOR(tm) */ BPM_DIR_STRUCT;

typedef struct {
  char			name[GEN_NAM_LEN];
  int			tclk;
  int			plane;
  int			slot;
  int			date;
  int			fid;
  int			lock;
  char			title[TIT_LEN];
 } __attribute__((packed)) /* Added by the PACKINATOR(tm) */ GEN_DB_HDR_STRUCT;

typedef struct {
  GEN_DB_HDR_STRUCT	hdr;
  union {
     int		longs[GEN_DB_DATA_SIZE];         /*dataType = 0 */
     short		shorts[GEN_DB_DATA_SIZE];        /*dataType = 1 */
     float		floats[GEN_DB_DATA_SIZE];        /*dataType = 2 */
   } x;
 } __attribute__((packed)) /* Added by the PACKINATOR(tm) */ GEN_DB_STRUCT;

typedef struct {
   GEN_DB_HDR_STRUCT    rec[GEN_MAX_RECS];
   int			num_recs;
 }  __attribute__((packed)) /* Added by the PACKINATOR(tm) */ GEN_DIR_STRUCT;

/* Here are structures for the ftable db */



typedef struct {
  int plane;             /* plane */
  int fid;               /* unique fid for that plane */
  char title[TIT_LEN];   /* title */
  int date;              /* date record was entered */
  int my_lock;
}  __attribute__((packed)) /* Added by the PACKINATOR(tm) */ FTABLE_DB_HDR_STRUCT;

typedef struct {
  float t;
  float v;
}  __attribute__((packed)) /* Added by the PACKINATOR(tm) */ FT_POINT;

typedef struct {
  FTABLE_DB_HDR_STRUCT hdr;
  int firstrec;          /* Flag if it's the first record of a group */
  int period;            /* period in the ring */
  int longshort;         /* whether it's a long or a short */
  int dac_val;           /* present DC value */
  int max_slots;
  float max_time;
  float min_value;
  float max_value;
  char y_label[5];
  FT_POINT ramp[MAX_SLOTS]; /* the time ramp */
}  __attribute__((packed)) /* Added by the PACKINATOR(tm) */ FTABLE_DB_STRUCT;


typedef struct {
  FTABLE_DB_HDR_STRUCT  rec[FTABLE_MAX_RECS];
  int                   num_recs;
}  __attribute__((packed)) /* Added by the PACKINATOR(tm) */ FTABLE_DIR_STRUCT;

extern "C" int gen_hdr_sel(int genid,int tclk,int pl,int slot,GEN_DB_HDR_STRUCT *hdr,
		int *fid,int allow_new);
extern "C" int gen_dir_r(int genid,int tclk,int pl,int slot,int* num_recs,char** dir);
extern "C" int gen_rec_lock(int rw, int genid, int date, int *lock);
extern "C" int gen_hdr_def(int did,int clk,int pl,int slot,int fid,GEN_DB_HDR_STRUCT *h);
extern "C" int gen_rec_r(int did,GEN_DB_HDR_STRUCT *h,void *buf);
extern "C" int gen_rec_w(int did, GEN_DB_STRUCT *buf);
extern "C" int gen_rec_del(int did,GEN_DB_HDR_STRUCT *h);
extern "C" int gen_rec_count(int did,int tclk,int pl,int slot,int fid);
extern "C" int gen_pack_insert(char *chars, char *tnam, GEN_DB_HDR_STRUCT *h);
extern "C" int pack_shorts(char *chars, int nshorts, short *shorts);
extern "C" int pack_longs(char *chars, int nlongs, int *longs);
extern "C" int pack_floats(char *chars, int nfloats, float *floats);

extern "C" int bpm_dir_r(int tclk,int type,int* num_recs,char** dir);
extern "C" int bpm_hdr_sel(int tclk,int type,BPM_HDR_STRUCT *hdr);
extern "C" int bpm_rec_lock(int rw,BPM_HDR_STRUCT* h,int* lock);
extern "C" int bpm_rec_r(BPM_HDR_STRUCT* h,void *buf);
extern "C" int bpm_rec_w(BPM_SINGLE_TABLE_STRUCT *buf);
extern "C" int bpm_rec_del(int max_recs);
extern "C" int desob_w(GEN_DB_STRUCT *des,GEN_DB_STRUCT *ski,int say);
extern "C" int desob_r(int pl,int fid,GEN_DB_STRUCT *des,GEN_DB_STRUCT *ski);

extern "C" void bpm_rec_expand(BPM_SINGLE_TABLE_STRUCT *, BPM_TABLE_STRUCT *);
extern "C" void bpm_rec_compress(BPM_TABLE_STRUCT *,int, BPM_SINGLE_TABLE_STRUCT *);

extern "C" int ftable_dir_r(int ,int *num_recs,FTABLE_DB_HDR_STRUCT **);
extern "C" int ftable_rec_del(FTABLE_DB_HDR_STRUCT *);
extern "C" int ftable_rec_w(FTABLE_DB_STRUCT *);
extern "C" int pack_ftable_rec(char *,FTABLE_DB_STRUCT *);
extern "C" int ftable_hdr_sel(int ,int ,FTABLE_DB_HDR_STRUCT *);
extern "C" int ftable_rec_lock(int , FTABLE_DB_HDR_STRUCT *);
extern "C" int ftable_hdr_init(int ,FTABLE_DB_HDR_STRUCT *);
extern "C" int ftable_write(FTABLE_DB_HDR_STRUCT *,int ,FT_Ramp *ramps,
                 Map_465 *maps[]); 
extern "C" int ftable_read(FTABLE_DB_HDR_STRUCT *,int ,
                 int *,FT_Ramp *ramps,
                 Map_465 *maps[]);
extern "C" int gen_recent_rec_r(int did, GEN_DB_HDR_STRUCT *h, void *buf);




#endif

