/*
  ******************************************************************** 
  ******************************************************************** 
  ****								  **** 
  ****								  **** 
  ****	      Fermilab Accelerator Control Network (ACNET)	  **** 
  ****								  **** 
  ****	      VAX/VMS Console Processor System Application	  **** 
  ****								  **** 
  ****								  **** 
  ******************************************************************** 
  ********************************************************************

 Functional description:
 PA1747

	Primary application to control MR orbit...

 Environment:

	Application started by index page.

 History:

 	V1.0	D. Herrup					27 Jan 1999
		Booster Orbit Correction at 400 MeV

	V0.0	G. Wu / MAD      		                      1-Oct-97
	Created

        found 3 bump alg give unexpected results. The reson about
	skip bits that have not been unpacked again after changed
	in parameter page.						3/30/98


*/

/****************************/
/*** System Include Files ***/
/****************************/


#include "gen.h"
#include "lib465.h"     /* Routines to deal with 465's */
#include "otable.h"
#include "obc.h"
#include "util.h"
#include "bcorrsys.h"   /* information about the whole corrector system */
#include "boosramp.h"   /* Everything associated with the booster ramp */
#include "corr.h"

bcorr_info *corrsys;   /* This will hold pointers to all information */
BOOSTER_RAMP *bramp;   /* This will hold information about the booster ramp */

       




int		bar_level = -1;
int		last_count15hz = 0;

// definitions of extern variables in obc.h
SETUP_STRUCT	setp;
MISC_PAR_STRUCT	miscpar;
PLT_PAR_STRUCT	pltpar;
/* constants must be available for correction and updated when change plane */
GEN_DB_STRUCT		clim;
GEN_DB_STRUCT		deso;
GEN_DB_STRUCT		skip;
GEN_DB_STRUCT		sf;
LATTICE_STRUCT		lat;
int			gdis[RING_SIZE+1];


BPM_DATA_STRUCT 	*bp;
CORR_STRUCT		*cor;



static void mio_ini(void);
static void mio_per(void);
static void top_bar_create(void);
static void obc_init(void);


/******************************************************************************/
/*+ int main(void)
 *
-*/
/******************************************************************************/
int main(void)
{
 short 		inwid, intyp;
 int 		inrow, incol, info;

 while (TRUE)
  {
   window_intype(&inwid,&intyp,&inrow,&incol,&info);
   switch (intyp)
    {
     case INTINI:
      mio_ini();
      break;

     case INTTRM:
      obc_terminate();	
      break;

     case INTKBD:
      mio_kbi(inwid, inrow, incol);
      break;

     case INTPER:
      mio_per();
      break;

     default:
      break;
    }
  }


}				/* end of main program */


/******************************************************************************/
/*+ static void mio_ini(void)
 *
-*/
/******************************************************************************/
static void mio_ini(void)
{
 int	wrow = 30;
 int	wcol = 80;
 short wid = WMNGR_BACKGROUND;
 int 		sts;
 static int dioval[4] = {FALSE, 6, 6, 6};	/* dio_tuner parameters */
 static int fm_val[2] = {FALSE, 5};	/* fm_tuner parameters */

 /* the local log(also called program log) need a FS file created, D112 help
    has instruction how to do it. The point is using 'replicate' to template
    a model file */

 window_set_size_c ( &wid, wrow, wcol );
 error_init_c(PA_MAXROW-5,1,PA_MAXCOL-2,LOG_BOTH,"PA1747LG","HERRUP",4);	
 dio_tuner(&dioval[0],&dioval[1],&dioval[2],&dioval[3]);	
 fm_tuner(&fm_val[0],&fm_val[1]);			
 btvm_c(1,6,"BOOSTER ORBIT CORRECTION",27,GREEN);
 utility_window_init_c(1,70);
 wn_clip_c(TRUE);
 window_enable_interrupts(); /* this is needed for windowscroll */

 sts = script_create();
 if (sts == CBS_OK)
 timmes_c(WMNGR_CENTER_IT,WMNGR_CENTER_IT,
		 "Script creation in progress", GREEN,2);
 error_imbedded_off();           /* suppress bpm error output */
 error_trace_on();		/* turn on error traceback */

 top_bar_create();

 obc_init();

/* stage the main menu - orbit smoothing */
 corre();

 return;
}				/* end of mio_ini */

/*******************************************************************************
*
*mecar:mio_trm - program termination
*
*******************************************************************************/

extern "C" void mio_trm(void)
{
 plt_par_rw(SET);
 misc_par_rw(SET);
 term();
 return;
}				/* end of mio_trm */


/******************************************************************************/
/*+ int mio_kbi(short wid, int row, int col)
 *
-*/
/******************************************************************************/
extern "C" int mio_kbi(short wid, int row, int col)
{
 int		menu_bar_num;
 if (wid == WMNGR_BACKGROUND) {
    menu_bar_num = menu_bar_update();
    if (menu_bar_num > 0) top_bar_exe(menu_bar_num);
    else return(TRUE);
  }
 return(FALSE);
}


/******************************************************************************/
/*+ static void mio_per(void)
 *
-*/
/******************************************************************************/
static void mio_per(void)
{
 return;
}


/******************************************************************************/
/*+ static void top_bar_create(void)
 *
-*/
/******************************************************************************/
static void top_bar_create(void)
{
 int		sts;

 window_blank_c(0, 1, 30, 26);
 menu_bar_delete();

 sts=menu_bar_create(
 " SETUP \\DESIRE-FILE-0(default)\\MISC",
   0,2,WHITE);

 bar_level = 0;
}


/******************************************************************************/
/*+ void top_bar_exe(int item)
 *
-*/
/******************************************************************************/
extern "C" void top_bar_exe(int item)
{
 int 		item1;

 again:
 switch (item)
  {
   case 1:
    setup();
    break;

   case 2:
    edit_desire();
    break;

   case 3:
    misc();
    break;

   default:
    break;
  }

 wmenu_fix(0);
 item1 = menu_bar_update();
 if (item1 > 0 && item1 != item)
  {
   item = item1;
   goto again;
  }

} 


/******************************************************************************/
/*+ float sqr(float in)
 *
-*/
/******************************************************************************/
extern "C" float sqr(float in)
{
 return (in * in);
}


/******************************************************************************/
/*+ int count15hz(int count15hz_req)
 *
-*/
/******************************************************************************/
extern "C" int count15hz(int count15hz_req)
{
 if ((int)(k15hz() - last_count15hz) > count15hz_req)
  {
   last_count15hz = k15hz();
   return(TRUE);
  }
 return(FALSE);
}


/******************************************************************************/
/*+ void wmenu_fix(short win)
	wmenu_fix - fix a problem that after a wmenu called, even there was no
     	interrupts in the wmenu window, the intype informations were altered 
        so a later call the use theses infor, such as 'menu_bar_update' dive 
	wrong info. This routine recover information that lost in wmenu. The 
	window id 'win'has to be passed right.
-*/
/******************************************************************************/
extern "C" void wmenu_fix(short win)
{
 short 		intyp;
 int 		inrow, incol;

 intype_again(&intyp, (short *)&inrow, (short *)&incol);
 window_intype_put_data_c(win, intyp, inrow, incol, CLIB_DEFAULT_ARG);

}


/******************************************************************************/
/*+ static void obc_init(void)
 *
-*/
/******************************************************************************/
static void obc_init(void)

{
 int		cns,cnsslot;
 char		date[21];
 char		mess[80];


 cns = numcns();
 cnsslot = myslot();
 clinks_to_date(clinks_now(), date);
 sprintf(mess,"PA1747 on CNS%d, slot%d start %.20s",cns,cnsslot,date);
 error_message_c(mess,0,YELLOW,TRUE); 

 setp.slot = INVALID;  /* force a reading */
 setup_rw(GET);                                         /* get setup pars */
 if (setp.gtable_num <= 0) setp.gtable_num = 1;
 if (setp.lattice_data_src < 0 || setp.lattice_data_src > 1) 
    setp.lattice_data_src = 1;
 misc_par_rw(GET);                                      /* get misc pars */

 plt_par_rw(GET);                                       /* get plt pars */

/* set plane flags of all constants to negative */

 lat.plane = INVALID;
 lat.tune[HORZ] = lat.tune[VERT] = INVALID;
 gdis[RING_SIZE] = INVALID;
 gen_hdr_def(DESOB,0,setp.plane,0,DESOB_FID_DEF,&deso.hdr);
/* gen_hdr_def(CLIMIT,0,setp.plane,0,0,&clim.hdr);*/
 deso.hdr.plane = INVALID;
 clim.hdr.plane = INVALID;
 sprintf(mess,"DESIRE-FILE-%d(default)",deso.hdr.fid);
 menu_bar_change_entry_c(0,2,mess);

/* set some mem addresses to NULL */
 bp = NULL;
 cor = NULL;

 if (!bp) {
    bp = (BPM_DATA_STRUCT *) malloc(sizeof(BPM_DATA_STRUCT)); 
    if (!bp) util_errpost(MYERR,"malloc bpm data area",NULL);
  }

 bpm_machine_c(BPM_BOOSTER);


   bramp = get_booster_ramp();
   if(bramp==NULL) {
     error_display_c ("Error getting info about the booster ramp ",
                       ERR_ACNET,0);
   }

 return;
}


/******************************************************************************/
/*+ void corr_trm(void)
 *
-*/
/******************************************************************************/
extern "C" void corr_trm(void)
{
 obc_terminate();
}


/******************************************************************************/
/*+ void util_trm(void)
 *
-*/
/******************************************************************************/
extern "C" void util_trm(void)
{
 obc_terminate();
}


/******************************************************************************/
/*+ void misc(void)
 *
-*/
/******************************************************************************/
extern "C" void misc(void)
{
 int			row,col;
 int			icmd;

 static  char	mtxt[][22]= {"Plot options         ",
                                     "Load DAC Reset Values"};
 row = 3; col = 27; cursor(0, &row, &col);
 if (my_wmenu_c(row,col,2,22,(char *)mtxt,"",&icmd)) {
    switch (icmd) {
       case 0:
          pltopt();
          break;
       case 1:
          bcorrsys_get_dacvals(cor->plane);
          break;
       default:
          break;
     }
  }
}


/******************************************************************************/
/*+ void obc_terminate(void)
-*/
/******************************************************************************/
extern "C" void obc_terminate(void)
{
 char			date[21];
 char			mes2[80];

 clinks_to_date(clinks_now(), date);
 sprintf(mes2,"PA1747 terminated %.20s",date);
 error_message_c(mes2,0,YELLOW,TRUE); 
 term();
 return;
}		

