#include "gen.h"
#include "lib465.h"
#include "bcorrsys.h"
#include "otable.h"
#include "obc.h"
#include "util.h"



static  char	gentnam[][15] =  /* 3 gen tables */
                         {"b_db_shorts","b_db_longs","b_db_floats"};
static  char	gendnam[][8] =  /* data(group) titles */
                         {"setup","pltpar","climit","desob","skip",
                          "miscpar"};
                        /* tab id 0 for shorts, 1 for long and 2 for float */
static  int	gentid[] ={1,1,2,2,1,1};
     			/* data size for 3 gen tables */
static  int	gensize[] = {2*RING_SIZE,4*RING_SIZE,4*RING_SIZE};
static  int	genrecs[] ={20,1,1,10,10,1};




/******************************************************************************/
/*+ int gen_rec_lock(int rw, int genid, int date, char *lock)
-*/
/******************************************************************************/
extern "C" int gen_rec_lock(int rw, int genid, int date, int *lock)
{
 int			sts;
 int			dummy;
 unsigned int m,return_row;
 short return_code;
 char			sqlcmd[100];

 if (rw == GET) {      /* read out lock/unlcok flag, 0 is unlocked */
    m = sprintf(sqlcmd,"select my_lock from prebys.%.*s where name='%.*s' and\
 date=%d",strlen(gentnam[gentid[genid]]),gentnam[gentid[genid]],
 strlen(gendnam[genid]),gendnam[genid],date);
    sts = db_send_c(1,sqlcmd,m,sizeof(int),&return_row,(void *)lock,30,0,0,0,
                    &return_code);
    return(util_errpost(sts,"Err read lock flag of gen rec",NULL));
  }
 else {                                         /* write a lock/nulock flag */
    m = sprintf(sqlcmd,"update prebys.%.*s set lock=%d where name='%.*s' and\
 date=%d",strlen(gentnam[gentid[genid]]),gentnam[gentid[genid]],*lock,
 strlen(gendnam[genid]),gendnam[genid],date);
    sts = db_send_c(1,sqlcmd,m,1,&return_row,(void *)&dummy,30,0,0,0,
                    &return_code);
    return(util_errpost(sts,"Err set lock flag of gen rec",NULL));
  }
}


/******************************************************************************/
/*+ int gen_hdr_sel(int genid,int tclk,int pl,int slot,GEN_DB_HDR_STRUCT *hdr,
		    int *fid,int allow_new)
	return num of records got. 
-*/
/******************************************************************************/
extern "C" int gen_hdr_sel(int genid,int tclk,int pl,int slot,GEN_DB_HDR_STRUCT *hdr,
		int *fid,int allow_new)
{
 int			i, m, sts;
 int			status = -1;
 static short		win, hwid;
 short 			inwid, intyp;
 int 			inrow, incol, info;
 int			rows;
 int			firstrow = 3, lastrow = 20;
 int			width = 63;
 char			cbuf[90];
 char			date[21];
 int			lock = FALSE;
 static  char	plnam[][5] = {"horz","vert"};
 static  char	nynam[] = "NY";
 int			num_recs;
 GEN_DB_HDR_STRUCT	*dir;
 GEN_DB_HDR_STRUCT      htemp,*h;

 /* make sure passed clk,pl,slot are right */
 *fid = -1;
 dir = NULL;
 num_recs = 0;
 gen_hdr_def(genid,tclk,pl,slot,0,&htemp);
 sts = gen_dir_r(genid,htemp.tclk,htemp.plane,htemp.slot,&num_recs,
                (char **)&dir);
 if (sts) return (util_errpost(MYERR,"read gen rec dir",NULL));
 rows = num_recs;
 if (allow_new) rows++;
 if (rows < lastrow - firstrow) lastrow = rows + firstrow - 1;
 sprintf(cbuf,"dir of %.*s tables",strlen(gendnam[genid]),gendnam[genid]);
 sts = window_construct_c(3, WMNGR_CENTER, lastrow + 2, 
    			     width + 5, FALSE, BLUE, tv_colors(CYAN,BLACK),
			     cbuf,&win, TRUE, WMNGR_SCROLL_IT,
                             WMNGR_NO_MOVE, WMNGR_RESTORE_BKGND);
 if (sts) goto ret;
 window_enable_scroll_io_c(win);
 window_enable_scroll_status_c(win, WMNGR_DISPLAY_WHEN_NEEDED);
 window_set_scroll_region_c(win, firstrow, lastrow);
 window_tvm_c(win, 1, 2,
  "#  fid         title             date           clk pl sl lock  ", 
  width,CYAN);
 window_hline_c(win, 2, 1, width+1, BLUE);
 window_tvm_c(win, 2, width-11, "*Lock-Unlock", 12, bf[lock]);
 window_tvm_c(win, 2, width-19, "*Return", 7, bf[0]);
 for (i = 0; i < num_recs; i++) {
    h = &dir[i];
    clinks_to_date(h->date, date);
    m = sprintf(cbuf,"%2d %.20s %.20s  %X  %.1s  %1d   %.1s ",h->fid,
              h->title,date,h->tclk,plnam[h->plane],h->slot,&nynam[h->lock]);
/*    m = sprintf(cbuf,"%2d %2d %.20s %.20s  %X  %.1s  %1d   %.1s ",i+1,h->fid,
              h->title,date,h->tclk,plnam[h->plane],h->slot,&nynam[h->lock]);*/
    window_tvm_c(win,firstrow+i,2,cbuf,m,CYAN);
  }
 hilite_create_c(win, firstrow, 2, lastrow-firstrow+1, width-4, 1,
                 &hwid, width-4, 0, 1, HILITE_ROW_MAJOR, TRUE);
 hilite_update_c(hwid);

 while (TRUE) {
    window_intype(&inwid,&intyp,&inrow,&incol,&info);
    if (intyp == INTTRM) goto ret;
    if (intyp == INTKBD) {
       if (inwid != win) goto ret;
       else if (inrow <= 2) {
          if (inrow == 2 && incol >= width-19 && incol < width-12) goto ret;
          else if (inrow == 2 && incol >= width-11 && incol < width-1) {
             lock ? (lock = FALSE) : (lock = TRUE);
             window_tvm_c(win, 2, width-11, "*Lock-Unlock", 12, bf[lock]);
           }
          else goto out;
        }
       else if (incol <= width) {
          i = window_row_to_entry_c(win, inrow);
          if (i < 0 || i >= rows) goto ret;
          h = &dir[i];
          m = window_entry_to_row_c(win, i);
          hilite_suspend_c(hwid,HILITE_ERASE_LAST);
          if (incol == 61) {
             if (lock && i < num_recs) {
                (h->lock == 0) ? (h->lock = 1) : (h->lock = 0);
                gen_rec_lock(SET,genid,h->date,&h->lock);
                gen_rec_lock(GET,genid,h->date,&h->lock);
                if (!sts) window_tvm_c(win,m,width-2,&nynam[h->lock],1,CYAN);
              }
           }
          else {
             if (i < num_recs) {
                memcpy(hdr, h, sizeof(GEN_DB_HDR_STRUCT)); 
                *fid = dir[i].fid;
              }
             else if (i < DESOB_MAX_NUM) {
                *fid = dir[num_recs-1].fid + 1;
              }
             else {
                if (i >= DESOB_MAX_NUM) error_message_c(
                   "Err:file number exceeds maximum",0,RED,TRUE);
                goto ret;
              }
             status = 0;
             goto ret;
           }
          hilite_resume_c(hwid);
        }
     }
    out:;
  }
 ret: del_window(&win);
 free(dir);
 hilite_delete_c(hwid);
 return (num_recs);
}


/******************************************************************************/
/*+ int gen_dir_r(int genid,int tclk,int pl,int slot,int* num_recs,char** dir)
-*/
/******************************************************************************/
extern "C" int gen_dir_r(int genid,int tclk,int pl,int slot,int* num_recs,char** dir)
{
 char 			sqlcmd[160];    
 char			cbuf[140]; 
 int 			n, sts;
 unsigned int m,return_row;
 short return_code;

  /* prepare 'where' clause for uses twice */ 

 if (genid == DESOB || genid == SKIP) {
    n = sprintf(cbuf,"from prebys.%.*s where name='%.*s' and plane=%d", 
                strlen(gentnam[gentid[genid]]),gentnam[gentid[genid]],
                strlen(gendnam[genid]),gendnam[genid],pl);
  }
 else {
    n = sprintf(cbuf,"from prebys.%.*s where name='%.*s' and tclk=%d and plane=%d\
 and slot=%d", strlen(gentnam[gentid[genid]]),gentnam[gentid[genid]],
    strlen(gendnam[genid]),gendnam[genid],tclk,pl,slot);
  }
  /* count records */
 m = sprintf(sqlcmd,"select count(*) %.*s",n,cbuf);
 *num_recs = 0;
 sts = db_send_c(1,sqlcmd,m,sizeof(int),
                 &return_row,(void *)num_recs,30,0,0,0,&return_code);
 if (sts) return(util_errpost(sts,"Err count records in gen_dir_r",NULL));
 if (*num_recs == 0) return(util_errpost(MYERR,"Err in gen_dir_r, no recs",NULL));

  /* now we know size of mem and book it */
 *dir = clib_calloc(*num_recs+1,sizeof(GEN_DB_HDR_STRUCT));
 if (*dir == NULL) return(util_errpost(sts,"Err clib_calloc in gen_dir_r",NULL));

 m = sprintf(sqlcmd,"select name,tclk,plane,slot,date,fid,my_lock,title %.*s",
             n,cbuf);
 sts = db_send_c(*num_recs+2,sqlcmd,m,sizeof(GEN_DB_HDR_STRUCT),
                 &return_row,*dir,30,0,0,0,&return_code);
 if (sts) {
    free(*dir);
    return(util_errpost(sts,"Err read table dir in gen_dir_r",NULL));
  }
 if ((int)return_row != *num_recs) 
    return(util_errpost(sts,"Err record number in gen_dir_r",NULL));
 return(0);
}


/**************************************************************************/
/*+ int gen_rec_r(int did,GEN_DB_HDR_STRUCT *h,void *buf)
	 And so far tclk is 0 for all gen data.
-*/
/**************************************************************************/
extern "C" int gen_rec_r(int did,GEN_DB_HDR_STRUCT *h,void *buf)
{
 int 			n,sts;
 int 			tid,size;
 unsigned int m,return_row;
 short return_code;
 char 			sqlcmd[150];    

 tid = gentid[did];
 size = sizeof(GEN_DB_HDR_STRUCT) + gensize[tid];
 m = sprintf(sqlcmd,"select * from prebys.%.*s where name='%.8s' and tclk=%d and\
 plane=%d and slot=%d and fid=%d",strlen(gentnam[tid]),gentnam[tid],h->name,
 h->tclk,h->plane,h->slot,h->fid);
 if (did==SETUP) {
    n = sprintf(&sqlcmd[m]," and date=%d",h->date);
    m += n;
  }
 sts = db_send_c(1,sqlcmd,m,size,&return_row,(void *)buf,30,0,0,0,&return_code);
 if (sts)return(util_errpost(sts,gentnam[tid]," - err read gen rec"));
 if (return_row != 1)
    return(util_errpost(MYERR,gentnam[tid],"- err read 0 rec"));
 return(sts);
}


/**************************************************************************/
/*+ int gen_rec_count(int genid)
-*/
/**************************************************************************/
extern "C" int gen_rec_count(int did,int tclk,int pl,int slot,int fid)
{
 char 			sqlcmd[160];    
 int 			tid,sts;
 int			num_of_records=0;
 unsigned int m,return_row;
 short return_code;

 tid = gentid[did];
 if (did == DESOB || did == SKIP) {
    m = sprintf(sqlcmd,"select count(*) from prebys.%.*s where name='%.*s' and\
 plane=%d and fid=%d",strlen(gentnam[tid]),gentnam[tid],
 strlen(gendnam[did]),gendnam[did],pl,fid);
  }
 else if (did == CLIMIT) {
    m = sprintf(sqlcmd,"select count(*) from prebys.%.*s where name='%.*s' and\
 plane=%d",strlen(gentnam[tid]),gentnam[tid],strlen(gendnam[did]),
 gendnam[did],pl);
  }
 else {
    m = sprintf(sqlcmd,"select count(*) from prebys.%.*s where name='%.*s' and\
 tclk=%d and plane=%d and slot=%d",strlen(gentnam[tid]),gentnam[tid],
 strlen(gendnam[did]),gendnam[did],tclk,pl,slot);
  }
 sts = db_send_c(1, sqlcmd, m, sizeof(num_of_records),
          &return_row, (void *)&num_of_records, 30, 0, 0, 0, &return_code);
 if (sts) error_message_c("Err count records",0,RED,TRUE);
 return(num_of_records);
}


/**************************************************************************/
/*+ int gen_rec_del(int did,GEN_DB_HDR_STRUCT *h,int circular)
	
	For circular records record fid is not meaningfull - delete all or an 
	oldest record for a given gen table id and for given data name and 
	given tclk,pl and slot to keep the number of records as designed
        Otherwise records are identified by fid and the fid is hept unique.
        Note that the deleting critera is dependent on different data.
-*/
/**************************************************************************/
extern "C" int gen_rec_del(int did,GEN_DB_HDR_STRUCT *h)
{
 char 			sqlcmd[220];    
 char			cbuf[88];
 int 			tid, n, sts, dummy;
 int			max_recs,num_recs_exist = 0;
 unsigned int m,return_row;
 short return_code;

 tid = gentid[did];
 max_recs = genrecs[tid];
 if (did == DESOB || did == SKIP) max_recs = 1;
 num_recs_exist = gen_rec_count(did,h->tclk,h->plane,h->slot,h->fid);
 if (num_recs_exist <= max_recs) return(0);
 if (did == DESOB || did == SKIP) {
    n = sprintf(cbuf,"from prebys.%.*s where name='%.*s' and plane=%d and fid=%d\
    and my_lock=0",strlen(gentnam[tid]),gentnam[tid],strlen(h->name),h->name,
    h->plane,h->fid);
  }
 else if (did == CLIMIT) {
    n = sprintf(cbuf,"from prebys.%.*s where name='%.*s' and plane=%d and my_lock=0",
    strlen(gentnam[tid]),gentnam[tid],strlen(h->name),h->name,h->plane);
  }
 else {
    n = sprintf(cbuf,"from prebys.%.*s where name='%.*s' and tclk=%d and\
    plane=%d and slot=%d and my_lock=0",strlen(gentnam[tid]),gentnam[tid],
    strlen(h->name),h->name,h->tclk,h->plane,h->slot);
  }
 m = sprintf(sqlcmd,"delete %.*s and date=(select MIN(date) %.*s and my_lock=0)",
             n,cbuf,n,cbuf);
 while (num_recs_exist > max_recs) {
    sts = db_send_c(1,sqlcmd,m,1,&return_row,(void *)&dummy,30,0,0,0,
                        &return_code);
    if (sts) return(util_errpost(sts,"Err delete a gen rec, may need unlock",NULL));
    num_recs_exist--;
  }
 return(sts);
}


/**************************************************************************/
/*+ int gen_rec_w(int did,GEN_DB_STRUCT *buf)
	did - data id such as DESOB,etc...
-*/
/**************************************************************************/
extern "C" int gen_rec_w(int did,GEN_DB_STRUCT *buf)
{
 int 			n, sts;
 int 			tid, dummy;
 char 			sqlcmd[2000];
 unsigned int return_row,m;
 short return_code;    


 tid = gentid[did];
 m = gen_pack_insert(sqlcmd,gentnam[tid],&buf->hdr);
 if (tid==0) n = pack_shorts(&sqlcmd[m],GEN_DB_DATA_SIZE,buf->x.shorts);
 else if (tid==1) n = pack_longs(&sqlcmd[m],GEN_DB_DATA_SIZE,buf->x.longs);
 else if (tid==2) n = pack_floats(&sqlcmd[m],GEN_DB_DATA_SIZE,buf->x.floats);
 else return(util_errpost(MYERR,"Err: invalid gentid table",NULL));
 m += n;
 n = sprintf(&sqlcmd[m],")");
 sts = db_send_c(1,sqlcmd,m+n,1,&return_row,(void *)&dummy,30,0,0,0,
                 &return_code);
 return(util_errpost(sts,"- err write a general rec",NULL));
}


/**************************************************************************/
/*+ int gen_pack_insert(char *chars, char *tnam, GEN_DB_HDR_STRUCT *h)
-*/
/**************************************************************************/
extern "C" int gen_pack_insert(char *chars, char *tnam, GEN_DB_HDR_STRUCT *h)
{
 int 			m;
 m = sprintf(chars,"insert into prebys.%.*s values('%.8s',%d,%d,%d,%d,%d,%d,\
 '%.*s'",strlen(tnam),tnam,h->name,h->tclk,h->plane,h->slot,
 h->date,h->fid,h->lock,TIT_LEN,h->title);
 return(m);
}


/**************************************************************************/
/*+ int pack_floats(char *chars, int nfloat, float *floats)
	packing data type float into a string for sql use.
-*/
/**************************************************************************/
extern "C" int pack_floats(char *chars, int nfloats, float *floats)
{
 int		i, n, m = 0;
 for (i = 0; i < nfloats; i++) {
    n = sprintf(&chars[m],",%f",floats[i]);
    m += n;
  }
 return(m);
}


/**************************************************************************/
/*+ int pack_longs(char *chars, int nlong, long *longs)
	packing data type long into a string for sql use.
-*/
/**************************************************************************/
extern "C" int pack_longs(char *chars, int nlongs, int *longs)
{
 int		i, n, m = 0;
 for (i = 0; i < nlongs; i++) {
    n = sprintf(&chars[m],",%d",longs[i]);
    m += n;
  }
 return(m);
}


/**************************************************************************/
/*+ int pack_shorts(char *chars, int nshorts, short *shorts)
	packing data type short into a string for sql use.
-*/
/**************************************************************************/
extern "C" int pack_shorts(char *chars, int nshorts, short *shorts)
{
 int		i, n, m = 0;
 for (i = 0; i < nshorts; i++) {
    n = sprintf(&chars[m],",%d",shorts[i]);
    m += n;
  }
 return(m);
}


/******************************************************************************/
/*+ void gen_hdr_def(int did,int clk,int pl,int slot,int fid,GEN_DB_HDR_STRUCT *h)
-*/                     
/******************************************************************************/
extern "C" int gen_hdr_def(int did,int clk,int pl,int slot,int fid,GEN_DB_HDR_STRUCT *h)
{
 h->tclk = h->plane = h->slot = h->fid = GEN_DB_DEF_VAL;
 if (did == SETUP || did == MISCPAR || did == PLTPAR) { }       /* 0-dim data */ 
 else if (did == DESOB || did == SKIP) {   /* 1-dim data */ 
    h->plane = pl;   
    h->fid = fid;   
  }
 else if (did == CLIMIT) {   /* 1-dim data */ 
    h->plane = pl;   
  }
 else return(util_errpost(MYERR,"Err invalid data, a big bug",NULL));
 memcpy(h->name,gendnam[did],GEN_NAM_LEN);
 return(0);
}



/******************************************************************************/
/*+ int bpm_dir_r(int type,int tclk,int* num_recs,char** data)
        read records' headers for passed data type and tclk. 
	if type=0,tclk=0, get headers for all;
-*/                     
/******************************************************************************/
extern "C" int bpm_dir_r(int tclk,int type,int* num_recs,char** dir)
{
 int			n=0,sts;
 char			cbuf[40]; 
 char			sqlcmd[180]; 
 unsigned int m,return_row;
 short return_code;

  /* prepare 'where' clause for uses twice */ 
 if (tclk && type) n = sprintf(cbuf,"where tclk=%d and type=%d",tclk,type);
 else if (type) n = sprintf(cbuf,"where type=%d",type);
 else if (type) n = sprintf(cbuf,"where tclk=%d",tclk);

  /* count records */
 m = sprintf(sqlcmd,"select count(*) from prebys.b_bpm_data %.*s",n,cbuf);
 *num_recs = 0;
 sts = db_send_c(1, sqlcmd, m, sizeof(int),
           &return_row, (void *)num_recs, 30, 0, 0, 0, &return_code);
 if (sts) return(util_errpost(sts,"Err read table dir in bpm_dir_r",NULL));
 if (*num_recs == 0) return(util_errpost(MYERR,"Err in bpm_dir_r, no recs",NULL));

  /* now we know size of mem and book it */
 *dir = clib_calloc(*num_recs,sizeof(BPM_HDR_STRUCT));
 if (*dir == NULL) return(util_errpost(sts,"Err clib_calloc in bpm_dir_r",NULL));

  /* get headers */
 m = sprintf(sqlcmd,"select date,tclk,type,time,fid,my_lock,title from\
 prebys.b_bpm_data %.*s",n,cbuf);
 sts = db_send_c(*num_recs+2, sqlcmd, m, sizeof(BPM_HDR_STRUCT),
          &return_row, *dir, 30, 0, 0, 0, &return_code);
 if (sts) {
    free(*dir);
    return(util_errpost(sts,"Err read table dir in bpm_dir_r",NULL));
  }
 if ((int)return_row != *num_recs) 
    return(util_errpost(sts,"Err record number in bpm_dir_r",NULL));
 return(0);
}


/******************************************************************************/
/*+ int bpm_hdr_sel(int tclk,int type,BPM_HDR_STRUCT *hdr)
	get all records' headers and then select one. The selected record
	header is returned.
	If lock/unlock switch is turned on, lock status can be flip over
	by click on 'N' or 'Y'.
-*/
/******************************************************************************/
extern "C" int bpm_hdr_sel(int tclk,int type,BPM_HDR_STRUCT *hdr)
{
 int			i, m, sts;
 int			status = MYERR;
 static short		win, hwid;
 short 			inwid, intyp;
 int 			inrow, incol, info;
 int			firstrow = 3, lastrow = 20;
 int			width = 66;
 char			cbuf[80];
 char			date[21];
 int			lock = FALSE;
 static  char	nynam[] = "NY";
 int			num_recs;
 BPM_HDR_STRUCT		*dir;
 BPM_HDR_STRUCT      	*h;

  /* read headers */
 dir = NULL;
 num_recs = 0;
 sts = bpm_dir_r(tclk,type,&num_recs,(char **)&dir);
 if (sts) return (util_errpost(MYERR,"read gen rec dir",NULL));

 if (num_recs < lastrow - firstrow) lastrow = num_recs + firstrow - 1;
 sts = window_construct_c(WMNGR_CENTER, WMNGR_CENTER, lastrow + 2, 
    			     width + 5, FALSE, BLUE, tv_colors(CYAN,BLACK),
			     "BPM data directory",&win, TRUE, WMNGR_SCROLL_IT,
                             WMNGR_NO_MOVE, WMNGR_RESTORE_BKGND);
 if (sts) goto ret;
 window_enable_scroll_io_c(win);
 window_enable_scroll_status_c(win, WMNGR_DISPLAY_WHEN_NEEDED);
 window_set_scroll_region_c(win, firstrow, lastrow);
 window_tvm_c(win,1,2,
 "title               date                tclk  type time fid lock  ",
 width,CYAN);
  /*1234567890123456789012345678901234567890123456789012345678901234567890
  */
 window_hline_c(win, 2, 1, width+1, BLUE);
 window_tvm_c(win, 2, width-11, "*Lock-Unlock", 12, bf[lock]);
 window_tvm_c(win, 2, width-19, "*Return", 7, bf[0]);
 for (i = 0; i < num_recs; i++) {
    h = &dir[i];
    clinks_to_date(h->date, date);
    m = sprintf(cbuf,"%.20s %.20s %X  %d %6.3f %2d %1.1s ",
        h->title,date,h->tclk,h->type,h->time,h->fid,&nynam[h->lock]);
    window_tvm_c(win, firstrow+i, 2, cbuf, m, CYAN);
  }
 hilite_create_c(win, firstrow, 2, lastrow-firstrow+1, width-4, 1,
                 &hwid, width-4, 0, 1, HILITE_ROW_MAJOR, TRUE);
 hilite_update_c(hwid);

 while (TRUE) {
    window_intype(&inwid,&intyp,&inrow,&incol,&info);
    if (intyp == INTTRM) goto ret;
    if (intyp == INTKBD) {
       if (inwid != win)
	 {
	   status = 1;
	   goto ret;
	 }
       else if (inrow <= 2) {
          if (inrow == 2 && incol >= width-19 && incol < width-12) goto ret;
          else if (inrow == 2 && incol >= width-11 && incol < width-1) {
             lock ? (lock = FALSE) : (lock = TRUE);
             window_tvm_c(win, 2, width-11, "*Lock-Unlock", 12, bf[lock]);
           }
          else goto out;
        }
       else if (incol <= width) {
          i = window_row_to_entry_c(win, inrow);
          h = &dir[i];
          m = window_entry_to_row_c(win, i);
          hilite_suspend_c(hwid,HILITE_ERASE_LAST);
          if (incol >= width - 3) {
             if (lock && i < num_recs && incol >= width - 2) {
                (h->lock == 0) ? (h->lock = 1) : (h->lock = 0);
                bpm_rec_lock(SET,h,&h->lock);
                bpm_rec_lock(GET,h,&h->lock);
                if (!sts) window_tvm_c(win,m,width-2,&nynam[h->lock],1,CYAN);
                else window_tvm_c(win, m, width-2, "?", 1, RED);
              }
           }
          else {
             if (i < 0 || i >= num_recs) goto ret;
             memcpy(hdr, h, sizeof(BPM_HDR_STRUCT)); 
             status = 0;
             goto ret;
           }
          hilite_resume_c(hwid);
        }
     }
    out:;
  }
 ret: del_window(&win);
 free(dir);
 hilite_delete_c(hwid);
 return (status);
}


/******************************************************************************/
/*+ int bpm_rec_lock(int rw,BPM_HDR_STRUCT* h,int* lock)
	read lock status when rw=GET; set it when SET. The record is recognized
	by the header info passed.
-*/
/******************************************************************************/
extern "C" int bpm_rec_lock(int rw,BPM_HDR_STRUCT* h,int* lock)
{
 int			sts;
 int			dummy;
 char			sqlcmd[100];
 unsigned int m,return_row;
 short return_code;

 if (rw == GET) {      /* read out lock/unlcok flag, 0 is unlocked */
    m = sprintf(sqlcmd,"select my_lock from prebys.b_bpm_data where tclk=%d and\
 type=%d and time=%f and date=%d",h->tclk,h->type,h->time,h->date);
    sts = db_send_c(1,sqlcmd,m,1,&return_row,(void *)lock,30,0,0,0,
                    &return_code);
    return(util_errpost(sts,"Err read lock flag of bpm rec",NULL));
  }
 else {                                         /* write a lock/nulock flag */
    m = sprintf(sqlcmd,"update prebys.b_bpm_data set lock=%d where tclk=%d and\
 type=%d and time=%f and date=%d",*lock,h->tclk,h->type,h->time,h->date);
    sts = db_send_c(1,sqlcmd,m,1,&return_row,(void *)&dummy,30,0,0,0,
                    &return_code);
    return(util_errpost(sts,"Err set lock flag of gen rec",NULL));
  }
}


/**************************************************************************/
/*+ int bpm_rec_r(BPM_HDR_STRUCT* h,void *buf)
	read a record according to header info passed.
-*/
/**************************************************************************/
extern "C" int bpm_rec_r(BPM_HDR_STRUCT* h,void *buf)
{
 char 			sqlcmd[150];    
 int 			sts;
 unsigned int m,return_row;
 short return_code;

 m = sprintf(sqlcmd,"select * from prebys.b_bpm_data where tclk=%d and\
 type=%d and time=%f and date=%d",h->tclk,h->type,h->time,h->date);
 sts = db_send_c(1,sqlcmd,m,sizeof(BPM_SINGLE_TABLE_STRUCT),&return_row,
                 (void *)buf,30,0,0,0,&return_code);
 if (sts)return(util_errpost(sts,"Err read bpm rec",NULL));
 if (return_row != 1)return(util_errpost(MYERR,"Err read no bpm rec",NULL));
 return(sts);
}


/**************************************************************************/
/*+ int bpm_rec_w(int tbid, GEN_DB_STRUCT *buf)
-*/
/**************************************************************************/
extern "C" int bpm_rec_w(BPM_SINGLE_TABLE_STRUCT *buf)
{
 char 			sqlcmd[3000];    
 int 			n, sts, dummy;
 unsigned int m,return_row;
 short return_code;

 /* delete records if they exceeded a maximum */
 bpm_rec_del(BPM_MAX_RECS);

 m = sprintf(sqlcmd,"insert into prebys.b_bpm_data values(%d,%d,%d,%f,\
 %d,%d,'%.20s'",buf->hdr.date,buf->hdr.tclk,buf->hdr.type,buf->hdr.time,
 buf->hdr.fid,buf->hdr.lock,buf->hdr.title);

  /* pack binary number - status, size of binary field seems less than 432 */
 n = clib_sprintf(&sqlcmd[m],",0x%0208F",CNV_HEX_BIG_ENDIAN,buf->stat[0]);
  /* "%0208F"--> one byte use 2 char, 104*2=216, fill '0' for higher byte*/
 m += n;
 n = clib_sprintf(&sqlcmd[m],",0x%0208F",CNV_HEX_BIG_ENDIAN,buf->stat[1]);
 m += n;
  /* pack float data */
 n = pack_floats(&sqlcmd[m],2*RING_SIZE,(float *)buf->xy);
 m += n;
 n = sprintf(&sqlcmd[m],")");
 sts = db_send_c(1,sqlcmd,m+n,1,&return_row,(void *)&dummy,30,0,0,0,
                 &return_code);
 return(util_errpost(sts,"Err write a bpm rec",NULL));
}


/**************************************************************************/
/*+ int bpm_rec_del(int max_recs)
	delete one or more oldest records after number od rcords is found 
	to be more than max_recs.
-*/
/**************************************************************************/
extern "C" int bpm_rec_del(int max_recs)
{
 char 			sqlcmd[120];    
 int 			sts, dummy;
 int			num_recs = 0;
 unsigned int m,return_row;
 short return_code;

  /* count recs */
 m = sprintf(sqlcmd,"select count(*) from prebys.b_bpm_data");
 sts = db_send_c(1, sqlcmd, m, sizeof(int),
                 &return_row, (void *)&num_recs, 30, 0, 0, 0, &return_code);
 if (sts) return(util_errpost(sts,"Err count bpm recs in bpm_rec_del",NULL));
 if (num_recs < max_recs) return(0);

  /* delete extra records */
 m = sprintf(sqlcmd,"delete from prebys.b_bpm_data and\
 date=(select MIN(date) from prebys.b_bpm_data and my_lock=0)");
 while (num_recs > max_recs-1) {
    sts = db_send_c(1,sqlcmd,m,1,&return_row,(void *)&dummy,30,0,0,0,
                        &return_code);
    if (sts) return(util_errpost(sts,"Err delete a bpm rec",NULL));
    num_recs--;
  }
 return(sts);
}


/**************************************************************************/
/*+ int gen_recent_rec_r(int did, GEN_DB_HDR_STRUCT *h, (void*) buf)
        read a most recent gen record
-*/
/**************************************************************************/
extern "C" int gen_recent_rec_r(int did, GEN_DB_HDR_STRUCT *h, void *buf)
{
 char 			cbuf[150];    
 char 			sqlcmd[250];    
 int 			tid, n, sts;
 unsigned int m,return_row;
 short return_code;

  /* prepare 'where' clause for uses twice */ 
 tid = gentid[did];
 n = sprintf(cbuf,"from prebys.%.*s where name='%.*s' and tclk=%d and plane=%d\
 and slot=%d", strlen(gentnam[tid]),gentnam[tid],strlen(h->name),h->name,
 h->tclk,h->plane,h->slot);

 m = sprintf(sqlcmd,"select * %.*s and date=(select MAX(date) %.*s)",
             n,cbuf,n,cbuf);
 sts = db_send_c(1,sqlcmd,m,sizeof(GEN_DB_HDR_STRUCT)+gensize[tid],
                 &return_row,(void *)buf,30,0,0,0,&return_code);
 if (sts)return(util_errpost(sts,gentnam[tid],"err read gen rec"));
 if (return_row != 1)return(util_errpost(MYERR,gentnam[tid],"err read 0 rec"));
 return(sts);
}




/******************************************************************************/
/*+ int desob_w(GEN_DB_STRUCT *des,GEN_DB_STRUCT *ski,int say)
-*/                     
/******************************************************************************/
extern "C" int desob_w(GEN_DB_STRUCT *des,GEN_DB_STRUCT *ski,int say)
{
 char			date[21];
 static  char	plnam[][5] = {"horz","vert"};
 char			mes[80];

 des->hdr.date = ski->hdr.date = clinks_now();
 des->hdr.lock = 0;
  /* ensure skip hdr is same as desob */
 memcpy(&ski->hdr,&des->hdr,sizeof(GEN_DB_HDR_STRUCT));
 memcpy(ski->hdr.name,gendnam[SKIP],GEN_NAM_LEN);
 if (!gen_rec_w(DESOB,des))
   {
     if (!gen_rec_w(SKIP,ski)) 
     {
       gen_rec_del(DESOB,&des->hdr);
       gen_rec_del(SKIP,&ski->hdr);
       if (say) {
	 clinks_to_date(des->hdr.date,date);
	 sprintf(mes,"%.20s desired/skip for %.4s plane,file %d written",
		 date,plnam[des->hdr.plane],des->hdr.fid);
	 error_message_c(mes,0,GREEN,TRUE); 
       }
       return(0);
     }
}
return(MYERR);
}


/******************************************************************************/
/*+ int desob_r(int pl,int fid,GEN_DB_STRUCT *des,GEN_DB_STRUCT *ski)
	desob and skip always go together. Nowhere else in program should
	refer to the hdr of skip buff.
	plane is used as a flag to decide if need to read flash data.
-*/                     
/******************************************************************************/
extern "C" int desob_r(int pl,int fid,GEN_DB_STRUCT *des,GEN_DB_STRUCT *ski)
{
 GEN_DB_HDR_STRUCT 	hdr;
 if (des->hdr.plane == pl) return(0);
 gen_hdr_def(DESOB,0,pl,0,fid,&hdr);
 memcpy(hdr.name,gendnam[DESOB],GEN_NAM_LEN);
 if (gen_rec_r(DESOB,&hdr,des)) goto err;
 memcpy(hdr.name,gendnam[SKIP],GEN_NAM_LEN);
 if (gen_rec_r(SKIP,&hdr,ski)) goto err;
 skip_bits(SKIP_LOC_BIT,cor->skiploc);  
 skip_bits(SKIP_CED_BIT,cor->skipced);
 skip_bits(SKIP_BPM_BIT,cor->skipbpm);
 return(0);
 err:des->hdr.plane = INVALID;
 return(MYERR);
}


/******************************************************************************/
/*+ int clim_w(GEN_DB_STRUCT *cli,int say)
-*/                     
/******************************************************************************/
/*int clim_w(GEN_DB_STRUCT *cli,int say)
{
 char			date[21];
 static const char	plnam[][4] = {"horz","vert"};
 char			mes[80];

 cli->hdr.date = clinks_now();
 cli->hdr.lock = 0;
 if (!gen_rec_w(CLIMIT,cli)) {
    gen_rec_del(CLIMIT,&cli->hdr);
    if (say) {
       clinks_to_date(cli->hdr.date,date);
       sprintf(mes,"%.20s current limits for %.4s plane written",
            date,plnam[cli->hdr.plane]);
       error_message_c(mes,0,GREEN,TRUE); 
     }
    return(0);
  }
 return(MYERR);
}*/

/******************************************************************************/
/*+ int clim_r(int pl,GEN_DB_STRUCT *cli)
-*/                     
/******************************************************************************/
/*int clim_r(int pl,GEN_DB_STRUCT *cli)
{
 if (cli->hdr.plane == pl) return(0);
 gen_hdr_def(CLIMIT,0,pl,0,0,&cli->hdr);
 cli->hdr.plane = pl;
 memcpy(cli->hdr.name,gendnam[CLIMIT],GEN_NAM_LEN);
 if (gen_rec_r(CLIMIT,&cli->hdr,cli)) goto err;
 return(0);
 err:cli->hdr.plane = INVALID;
 return(MYERR);
}*/

/***********************************************************************/
/* These are stopgap measures to expand or compress a table into       */
/* from or to a single time slice                                      */
/***********************************************************************/
extern "C" void bpm_rec_expand(BPM_SINGLE_TABLE_STRUCT *b1, BPM_TABLE_STRUCT *b2) {
  int i,j;
  memcpy(&b2->hdr,&b1->hdr,sizeof(BPM_HDR_STRUCT));
  memcpy(&b2->stat,&b1->stat,2*RING_SIZE*sizeof(byte));
  for (i=0;i<2;i++) {
    for (j=0;j<MAX_BREAKPOINTS;j++) {
      memcpy(&b2->xy[i][j],&b1->xy[i],RING_SIZE*sizeof(float));
    }
  }
}
extern "C" void bpm_rec_compress(BPM_TABLE_STRUCT *b1, int ibrk, BPM_SINGLE_TABLE_STRUCT *b2) {
  int i;
  memcpy(&b2->hdr,&b1->hdr,sizeof(BPM_HDR_STRUCT));
  memcpy(&b2->stat,&b1->stat,2*RING_SIZE*sizeof(byte));
  for(i=0;i<2;i++) {
    memcpy(&b2->xy[i],&b1->xy[i][ibrk],2*RING_SIZE*sizeof(byte));
  }
}

/******************************************************************************
*+ int ftable_dir_r(int genid,int tclk,int pl,int slot,int* num_recs,char** dir)
* Like gen_dir_r, except that it's for reading table directories, which
* have a separate record for each card
*
******************************************************************************/
extern "C" int ftable_dir_r(int pl,int *num_recs,FTABLE_DB_HDR_STRUCT **dir)
{
 char 			sqlcmd[200];    
 int 			sts;
 unsigned int m,num_recs_ret;
 short return_code;

 *num_recs = 0;
 *dir = NULL;

 m=sprintf(sqlcmd,
  "select count(*) from prebys.b_465_ftable where firstrec=1 and plane=%d", 
     pl);
 sts = db_send_c(1,sqlcmd,m,sizeof(int),
                 NULL,num_recs,30,NULL,0,NULL,&return_code);
 if (sts!=DIO_OK) {
    *num_recs = 0;
    return(util_errpost(sts,"Err getting count in ftable_dir_r",NULL));
 } 
 
   
 
  /* Always create one extra slot for new records */
 (*dir) = (FTABLE_DB_HDR_STRUCT *)
     clib_calloc((*num_recs)+1,sizeof(FTABLE_DB_HDR_STRUCT));

 if((*dir)==NULL) {
    *num_recs = 0;
    return(util_errpost(sts,"Err allocating space in ftable_dir_r",NULL));
 }

 m=sprintf(sqlcmd,
  "select plane,fid,title,date,my_lock from prebys.b_465_ftable where firstrec=1 and plane=%d", 
     pl);
 sts = db_send_c(*num_recs,sqlcmd,m,sizeof(FTABLE_DB_HDR_STRUCT),
                 &num_recs_ret,(*dir),30,NULL,0,NULL,&return_code);
 if (sts) {
    *num_recs = 0;
    return(util_errpost(sts,"Err read table dir in ftable_dir_r",NULL));
  } else if((int)num_recs_ret!=(*num_recs)) {
    return(util_errpost(sts,"Warning record number mismatch in ftable_dir_r",NULL));
  } else {
    return(0);
  }
}
/****************************************************************
* This will delete all records matching a particular set of
* header criteria
*******************************************************************/
extern "C" int ftable_rec_del(FTABLE_DB_HDR_STRUCT *hdr) {
   char sqlcmd[200];
   int sts;
   unsigned int m;
   short return_code;
   m=sprintf(sqlcmd,
  "delete prebys.b_465_ftable where plane=%d and fid=%d",
     hdr->plane,hdr->fid);   
   sts = db_send_c(0,sqlcmd,m,0,
                 NULL,NULL,30,NULL,0,NULL,&return_code);
 if (sts) {
    return(util_errpost(sts,"Err delete record in ftable_rec_del",NULL));
  } else {
    return(0);
  }
}   
/****************************************************************
* This will write a set of FTABLE records to the database
*
******************************************************************/
extern "C" int ftable_rec_w(FTABLE_DB_STRUCT *rec) {
   char sqlcmd[4000];
   int sts;
   unsigned int m;
   short return_code;
   m=pack_ftable_rec(sqlcmd,rec);
   sts = db_send_c(0,sqlcmd,m,0,
                 NULL,NULL,30,NULL,0,NULL,&return_code);
   if (sts!=DIO_OK) return(util_errpost(sts,"Err ftable_rec_w",NULL));
   return(DIO_OK);
}   
/****************************************************************
* Pack an FTABLE fill into a long string (must be a better way to do it) 
***********************************************************************/
extern "C" int pack_ftable_rec(char cmd[],FTABLE_DB_STRUCT *rec) {
   char nextpair[40];
   int i;
   FTABLE_DB_HDR_STRUCT *h;
   
   h = &(rec->hdr);
   sprintf(cmd,
"INSERT into prebys.b_465_ftable VALUES(%d,%d,'%.*s',%d,%d,%d,%d,%d,%d,%d,%f,%f,%f,'%.*s'",
      h->plane,h->fid,TIT_LEN,h->title,h->date,h->my_lock,
      rec->firstrec,
      rec->period,rec->longshort,
      rec->dac_val,rec->max_slots,rec->max_time,
      rec->min_value,rec->max_value,LABEL_TEXT_SIZE,rec->y_label);
   for(i=0;i<MAX_SLOTS;i++) {
     sprintf(nextpair,",%f,%f",rec->ramp[i].t,rec->ramp[i].v);
     strcat(cmd,nextpair);
   }
   strcat(cmd,")");
   return(strlen(cmd));
}
/******************************************************************************/
/*+ int ftable_hdr_sel(int pl,FTABLE_DB_HDR_STRUCT *hdr)
	 
-*/
/******************************************************************************/
extern "C" int ftable_hdr_sel(int pl,int allow_new,FTABLE_DB_HDR_STRUCT *hdr)
{
 int			i, m, sts;
 int			status = -1;
 static short		win, hwid;
 short 			inwid, intyp;
 int 			inrow, incol, info;
 int			rows;
 int			firstrow = 3, lastrow = 20;
 int			width = 50;
 char			cbuf[90];
 char			date[DATIME_LEN+1];
 int			lock = FALSE;
 static  char	*plnam[] = {"horz","vert"};
 static  char	*nynam[] = {"N","Y"};
 int			num_recs;
 FTABLE_DB_HDR_STRUCT	*dir;
 FTABLE_DB_HDR_STRUCT   *h;

 /* make sure passed clk,pl,slot are right */
 dir = NULL;
 num_recs = 0;
 sts = ftable_dir_r(pl,&num_recs,
                (FTABLE_DB_HDR_STRUCT **) &dir);
 if (sts!=DIO_OK) return (util_errpost(MYERR,"read ftable rec dir",NULL));
 rows = num_recs;
 if(allow_new) rows++;  /* Allow new row */
 if (rows < lastrow - firstrow) lastrow = rows + firstrow - 1;
 sprintf(cbuf,"dir of ftables");
 sts = window_construct_c(3, WMNGR_CENTER, lastrow + 2, 
    			     width + 5, FALSE, BLUE, tv_colors(CYAN,BLACK),
			     cbuf,&win, TRUE, WMNGR_SCROLL_IT,
                             WMNGR_NO_MOVE, WMNGR_RESTORE_BKGND);
 if (sts!=DIO_OK) goto ret;
 window_enable_scroll_io_c(win);
 window_enable_scroll_status_c(win, WMNGR_DISPLAY_WHEN_NEEDED);
 window_set_scroll_region_c(win, firstrow, lastrow);
 window_tvm_c(win, 1, 2,
  "plane fid title             date   time lock              ", 
  width,CYAN);
 window_hline_c(win, 2, 1, width+1, BLUE);
 window_tvm_c(win, 2, width-11, "*Lock-Unlock", 12, bf[lock]);
 window_tvm_c(win, 2, width-19, "*Return", 7, bf[0]);
 for (i = 0; i < num_recs; i++) {
    h = &dir[i];
    clinks_to_datime_c(h->date, date);
    m = sprintf(cbuf,"%s %2d %.*s %.*s  %s ",
      plnam[h->plane],h->fid,TIT_LEN,h->title,
         DATIME_LEN,date,nynam[h->my_lock]);
    window_tvm_c(win,firstrow+i,2,cbuf,m,CYAN);
  }
 hilite_create_c(win, firstrow, 2, lastrow-firstrow+1, width-4, 1,
                 &hwid, width-4, 0, 1, HILITE_ROW_MAJOR, TRUE);
 hilite_update_c(hwid);

 while (TRUE) {
    window_intype(&inwid,&intyp,&inrow,&incol,&info);
    if (intyp == INTTRM) goto ret;
    if (intyp == INTKBD) {
       if (inwid != win) goto ret;
       else if (inrow <= 2) {
          if (inrow == 2 && incol >= width-19 && incol < width-12) goto ret;
          else if (inrow == 2 && incol >= width-11 && incol < width-1) {
             lock ? (lock = FALSE) : (lock = TRUE);
             window_tvm_c(win, 2, width-11, "*Lock-Unlock", 12, bf[lock]);
           }
          else goto out;
        }
       else if (incol <= width) {
          i = window_row_to_entry_c(win, inrow);
          if (i < 0 || i >= rows) goto ret;
          h = &dir[i];
          m = window_entry_to_row_c(win, i);
          hilite_suspend_c(hwid,HILITE_ERASE_LAST);
          if (incol == 61) {
             if (lock && i < num_recs) {
                (h->my_lock == 0) ? (h->my_lock = 1) : (h->my_lock = 0);
                ftable_rec_lock(SET,h);
                ftable_rec_lock(GET,h);
                if (!sts) window_tvm_c(win,m,width-2,nynam[h->my_lock],1,CYAN);
              }
           }
          else {
             if (i < num_recs) {
                memcpy(hdr, h, sizeof(FTABLE_DB_HDR_STRUCT)); 
              } else {
                ftable_hdr_init(pl,hdr);
              }
            
             status = 0;
             goto ret;
           }
          hilite_resume_c(hwid);
        }
     }
    out:;
  }
 ret: del_window(&win);
 free(dir);
 hilite_delete_c(hwid);
 return (0);
}
/******************************************************************************/
/*+ int ftable_rec_lock(int rw, FTABLE_DB_HDR_STRUCT *h)
-*/
/******************************************************************************/
extern "C" int ftable_rec_lock(int rw, FTABLE_DB_HDR_STRUCT *h)
{
 int			sts;
 int			dummy;
 char			sqlcmd[100];
 unsigned int m,return_row;
 short return_code;

 if (rw == GET) {      /* read out lock/unlcok flag, 0 is unlocked */
    m = sprintf(sqlcmd,
  "select my_lock from prebys.b_465_ftable where plane=%d and fid=%d",
    h->plane,h->fid);
    sts = db_send_c(1,sqlcmd,m,sizeof(int),&return_row,
       (void *) &h->my_lock,30,0,0,0,&return_code);
    return(util_errpost(sts,"Err read lock flag of ftable rec",NULL));
  }
 else {                                         /* write a lock/nulock flag */
    m = sprintf(sqlcmd,
    "update prebys.b_465_ftable set my_lock=%d where plane=%d and fid=%d",
     h->my_lock,h->plane,h->fid);
     sts = db_send_c(1,sqlcmd,m,1,&return_row,(void *)&dummy,30,0,0,0,
                    &return_code);
     return(util_errpost(sts,"Err set lock flag of ftable rec",NULL));
  }
}
/**********************************************************************
* ftable_hdr_init(FTABLE_DB_HDR_STRUCT *h) - initialize a new ftable
* header
***********************************************************************/
extern "C" int ftable_hdr_init(int plane,FTABLE_DB_HDR_STRUCT *h) {
  char sqlcmd[200];
  int sts,n;
  unsigned int m,return_row;
  short return_code;

  h->plane = plane;
  strcpy(h->title,"");
  h->date = clinks_now();
  h->my_lock = FALSE;
  h->fid = (-1);  /* default (error) value */
  /* Get a unique file ID */
  m=sprintf(sqlcmd,
  "select count(*) from prebys.b_465_ftable where plane=%d",
     plane);
  /* See if there are any records there yet */
  sts=db_send_c(1,sqlcmd,m,sizeof(int),&return_row,(void *) &n, 30,0,0,0,
       &return_code);
  if(sts!=DIO_OK) return(util_errpost(sts,"ERR ftable hdr init",NULL));
  if(n==0) {
    h->fid=1;  /* first record of this type */
  } else {
    m=sprintf(sqlcmd,
      "select max(fid) from prebys.b_465_ftable where plane=%d",
        plane);  
    sts=db_send_c(1,sqlcmd,m,sizeof(int),&return_row,(void *) &n, 30,0,0,0,
       &return_code);
    if(sts!=DIO_OK) return(util_errpost(sts,"ERR ftable hdr init",NULL));
    h->fid = n+1;  /* next in sequence */
  }
  return(0);
}
/***************************************************************/
/* write a set of ramps to the database                        */
/***************************************************************/
extern "C" int ftable_write(FTABLE_DB_HDR_STRUCT *hdr,int ncorr,FT_Ramp ramps[],
                 Map_465 *maps[]) {
   FTABLE_DB_STRUCT rec;
   int sts,ret_sts,i,j;
   
   memcpy(&(rec.hdr),hdr,sizeof(FTABLE_DB_HDR_STRUCT));
   rec.firstrec=TRUE;   /* Flag the first record of the list */
   ret_sts = DIO_OK;
   for(i=0;i<ncorr;i++) {
      if(maps[i]==NULL) continue;
      rec.period = i+1;
      rec.longshort = (hdr->plane==1)? 0:1;
      rec.dac_val = maps[i]->init_dac;
      rec.max_slots = ramps[i].Max_Slots;
      rec.max_time = ramps[i].Max_Time;
      rec.min_value = ramps[i].Min_Value;
      rec.max_value = ramps[i].Max_Value;
      memcpy(rec.y_label,ramps[i].y_label,LABEL_TEXT_SIZE+1);
      for(j=0;j<MAX_SLOTS;j++) {
        rec.ramp[j].t = ramps[i].Time_Value[j][0];
        rec.ramp[j].v = ramps[i].Time_Value[j][1];
      }
      sts = ftable_rec_w(&rec);
      if(sts!=DIO_OK) ret_sts = sts;      
      rec.firstrec = FALSE;  /* This flags the first record of a set */
   }
   if(ret_sts!=DIO_OK) return(util_errpost(ret_sts,"",NULL));
   return(DIO_OK);
}
/***************************************************************/
/* read a set of ramps to the database                        */
/***************************************************************/
extern "C" int ftable_read(FTABLE_DB_HDR_STRUCT *hdr,int maxrecs,
                 int *nrecs,FT_Ramp ramps[],
                 Map_465 *maps[]) {
   FTABLE_DB_STRUCT *recs;
   char sqlcmd[160];
   int i,j,icorr,sts;
   unsigned int m,nuse,nread;
   unsigned int dummy;
   short return_code;
   int checkls;
   int rowsize;
   
   m=sprintf(sqlcmd,
  "select count(*) from prebys.b_465_ftable where plane=%d and fid=%d",
     hdr->plane,hdr->fid);   
   sts = db_send_c(1,sqlcmd,m,sizeof(int),
                 &dummy,nrecs,30,NULL,0,NULL,&return_code);
   if(sts!=DIO_OK) {
      *nrecs = 0;
      return(util_errpost(sts,"Err ftable_read count",NULL));
   }
   nuse = ((*nrecs)<=maxrecs)? (*nrecs):maxrecs;   
   
   recs = (FTABLE_DB_STRUCT *) clib_calloc(nuse,sizeof(FTABLE_DB_STRUCT));
   if(recs==NULL) {
     *nrecs=0;
     return(util_errpost(MYERR,"Err ftable_read calloc",NULL));
   }

   m=sprintf(sqlcmd,
   "select * from prebys.b_465_ftable where plane=%d and fid=%d",
      hdr->plane,hdr->fid);     
   rowsize = sizeof(FTABLE_DB_STRUCT);
   sts = db_send_c(nuse,sqlcmd,m,sizeof(FTABLE_DB_STRUCT),
                 &nread,recs,30,NULL,0,NULL,&return_code);
   if((sts!=DIO_OK)||(nread!=nuse)) {
     free(recs);
     *nrecs = 0;
     if(sts!=DIO_OK) return(util_errpost(sts,"Err ftable_read recs",NULL));
     else return(util_errpost(MYERR,"Err ftable_read count mismatch",NULL));
   }

   /* If here, then all we have to do is unpack it into the records */

   checkls = (hdr->plane==0)? 1:0;  /* sanity check on long short */
   for(i=0;i<(int)nuse;i++) {
      /* sanity checks */
      if(recs[i].period>BOOSTER_MAX_CORRECTORS) {
        error_message_c("Err ftable_read illegal corrector",0,RED,TRUE);
        continue;
      }
      if(recs[i].longshort!=checkls) {
        error_message_c("Err ftable_read illegal long/short flag",0,RED,TRUE);
        continue;
      }
      icorr = (recs[i].period)-1;
      if(maps[icorr]!=NULL) maps[icorr]->init_dac = recs[i].dac_val;
      ramps[icorr].Max_Slots = recs[i].max_slots;
      ramps[icorr].Max_Time = recs[i].max_time;
      ramps[icorr].Min_Value = recs[i].min_value;
      
      memcpy(ramps[icorr].y_label,recs[i].y_label,LABEL_TEXT_SIZE+1);
      for(j=0;j<MAX_SLOTS;j++) {
        ramps[icorr].Time_Value[j][0] = recs[i].ramp[j].t;
        ramps[icorr].Time_Value[j][1] = recs[i].ramp[j].v;
      }
   }
   free(recs);
   return(DIO_OK);
}
