#ifndef __BCORRSYS_H__
#define __BCORRSYS_H__
/****************************************************************
** Some parameters and library routines do deal with the
** Booster corrector system
** 
******************************************************************/
#define BOOSTER_N_PLANES 2
#define BOOSTER_I_HORZ 0
#define BOOSTER_I_VERT 1
#define BOOSTER_PLANE_NAME_LEN 5
#define BOOSTER_MAX_CORRECTORS 24
#define HORZ_REFERENCE_CORRECTOR 9
#define VERT_REFERENCE_CORRECTOR 17

#define ENABLE_STATE_OFF 0
#define ENABLE_STATE_ON 1
#define ENABLE_STATE_MULTIPLE 2
#define ENABLE_STATE_UNDEFINED 3

#ifndef SET
#define SET 1
#endif
#ifndef GET
#define GET 0
#endif
#ifndef MYERR
#define MYERR 1
#endif

typedef struct {
  int n_planes;
  int i_horz;
  int i_vert;
  char plane_names[BOOSTER_N_PLANES][BOOSTER_PLANE_NAME_LEN];
  int num_correctors[BOOSTER_N_PLANES];
  Map_465 *maps[BOOSTER_N_PLANES][BOOSTER_MAX_CORRECTORS];
  int isok[BOOSTER_N_PLANES][BOOSTER_MAX_CORRECTORS];
  int corrector_number[BOOSTER_N_PLANES][BOOSTER_MAX_CORRECTORS];
  int corrector_pointer[BOOSTER_N_PLANES][BOOSTER_MAX_CORRECTORS];
  char corrector_names[BOOSTER_N_PLANES][BOOSTER_MAX_CORRECTORS][DEVICE_NAME_LEN+1];
  int reference_corrector[BOOSTER_N_PLANES];
  int active_corrector[BOOSTER_N_PLANES];
  float ampsperkick[BOOSTER_N_PLANES][BOOSTER_MAX_CORRECTORS];
  float current_limit[BOOSTER_N_PLANES][BOOSTER_MAX_CORRECTORS];
  float dIdt_limit[BOOSTER_N_PLANES][BOOSTER_MAX_CORRECTORS];  
  int active_plane;
  int active_ramp;
  Map_465 *active_map;
}  __attribute__((packed)) /* Added by the PACKINATOR(tm) */ bcorr_info;

/* Define some local functions */
extern "C" int bcorrsys_ini(bcorr_info **);   /* Initialize the whole system.  MUST be the first call */
extern "C" void build_corrector_list(void);  /* Build corrector list */
extern "C" int build_device_name(int, int, char *);  /* build a device name */
extern "C" void fill_corrector_parameters(void); /* fill corrector parameters */
extern "C" int bcorrsys_plane_ramp_state(int,int,int *); /* get or set ramp state */
extern "C" int bcorrsys_get_dacvals(int);    /* get the dac values for this plane */
#endif /* __BCORRSYS_H__ */










