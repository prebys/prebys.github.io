#ifndef __LIB465_H__
#define __LIB465_H__ 1
/*
    Misc. ramp definitions for RFWaves.
*/

/*
    Here are the 12 possible 46x card functions.
*/
#define P_PAGE_FUNCTION	    1
#define FT_TABLE_FUNCTION   2
#define G_TABLE_FUNCTION    3
#define H_TABLE_FUNCTION    4
#define MAP_FUNCTION	    5
#define S_FACTORS_FUNCTION  6
#define VERSION_FUNCTION    7
#define REFERENCE_FUNCTION  8
#define X_VALUES_FUNCTION   9
#define Y_VALUES_FUNCTION   10
#define C_EVENTS_FUNCTION   11
#define MDAT_FUNCTION	    12

#define MAX_FUNCTIONS	    12
/*
    The number of functions defined per family for the Booster 46x cards.
*/
#define NUMBER_FUNCTIONS    MAX_FUNCTIONS

/*
    Various statistics about array sizes for the 46x waveform tables.
*/
#define MAX_SEGMENTS	3
#define MAX_EVENTS	8
#define MAX_INTERRUPTS	32
#define MAX_RAMPS	15
#define MAX_SLOTS	64

/*
    Offsets used in the INFO_ARRAY.
*/
#define	FT_RAMP_END 7
#define CLOCK_INFO  11
#define CARD_INFO   12

#define INFO_ARRAY_SIZE	13
#define LABEL_TEXT_SIZE	4
#define SSDN_ARRAY_SIZE 8

#define NULL_EVENT 0xFE   /* Loaded into empty clock slots */

#define TRIG_STRING_LEN MAX_EVENTS*4+1

#define LIB465_SET  1
#define LIB465_GET  0  

/* This defines the structure for the info associated with a
   465 family
*/
typedef struct {
  int func2dimap[MAX_FUNCTIONS+1]; 
                     /* LEAVE AN EXTRA SPACE TO DEAL WITH NUMBERING */
  int family_di;
  int p_page_di;	    
  int ft_table_di;
  int g_table_di;
  int h_table_di;
  int map_di;
  int s_factors_di;
  int version_di;
  int reference_di;
  int x_values_di;
  int y_values_di;
  int c_events_di;
  int mdat_di;
  unsigned short info[INFO_ARRAY_SIZE];
  int init_dac;  /* This will hold the initial DAC setting */
  int enable;
  PDB_RS ft_scale;
}   __attribute__((packed)) /* Added by the PACKINATOR(tm) */ Map_465;

/* Map table structure */
typedef struct {
   short ramp_map[MAX_INTERRUPTS];
   short f_mult[MAX_INTERRUPTS];
   short g_mult[MAX_INTERRUPTS];
   short h_mult[MAX_INTERRUPTS];
   short f_scale[MAX_INTERRUPTS];
   short g_scale[MAX_INTERRUPTS];
   short h_scale[MAX_INTERRUPTS];
}  __attribute__((packed)) /* Added by the PACKINATOR(tm) */ ramp_map_t;

/*
    Internally defined format for ramps. Used for plotting purposes.
*/
typedef struct
	    {
		int		Max_Slots;
		float		Time_Value[ MAX_SLOTS ][ 2 ];
		float		Max_Time, Min_Value, Max_Value;
		char		y_label[ LABEL_TEXT_SIZE+1 ];
	    }  __attribute__((packed)) /* Added by the PACKINATOR(tm) */ FT_Ramp;


/* Define some routines */
extern "C" int lib465_get_map(int, Map_465 *);
extern "C" int lib465_ft_ramp(int,Map_465 *, int, short [MAX_SLOTS][2], FT_Ramp *);
extern "C" int scale_a_ft_ramp(Map_465 *, short [MAX_SLOTS][2], FT_Ramp *); 
extern "C" int unscale_a_ft_ramp(Map_465 *, short [MAX_SLOTS][2], FT_Ramp *); 
extern "C" int lib465_ramp_enable(Map_465 **, int, int);
extern "C" int lib465_clock_table(int, Map_465 *, short [MAX_INTERRUPTS][MAX_EVENTS]);
extern "C" int lib465_gi_hi_table(int, int, Map_465 *, int, int, short *, float *);
extern "C" int lib465_sf_table(int, Map_465  *, float [MAX_RAMPS]);
extern "C" int lib465_map_table(int, Map_465 *, short *, short *, short *,
                                     short *, short *, short *,
                                     short *, short *, short *h_scale);
extern "C" int lib465_default_maps(Map_465 *);
extern "C" int lib465_mdat(int, Map_465 *, int *, int *);
extern "C" int lib465_decode_trigger_string(char *, short *, int *);
extern "C" int lib465_encode_trigger_string(short *, int , char *);

extern "C" float lib465_dac_val(Map_465 *);

#endif /* __LIB465_H__ */
