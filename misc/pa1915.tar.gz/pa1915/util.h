#ifndef UTIL_DEF_DEFINED
#define UTIL_DEF_DEFINED

/*****************************************************************************/
                                  
/* plot definitions */

#define XPIX 		7.		/* pixels in x direction for lxcatt size 1 */
#define YPIX 		11.		/* pixels in y direction for lxcatt size 1 */
#define	PHYS_XSIZE	639.0
#define	PHYS_YSIZE	511.0
#define	CHX		(XPIX/PHYS_XSIZE)
#define	CHY		(YPIX/PHYS_YSIZE)

#define	WN_MAXROW		46.0		/* Lexidata text window limits */
#define	WN_MAXCOL		91.0

#define	PA_MAXROW		30		/* Lexidata text window limits */
#define	PA_MAXCOL		80




#define blink	0x40




extern char	h_correctors[NUM_CORRECTORS][DEVICE_NAME_LEN + 1];
extern char	v_correctors[RING_SIZE][DEVICE_NAME_LEN + 1];
extern char	h_diff_pos[RING_SIZE][DEVICE_NAME_LEN + 1];
extern char	v_diff_pos[RING_SIZE][DEVICE_NAME_LEN + 1];


extern float	h_ratios[24][3];
extern float	v_ratios[24][3];

   
extern float h_amps_to_mm[24];
extern float v_amps_to_mm[24];

extern int	bf[3];

#define MAX_CYC 1
extern short	cyc_num[MAX_CYC];

extern short		wi3;

#define GET 0
#define SET 1
#define PI 3.1415927

#define DESOB_FID_DEF 0
#define DESOB_MAX_NUM 50



extern "C" char test_bit(int jbit, char w);
extern "C" float calc_dpop(int n, float *x, char *stat, float *disper);
extern "C" float calc_ave(int n, char *stat, float *data);
extern "C" float calc_rms(int n, char *stat, float *data);
extern "C" void plt_limits(int ndat, float *data, float *limits);
extern "C" float maxi(int n, float *data);
extern "C" float mini(int n, float *data);
extern "C" int pro_bpm(int pl,float* dat,char* stat);
extern "C" void pltopt(void);
extern "C" short rounding(float x);
extern "C" void cursor(short wid, int *h, int *w);
extern "C" void del_window(short *wid);
extern "C" void top_bar_exe(int item);
extern "C" void bpm_(void);
extern "C" void wmenu_fix(short win);
extern "C" int model_init(void);
extern "C" int my_wmenu_c(int row, int col, int n_items, int txt_len, char *item_txt,
		char *inp_txt, int *item);
extern "C" int setup(void);
extern "C" int setup_rw(int rw);
extern "C" int misc_par_rw(int rw);
extern "C" int plt_par_rw(int rw);
extern "C" int setup_rw(int rw);
extern "C" int ring_wide_dat(char *title,int pl,char *dat,int dtype,int dlen,
                  int displen,int dgap);
extern "C" void ring_wide_disp(short win,int pl,char *ptr0,int dattyp,int datlen,
                    int row1,int col1,int displen,int gap);
extern "C" int ring_wide_input(short win,int inrow,int incol,int pl,char *ptr0,int dattyp,
                    int datlen,int row1,int col1,int displen,int gap);
extern "C" void ring_wide_cap(short win,int pl,int row1,int col1,int displen,int gap);

extern "C" void table_paint(short win,int row1,int width,int numlen,int displen,int gap,
               int ndat,char *ptr0,int dattyp,int datlen);
extern "C" int table_input(short win,int row1,int width,int numlen,int displen,int gap,
               int ndat,char *ptr0,int dattyp,int datlen,int inrow,int incol);
extern "C" void table_erase(short win,int row1,int rows,int col1,int cols);

extern "C" void disp_bpm_1(int screen,int pl,BPM_HDR_STRUCT* h,float* dat,char* stat);
extern "C" void disp_bpm_2(int screen,BPM_HDR_STRUCT* h,float* x,char* xstat,
                float* y,char* ystat);
extern "C" void disp_bpm_3(int screen,BPM_HDR_STRUCT* h,float* x,char* xstat,
                float* y,char* ystat);
extern "C" void disp_bpm_4(int screen,int pl,int npf,BPM_HDR_STRUCT* h,float* times, 
                float* dat,char* stat);
extern "C" void plt_ring_init1(int pl,int init,int last,int screen, int *pid, int trow, 
                    int rows,char *tit,float *ylimits,char *yunit);
extern "C" void plt_ring_data1(int screen, int id, float *dat, char *stat, 
                   int *color, char *cap1, char *cap2,char *cap3);
extern "C" void plt_ring_corr1(int screen, int id, int plane, float *dat, char *stat, 
                   int *color, char *cap1, char *cap2,char *cap3);
extern "C" void table_ring_data1(int pl,int init, int screen, int trow,int dtyp, 
                      int dlen, void *dat,int displen,char *stat, int *color, 
                      char *tit, char *cap1, char *cap2,char *cap3);
extern "C" void table_ring_corr1(int pl,int init, int screen, int trow,int dtyp, 
                      int dlen, void *dat,int displen,char *stat, int *color, 
                      char *tit, char *cap1, char *cap2,char *cap3);

extern "C" int util_errpost(int sts, char *mess, char *addmess);
extern "C" void disp_corr(int screen,int opt,int plane,float* data);
extern "C" void skip_bits(int jbit,int* bits);
extern "C" int edit_lat(void);
extern "C" int edit_desire(void);
extern "C" int get_booster_correctors ( int plane, float* currents );

extern "C" void disp_g_floats(int screen,GEN_DB_HDR_STRUCT* h,float* dat,char* stat,
	int opt);
extern "C" void plt_xy_init(int, int, int, int*, char *, float *, float *, char *,
                  char *);
extern "C" void plt_xy(int, int, float *, float *, int);
extern "C" void disp_rms_vs_time(int, int, int, float *, float * ,float *);
extern "C" void disp_dev_vs_time(int, int, int, int, float *, float * ,float *);

#endif
