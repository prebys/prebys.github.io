/*
**	Copyright 1997,	Universities Research Association.  All	rights reserved.
**++
**  FACILITY:
**
**	numerical receipee routines (SVD algorithm)
**
**  AUTHORS:
**
**	W. Marsh modification to routines from
**        W. Press, B. Flannery, S. Teukolsky, W. Vetterling,
**	    Numerical Recipes in C, Cambridge Univ. Press, 1988.
**
**
**
**  CREATION DATE:	12-Jun-1997
**
**
**
**  MODIFICATION HISTORY:
**
**
**--
*******************************************************************************/

/*******************************************************************************
*
*	Include Files
*
*******************************************************************************/

#include "cnsparam.h"		/* generic console constants */
#include "cns_data_structs.h"	/* generic console structures */
#include "clib.h"		/* prototypes and defined constants */
#include "cbslib.h"		/* prototypes and defined constants */
#include "diolib.h"		/* DIO prototypes and defined constants */
#include "acnet_errors.h"	/* ACNET error codes */
#include "dbprops.h"


#include <string.h>
#include <math.h>
#include <stdio.h>


#include "nrroutines.h"

/*******************************************************************************
*
*	Local definitions and types
*
*******************************************************************************/

static float	at, bt, ct;
#define PYTHAG(a,b) ((at=fabs(a)) > (bt=fabs(b)) ? \
(ct=bt/at,at*sqrt(1.0+ct*ct)) : (bt ? (ct=at/bt,bt*sqrt(1.0+ct*ct)): 0.0))

static float	maxarg1, maxarg2;
#define MAX(a,b) (maxarg1=(a),maxarg2=(b),(maxarg1) > (maxarg2) ?\
	(maxarg1) : (maxarg2))

#define SIGN(a,b) ((b) >= 0.0 ? fabs(a) : -fabs(a))

/*******************************************************************************
*
*	Module variables
*
*******************************************************************************/

/*******************************************************************************
*
*	Global variables
*
*******************************************************************************/


/*******************************************************************************
*
*	Module internal routines
*
*******************************************************************************/

/******************************************************************************/
/*+ svdcmp
*
*	SVD algorithm - (Singular Value Decomposition)
*
*		reference:  W. Press, B. Flannery, S. Teukolsky, W. Vetterling,
*			    Numerical Recipes in C, Cambridge Univ. Press, 1988.
*		-decomposes the matrix a, dimensioned m by n as shown
*                                             
*		 a[m][n] = u[m][n] * w[n] * ( transpose of )v[n][n]	
*
*		The matrix u is the matrix a on output.  The matrix v is
*		returned, not the transpose of v.		
*
*	note: vector and matrice indices start with 1 
*
*	returns acnet error
-*/
/******************************************************************************/

extern "C" int svdcmp(float **a, int m, int n, float *w, float **v)

{

    int flag,i,its,j,jj,k,l,nm;
    float c,f,h,s,x,y,z;
    float anorm=0.0,g=0.0,scale=0.0;
    float *rv1;


    if (m < n)
	{
	error_message_c(
	  "SVDCMP: You must augment matrix with extra zero rows",0,RED,TRUE);
	return CBS_INVARG;
	}
    rv1=vector(1,n);
    if(rv1 == NULL)return CBS_MEMFAIL;
    for (i = 1; i <= n; i++) {
	l=i+1;
	rv1[i]=scale*g;
	g=s=scale=0.0;
	if (i <= m) {
	    for (k=i;k<=m;k++) scale += fabs(a[k][i]);
	    if (scale != 0.0) {
		for (k=i;k<=m;k++) {
		    a[k][i] /= scale;
		    s += a[k][i]*a[k][i];
		}
		f=a[i][i];
		g = -SIGN(sqrt(s),f);
		h=f*g-s;
		a[i][i]=f-g;
		if (i != n) {
		    for (j=l;j<=n;j++) {
			for (s=0.0,k=i;k<=m;k++) s += a[k][i]*a[k][j];
			f=s/h;
			for (k=i;k<=m;k++) a[k][j] += f*a[k][i];
		    }
		}
		for (k=i;k<=m;k++) a[k][i] *= scale;
	    }
	}
	w[i]=scale*g;
	g=s=scale=0.0;
	if (i <= m && i != n) {
	    for (k=l;k<=n;k++) scale += fabs(a[i][k]);
	    if (scale != 0.0) {
		for (k=l;k<=n;k++) {
		    a[i][k] /= scale;
		    s += a[i][k]*a[i][k];
		}
		f=a[i][l];
		g = -SIGN(sqrt(s),f);
		h=f*g-s;
		a[i][l]=f-g;
		for (k=l;k<=n;k++) rv1[k]=a[i][k]/h;
		if (i != m) {
		    for (j=l;j<=m;j++) {
			for (s=0.0,k=l;k<=n;k++) s += a[j][k]*a[i][k];
			for (k=l;k<=n;k++) a[j][k] += s*rv1[k];
		    }
		}
		for (k=l;k<=n;k++) a[i][k] *= scale;
	    }
	}
	anorm=MAX(anorm,(fabs(w[i])+fabs(rv1[i])));
    }
    for (i=n;i>=1;i--) {
	if (i < n) {
	    if (g != 0.0) {
		for (j=l;j<=n;j++)
		    v[j][i]=(a[i][j]/a[i][l])/g;
		for (j=l;j<=n;j++) {
		    for (s=0.0,k=l;k<=n;k++) s += a[i][k]*v[k][j];
		    for (k=l;k<=n;k++) v[k][j] += s*v[k][i];
		}
	    }
	    for (j=l;j<=n;j++) v[i][j]=v[j][i]=0.0;
	}
	v[i][i]=1.0;
	g=rv1[i];
	l=i;
    }
    for (i=n;i>=1;i--) {
	l=i+1;
	g=w[i];
	if (i < n)
	    for (j=l;j<=n;j++) a[i][j]=0.0;
	if (g != 0.0) {
	    g=1.0/g;
	    if (i != n) {
		for (j=l;j<=n;j++) {
		    for (s=0.0,k=l;k<=m;k++) s += a[k][i]*a[k][j];
		    f=(s/a[i][i])*g;
		    for (k=i;k<=m;k++) a[k][j] += f*a[k][i];
		}
	    }
	    for (j=i;j<=m;j++) a[j][i] *= g;
	} else {
	    for (j=i;j<=m;j++) a[j][i]=0.0;
	}
	a[i][i] += 1.0;
    }
    for (k=n;k>=1;k--) {
	for (its=1;its<=30;its++) {
	    flag=1;
	    for (l=k;l>=1;l--) {
		nm=l-1;
		if (fabs(rv1[l])+anorm == anorm) {
		    flag=0;
		    break;
		}
		if (fabs(w[nm])+anorm == anorm) break;
	    }
	    if (flag) {
		c=0.0;
		s=1.0;
		for (i=l;i<=k;i++) {
		    f=s*rv1[i];
                    rv1[i] = c*rv1[i]; 	/*  ???????????? */
		    if (fabs(f)+anorm != anorm) {
			g=w[i];
			h=PYTHAG(f,g);
			w[i]=h;
			h=1.0/h;
			c=g*h;
			s=(-f*h);
			for (j=1;j<=m;j++) {
			    y=a[j][nm];
			    z=a[j][i];
			    a[j][nm]=y*c+z*s;
			    a[j][i]=z*c-y*s;
			}
		    }
		}
	    }
	    z=w[k];
	    if (l == k) {
		if (z < 0.0) {
		    w[k] = -z;
		    for (j=1;j<=n;j++) v[j][k]=(-v[j][k]);
		}
		break;
	    }
	    if (its == 30)
		{
		error_message_c(
		  "No convergence in 30 SVDCMP iterations",0,RED,TRUE);
		return CBS_REQLIMIT;
		}
	    x=w[l];
	    nm=k-1;
	    y=w[nm];
	    g=rv1[nm];
	    h=rv1[k];
	    f=((y-z)*(y+z)+(g-h)*(g+h))/(2.0*h*y);
	    g=PYTHAG(f,1.0);
	    f=((x-z)*(x+z)+h*((y/(f+SIGN(g,f)))-h))/x;
	    c=s=1.0;
	    for (j=l;j<=nm;j++) {
		i=j+1;
		g=rv1[i];
		y=w[i];
		h=s*g;
		g=c*g;
		z=PYTHAG(f,h);
		rv1[j]=z;
		c=f/z;
		s=h/z;
		f=x*c+g*s;
		g=g*c-x*s;
		h=y*s;
		y=y*c;
		for (jj=1;jj<=n;jj++) {
		    x=v[jj][j];
		    z=v[jj][i];
		    v[jj][j]=x*c+z*s;
		    v[jj][i]=z*c-x*s;
		}
		z=PYTHAG(f,h);
		w[j]=z;
		if (z != 0.0) {
		    z=1.0/z;
		    c=f*z;
		    s=h*z;
		}
		f=(c*g)+(s*y);
		x=(c*y)-(s*g);
		for (jj=1;jj<=m;jj++) {
		    y=a[jj][j];
		    z=a[jj][i];
		    a[jj][j]=y*c+z*s;
		    a[jj][i]=z*c-y*s;
		}
	    }
	    rv1[l]=0.0;
	    rv1[k]=f;
	    w[k]=x;
	}
    }

    free_vector(rv1,1,n);

    return CBS_OK;

}						/* end of SVDCMP */

/******************************************************************************/
/*+ svbksb

*	SVBKSB algorithm - (Singular Value Back Substitution)
*
*		reference:  W. Press, B. Flannery, S. Teukolsky, W. Vetterling,
*			    Numerical Recipes in C, Cambridge Univ. Press, 1988.
*
*		-solves Ax = b for a vector x where A is given by
*                                             
*		 a[m][n] = u[m][n] * w[n] * ( transpose of )v[n][n]	
*
*		in the SVDCMP algorithm.
*	note: vector and matrice indices start with 1 
*
*	returns acnet error
*
-*/
/******************************************************************************/
 
extern "C" int svbksb(float **u, float *w, float **v, int m, int n, 
  float *b, float *x)

{

    int jj,j,i;
    float s;
    float *tmp;



    tmp=vector(1,n);
    if(tmp == NULL)return CBS_MEMFAIL;
    for (j = 1; j <= n; j++) {
	s=0.0;
	if (w[j] != 0.0) {
	    for (i = 1; i <= m; i++) s += u[i][j]*b[i];
	    s /= w[j];
	}
	tmp[j]=s;
    }
    for (j = 1; j <= n; j++) {
	s=0.0;
	for (jj = 1; jj <= n; jj++) s += v[j][jj]*tmp[jj];
	x[j]=s;
    }

    free_vector(tmp,1,n);

    return CBS_OK;

}					/* end of SVBKSB */

/******************************************************************************/
/*+ create_matrix
*
*	Allocate memory for a matrix
*
-*/
/******************************************************************************/

extern "C" float **create_matrix(int nrl, int nrh, int ncl, int nch)

{

    int	i, j;
    float	**data;
    char *ptr;

    data = (float **) clib_malloc((nrh-nrl+1)*sizeof(float *));
					/* allocate pointers to rows */
    if (data == NULL)
	{
	error_message_c(
	  "Memory allocation failure in create_matrix",0,RED,TRUE);
	return (data);
	}

    data -= nrl;

    for (i = nrl; i <= nrh; i++)   /* allocate rows and set pointers to them */
	{
	data[i] = (float *) clib_malloc((nch-ncl+1)*sizeof(float));
	if (data[i] == NULL)
	    {
	    for (j = nrl; j < i; j++)
		{
		ptr = (char *)(data[j]+ncl);
		clib_free(&ptr);
		}
	    ptr = (char *)(data+nrl);
	    clib_free(&ptr);
	    error_message_c(
	      "Memory allocation failure in create_matrix",0,RED,TRUE);
	    return (NULL);
	    }
	data[i] -= ncl;
	}

    return (data);

}		                    /* end of CREATE_MATRIX */

/******************************************************************************/
/*+ free_matrix
*
*	Free memory for a matrix
*
-*/
/******************************************************************************/

extern "C" void free_matrix(float **data, int nrl, int nrh, int ncl, int nch)

{

    int	i;
    char *ptr;

    for (i = nrh; i >= nrl; i--)
	{
	ptr = (char *)(data[i]+ncl);
	clib_free(&ptr);
	}
    ptr = (char *)(data+nrl);
    clib_free(&ptr);


    return;

}		                    /* end of FREE_MATRIX */

/******************************************************************************/
/*+ vector
*
*	Allocate memory for a vector
*
-*/
/******************************************************************************/

extern "C" float *vector(int nl, int nh)

{

    float	*data;

    data = (float *) clib_malloc((unsigned) (nh-nl+1)*sizeof(float));

    if (data == NULL)
	{
	error_message_c("Memory allocation failure in vector",0,RED,TRUE);
	return (data);
	}
    else
	{
	return (data - nl);
	}

}					    /* end of VECTOR */

/******************************************************************************/
/*+ free_vector
*
*	Free memory for a vector
*
-*/
/******************************************************************************/

extern "C" void free_vector(float *data, int nl, int nh)

{
    char *ptr;

    ptr = (char *)(data+nl);
    clib_free(&ptr);

    return;

}					    /* end of FREE_VECTOR */
