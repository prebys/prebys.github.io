/***************************************************************/
/* These are the parameters associated with the BOOSTER ramp   */
/***************************************************************/


typedef struct {
  int num_brkpts;
  float time_breaks[MAX_BREAKPOINTS];
  float turn_breaks[MAX_BREAKPOINTS];
  int use_breaks[MAX_BREAKPOINTS];
  int ipnt[MAX_BREAKPOINTS];  /* Pointer to which breaks are used */
  float t[MAX_BREAKPOINTS];   /* Time at each ramp breakpoint */
  int turn[MAX_BREAKPOINTS];  /* turn number of each breakpoint */
  float p[MAX_BREAKPOINTS];   /* momentum at each ramp breakpoint */
  }  __attribute__((packed)) /* Added by the PACKINATOR(tm) */ BOOSTER_RAMP;
  
BOOSTER_RAMP *get_booster_ramp();
extern "C" float booster_t2p(float);
