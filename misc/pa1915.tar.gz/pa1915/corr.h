#ifndef CORR_DEF_DEFINED
#define CORR_DEF_DEFINED

extern "C" void corre(void);

extern "C" int alg_3bump(int);
extern "C" int alg_svd(int);
extern "C" int alg_lssol(int);

extern "C" void calc_dthet(int* ix, float move, float* dthet);
extern "C" void corr_plt(int step);
extern "C" void corr_disp_par(int wn,int r1,int c1);
extern "C" void calc_po(int pl);
/*void check_corr_limits ( int pl, float* corr );*/

#endif
