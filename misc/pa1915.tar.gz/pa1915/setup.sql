$isql/server=adbs/user="herrup"/pass="bob_dole"
use appdb
go
insert b_db_longs values ( 'setup',0,0,0,0,0,0,'Initial Setup       ', 0,0,0,0,1,0,0,100,0,0, 0,0,0,0,1,0,0,0,0,0, 0,0,0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0)
go
select * from b_db_longs
go
  
