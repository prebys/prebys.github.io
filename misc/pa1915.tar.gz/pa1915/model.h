


extern "C" int get_lattice(int source,int plane,LATTICE_STRUCT *lat);

extern "C" int calc_transfer(int plane, LATTICE_STRUCT *lat);
