$isql/server=adbs/user="prebys"/pass="thatdawg"
use appdb
go
insert prebys.b_db_floats select * from herrup.b_db_floats
insert prebys.b_db_longs select * from herrup.b_db_longs
insert prebys.b_db_shorts select * from herrup.b_db_shorts
insert prebys.b_bpm_data select * from herrup.b_bpm_data
go

