#ifndef BPM_DEF_DEFINED
#define BPM_DEF_DEFINED

#ifdef BPM_
extern "C" void bpm_(void);
extern "C" void bpm_init(void);
extern "C" void bpm_end(void);
#endif
extern "C" int read_bpm_file(BPM_TABLE_STRUCT* b);
extern "C" int bpm_arm(int, int);
extern "C" int read_bpm(int event, int nskip,int frame,int nframe, BPM_TABLE_STRUCT* b);

#endif

