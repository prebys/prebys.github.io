/************************************************************************
 ** Some routines for handling the booster corrector system
 **
 ** October 19, 2001 E.Prebys Original, extracted from test465.c
 ** November 7, 2001 E.Prebys Changed numbering scheme to something
 **                           more sensible
 **
 ***********************************************************************/
#include "cnsparam.h"				/* generic console constants */
#include "cns_data_structs.h"			/* generic console data structures */
#include "dbprops.h"				/* database properties */
#include "clib.h"				/* 'old' CLIB constants and prototypes */
#include "cbslib.h"				/* CBS constants and prototypes */
#include "diolib.h"				/* DIO constants and prototypes */
#include "acnet_errors.h"			/* defined constants for ACNET errors */
#include "tclk_events.h"			/* defined constants for TCLK events */
#include "extchrset.h"				/* definitions for special characters */
#include "argument_defs.h"			/* general defined constants for defaulted argument values */
#include "ul_cbsaux/auxlib.h"			/* UL_CBSAUX library defs */
#include "ul_windowlib/windowlib.h"		/* UL_WINDOWLIB library defs */
#include "gen.h"
#include "lib465.h"
#include "otable.h"
#include "lib465.h"                             /* 465 utility routines */
#include "bcorrsys.h"                           /* stuff specific to this library */
#include "util.h"

static int testmode=0;  /* cause it to only "find" the test module */

/* define some short names for internal use */
#define N_PLANES BOOSTER_N_PLANES
#define I_HORZ BOOSTER_I_HORZ
#define I_VERT BOOSTER_I_VERT
#define PLANE_NAME_LEN BOOSTER_PLANE_NAME_LEN
#define MAX_CORRECTORS BOOSTER_MAX_CORRECTORS

static bcorr_info bcorr;

static char bcorrsys_messbuff[128];  /* generic message buffer */

/****************************************************************/
/* These are static corrector limits and parameters.            */
/****************************************************************/

/* keep the same convention that slot 0 is empty */
/* This is the kick/amp conversion */
static float booster_ampsperkick[N_PLANES][MAX_CORRECTORS] = {
  { 3.600E3,3.600E3,3.600E3,3.600E3,3.600E3,3.600E3,3.600E3,3.600E3,
    3.600E3,3.600E3,3.600E3,3.600E3,3.600E3,3.600E3,3.600E3,3.600E3,
    3.600E3,3.600E3,3.600E3,3.600E3,3.600E3,3.600E3,3.600E3,3.600E3},
  { 6.223E3,6.223E3,6.223E3,6.223E3,6.223E3,6.223E3,6.223E3,6.223E3,
    6.223E3,6.223E3,6.223E3,6.223E3,6.223E3,6.223E3,6.223E3,6.223E3,
    6.223E3,6.223E3,6.223E3,6.223E3,6.223E3,6.223E3,6.223E3,6.223E3}};
/* these are the current limits (Amps) */
static float booster_current_limit[N_PLANES][MAX_CORRECTORS] = {
  {9.99,9.99,9.99,9.99,9.99,9.99,9.99,9.99,9.99,9.99,9.99,9.99,
    9.99,9.99,9.99,9.99,9.99,9.99,9.99,9.99,9.99,9.99,9.99,9.99},
  {9.99,9.99,9.99,9.99,9.99,9.99,9.99,9.99,9.99,9.99,9.99,9.99,
    9.99,9.99,9.99,9.99,9.99,9.99,9.99,9.99,9.99,9.99,9.99,9.99}};
/* these are the dI/dt limits (A/s) */
static float booster_dIdt_limit[N_PLANES][MAX_CORRECTORS] = {
  {650.,650.,650.,650.,650.,650.,650.,650.,650.,650.,650.,650.,
     650.,650.,650.,650.,650.,650.,650.,650.,650.,650.,650.,650.},
  {650.,650.,650.,650.,650.,650.,650.,650.,650.,650.,650.,650.,
     650.,650.,650.,650.,650.,650.,650.,650.,650.,650.,650.,650.}};


/*********************************************************************************
 ** This routine initializes the whole system and returns a table with the info
 ********************************************************************************/
extern "C" int bcorrsys_ini(bcorr_info **b) {
  if(b!=NULL) *b = &bcorr;  /* Could also map directly to the structure */
  /* Fill in some general info */
  bcorr.n_planes = N_PLANES;
  bcorr.i_horz = I_HORZ;
  bcorr.i_vert = I_VERT;
  bcorr.reference_corrector[I_HORZ] = HORZ_REFERENCE_CORRECTOR;
  bcorr.reference_corrector[I_VERT] = VERT_REFERENCE_CORRECTOR;
  bcorr.active_plane = I_HORZ;
  bcorr.active_ramp = 1;
  strcpy(bcorr.plane_names[I_HORZ],"HORZ");
  strcpy(bcorr.plane_names[I_VERT],"VERT");
  build_corrector_list();
  fill_corrector_parameters();
  
  return(0);
}
 
/***************************************************************************************
 * void build_corrector_list()
 *  Build the device names for the rampable correctors which are in the database. Also
 *  read the function maps and info for each corrector. (Note! I probably want to speed
 *  up some of the database calls at some point)
 *
 **************************************************************************************/
extern "C" void build_corrector_list(void) {
  int iplane,icorr;
  int sts;
  int di[MAX_CORRECTORS];
  short index_err[MAX_CORRECTORS];

  error_message_c("Building corrector list");
  for(iplane = 0; iplane<N_PLANES; iplane++) {
    /* Initialize some stuff for the zeroth (reference) entry */
    /* Loop over the correctors.  They will be included in the list if ALL of the following are 
       true:
          (1) The family name is found in the database
          (2) The family name decodes to NUM_FUNCTION individual di's
          (3) The info buffer is correctly read out of the physical device
    */
    bcorr.num_correctors[iplane] = 0;  /* number of "good" correctors */

    for(icorr=0;icorr<MAX_CORRECTORS;icorr++) {
      build_device_name(iplane,icorr,bcorr.corrector_names[iplane][icorr]);
    }
    
    sts = dio_device_index_c((char *)bcorr.corrector_names[iplane],di,
       MAX_CORRECTORS,index_err);       

    
    for(icorr=0;icorr<MAX_CORRECTORS;icorr++) {
      bcorr.maps[iplane][icorr] = NULL;
      bcorr.isok[iplane][icorr] = FALSE;
      if(index_err[icorr]==0) {
        /* See if we can talk to it */
	if(bcorr.maps[iplane][icorr]==NULL) bcorr.maps[iplane][icorr] = (Map_465 *)calloc(1,sizeof(Map_465));
	if(bcorr.maps[iplane][icorr]==NULL) {
	  sprintf(bcorrsys_messbuff,
	    "Could not allocate memory for plane %d, corrector %d",iplane,icorr);
	  error_display_c(bcorrsys_messbuff,ERR_ACNET,-1);
	} else {
	  sts = lib465_get_map(di[icorr],bcorr.maps[iplane][icorr]);

	  if(sts == 0) { /* If here then everything OK */
	    bcorr.isok[iplane][icorr] = TRUE;
            bcorr.corrector_number[iplane][bcorr.num_correctors[iplane]] = 
            	 icorr;
            bcorr.corrector_pointer[iplane][icorr] =
            bcorr.num_correctors[iplane];
	    bcorr.num_correctors[iplane]++;
	  } else {
	    sprintf(bcorrsys_messbuff,
	       "Corrector %s in database but could not map.",
	       bcorr.corrector_names[iplane][icorr]);
	    error_display_c(bcorrsys_messbuff,ERR_ACNET,sts);
	    if(bcorr.maps[iplane][icorr]!=NULL)
            	    cfree(bcorr.maps[iplane][icorr]);
            bcorr.maps[iplane][icorr] = NULL;  /* important!! */
	  }
	}
      }
    }
    if(bcorr.num_correctors[iplane]==0) {
      sprintf(bcorrsys_messbuff,"No valid correctors found for %s plane.",bcorr.plane_names[iplane]);
      error_display_c(bcorrsys_messbuff,ERR_ACNET,sts);
    } else {
      if(bcorr.maps[iplane][bcorr.reference_corrector[iplane]] == NULL) {   /* if reference corrector not valid.  Load a "good" one. */ 
	bcorr.reference_corrector[iplane] = bcorr.corrector_number[iplane][0];
	sprintf(bcorrsys_messbuff,"Reference corrector not found for %s plane. Setting to %s",
		bcorr.plane_names[iplane],
		bcorr.corrector_names[iplane][bcorr.reference_corrector[iplane]]);
      } 
    }
    bcorr.active_corrector[iplane] = bcorr.reference_corrector[iplane];
  }

  sprintf(bcorrsys_messbuff,"Found %d horizontal and %d vertical correctors",bcorr.num_correctors[0],bcorr.num_correctors[1]);
  error_message_c(bcorrsys_messbuff);

  return;
}
/*******************************************************************
 ** Build the device family name for a corrector 
 ******************************************************************/
extern "C" int build_device_name(int iplane, int icorr, char *name) {
  static char plane_code[N_PLANES][3] = {"HS","VL"};
  int i;

  if(testmode) {
    if(icorr==0) {
       strcpy(name,"S:465Z  ");
    } else {
       strcpy(name,"EREWHON ");
    }
    return(0);
  }      

  if((iplane<0)||(iplane>=N_PLANES)||
     (icorr<0)||(icorr>=MAX_CORRECTORS)) return(-1);
 
  sprintf(name,"B:%s%dRZ",plane_code[iplane],icorr+1);
  /* pad with blanks */
  
  name[DEVICE_NAME_LEN]='\0';
  for(i=strlen(name);i<DEVICE_NAME_LEN;i++) name[i]=' ';
 
  
  return (0);
}
/******************************************************************/
/* This fills some parameters about the corrector                 */
/******************************************************************/
extern "C" void fill_corrector_parameters(void) {
   int iplane,icorr;

   for(iplane = 0;iplane<N_PLANES;iplane++) {
     for(icorr = 0; icorr < MAX_CORRECTORS ; icorr++) {
        bcorr.ampsperkick[iplane][icorr] = booster_ampsperkick[iplane][icorr];
        bcorr.current_limit[iplane][icorr] =
                         booster_current_limit[iplane][icorr];
        bcorr.dIdt_limit[iplane][icorr] = booster_dIdt_limit[iplane][icorr];
     }
   }
}
/*******************************************************************/
/* bcorrsys_plane_ramp_state-  get or set the RAMP enable state for*/
/* all the 465's in a plane                                        */
/*******************************************************************/
extern "C" int bcorrsys_plane_ramp_state(int rw,int plane,int *state) {

  int i,ison,dum,sts;
  Map_465 *map;
  if(rw==SET) {
    return(lib465_ramp_enable(bcorr.maps[plane],MAX_CORRECTORS,(*state)));
  } else {
    for(i=0;i<MAX_CORRECTORS;i++) {
      map = bcorr.maps[plane][i];
      if(map==NULL) continue;
      sts=dio_status_c(map->reference_di,&ison,&dum,&dum,&dum);  
      if((sts!=DIO_OK)||((ison!=TRUE)&&(ison!=FALSE))) {
         *state = ENABLE_STATE_UNDEFINED;
         return(MYERR);
      }
      if(i==0) *state=ison;
      else if (ison!=(*state)) {
         *state = ENABLE_STATE_MULTIPLE;
         return(MYERR);
      }
    }
    return(sts);
  }
}
/**************************************************************************/
/* bcorrsys_get_dacvals(int pl) - reload the DAC reset values for a plane    */
/**************************************************************************/
extern "C" int bcorrsys_get_dacvals(int pl) { 
   int sts,retstat,i;
   short err;
   short raw_dac;
   Map_465 *map;
   
   retstat = 0; 
   for(i=0;i<MAX_CORRECTORS;i++) {
     map = bcorr.maps[pl][i];
     if(map==NULL) continue;
  /* Get the initial DAC setting and scale it */
     sts = dio_get_raw_c(map->reference_di,PRSET,&raw_dac,0,sizeof(short));
     if(sts!=DIO_OK) {
        retstat = sts;
        continue;
     }
     map->init_dac = (int)PDUDCU( &raw_dac,&(map->ft_scale),&err);
   }
   return(util_errpost(retstat,"Problems reading 465 DAC values",NULL));
}
     
#ifdef LINUX
/*
 * Values accepeted for scrub issues are ...
 * not-addressed (issue present and not addressed) or
 * addressed (issue present and verified ok or fixed).
 * No key-value string is to be treated as not-addressed.
 * If there is no such issue at all then no string is
 * needed at all.
 */
static char const * const LcppScrubIssues[] __attribute__((unused)) = {
    "$LcppScrubIssues: fp-network-use=addressed $",
    };
#endif
