
#ifndef OBC_DEF_DEFINED
#define OBC_DEF_DEFINED

/*#include "ul_mecarlib:mecarlib.h"*/

#define I2F_FACTOR 100000. 
#define MAX_TABLES 8
#define SKIP_LOC_BIT 0
#define SKIP_CED_BIT 1
#define SKIP_BPM_BIT 2
#define INPUT_BPM_DISPLAY 0
#define INPUT_BPM_FILE 1
#define DES_CENTER 0
#define DES_DES_FILE 1
#define DES_BPM_FILE 2
#define DES_BREAKPT 3



#define ALG_TYPE_3BUMP 0
#define ALG_TYPE_SVD 1
#define ALG_TYPE_LSSOL 2

/* all constants that needed to remember are in int or float group. They
   are read when enter and written down when exit program. When a reading at
   egining is failed writting at exit is not done so to avoid gargabe is
   written */

typedef struct { 
  /* pars that define correction, stored in multi-records */
  int		cycle;
  int		plane;
  int		slot;
  int		if_p_corr;
  int		if_d_orbit;
  int		alg_type;
  int		tolerance;
  int		stepcut;
  int		if_save_g;
  int		bpmsource;
  int		stop_step;
  int		corr_plt_opt;
  int		curr_set_plt_opt;
  int		new_set_plt_opt;
  int		gtable_num;
  int		lattice_data_src;
 }  __attribute__((packed)) /* Added by the PACKINATOR(tm) */ SETUP_STRUCT;
extern SETUP_STRUCT	setp;

typedef struct {
  /* misc pars, not stored */
  int		cns;
  int		cnsslot;
  int		bpmsource;
  int		bpmpfilenum;
  int		bpmdirtclk;
  int		bpmdirtype;
  int		if_use_file_bpm;
  int		if_use_file_g;
  int		corr_plt_opt;
  int		curr_set_plt_opt;
  int		new_set_plt_opt;
  int		po_plt_opt;
 }  __attribute__((packed)) /* Added by the PACKINATOR(tm) */ MISC_PAR_STRUCT;
extern MISC_PAR_STRUCT	miscpar;

typedef struct {
  /* plot option pars, stored in a single file */
  int		gx;
  int		hmaxplts;
  int		vmaxplts;
  int		pile;
  int		bar;
  int		connect;
  int		sym;
  int		symtyp;
  int		symsiz;
  int		symfill;
  int		colors[2];
  int		raweng;
  int		autolim;
  int		glim;
  int		amplim;
  int		mmlim;
 }  __attribute__((packed)) /* Added by the PACKINATOR(tm) */ PLT_PAR_STRUCT;
extern PLT_PAR_STRUCT	pltpar;


/* all correction related and plane specific constants are made available 
   when a specific item is first called for and stay utill end. Their address
   are initialized to NULL at begining and used as a flag of availability */

typedef struct {
  int			plane;
  float			tune[2];    /* tunes for both plane read together */
  float			beta_c[RING_SIZE];
  float			psi_c[RING_SIZE];
  float			disp_c[RING_SIZE];
  float			beta_b[RING_SIZE];
  float			psi_b[RING_SIZE];
  float			disp_b[RING_SIZE];
  float                 A[RING_SIZE][RING_SIZE]; /* The transfer matrix */
 }  __attribute__((packed)) /* Added by the PACKINATOR(tm) */ LATTICE_STRUCT;

/* constants must be available for correction and updated when change plane */

extern GEN_DB_STRUCT		clim;
extern GEN_DB_STRUCT		deso;
extern GEN_DB_STRUCT		skip;
extern GEN_DB_STRUCT		sf;
extern LATTICE_STRUCT		lat;
extern int			gdis[RING_SIZE+1];

/*CDAHadd*/
typedef struct 
 {
  int		valid;
  int		source;
  int		file;
  int		profile;
  int		type;
  char		date[14];
  int		cycle;
  float		time;
  float		energy;
  int		slot;
  float		dpop;
  float		dat[2][MAX_BREAKPOINTS][RING_SIZE];
  char		stat[2][RING_SIZE];
  float		kicks[MAX_BREAKPOINTS][RING_SIZE];
 } __attribute__((packed)) /* Added by the PACKINATOR(tm) */ BPM_DATA_STRUCT;

typedef struct {
  int			flag[10];
  int			desob_fid;
  int			num_brkpts;
  int                   curr_brkpt;  /* The current breakpoint being calculated */
  int                   des_brkpt;   /* only used to lock to one breakpoint */
  int                   max_pass;    /* maximum passes in iterative algorithm */
  int                   ramp_num; 
  int                   orbit_drift_mode; /* what to do with orbit drift */
  float                 trim_headroom;  /* distance from hard limits to allow
                                           tuning */
  int                   nevents; 
  short                 events[8];
  float			brk_t[MAX_BREAKPOINTS];
  float			brk_p[MAX_BREAKPOINTS];
  int 			gtablenum;
     /* set INVALID at initialization or if ced or bpm or lattice changed, so
	a setup can be triggered when do SVD */ 
  int			plane;
  float			stepcut;
  int			plane_svd_setup_flag[2];  
  int			skiploc[RING_SIZE+1];
  int			skipced[RING_SIZE+1];
  int			skipbpm[RING_SIZE+1];
  int			useced[RING_SIZE];
  int			usebpm[RING_SIZE];
  float			sfactors[RING_SIZE+1]; /* s.f, last element is pl flg*/
  BPM_TABLE_STRUCT	b1;                  /* current orbit */
  GEN_DB_STRUCT		g1;                  /* current g settings */
  float			g2[MAX_BREAKPOINTS][RING_SIZE];
  float			dx1[MAX_BREAKPOINTS][RING_SIZE];      /* desired move */
  float			dthet[MAX_BREAKPOINTS][RING_SIZE];    /* calced angles by dx1 */
  float			dx2[MAX_BREAKPOINTS][RING_SIZE];      /* calcd move by dthet */
  float			b2[MAX_BREAKPOINTS][RING_SIZE];      /* calcd move by dthet */
  float			b0_rms[MAX_BREAKPOINTS];
  float			b1_rms[MAX_BREAKPOINTS];
  float			b1_dpop[MAX_BREAKPOINTS];
  float			b2_rms[MAX_BREAKPOINTS];
  float			dthet_ave[MAX_BREAKPOINTS];
  float			g1_ave[MAX_BREAKPOINTS];
  float			g2_ave[MAX_BREAKPOINTS];
  char			bstat[RING_SIZE];
  char			gstat[RING_SIZE];
 }  __attribute__((packed)) /* Added by the PACKINATOR(tm) */ CORR_STRUCT;

extern BPM_DATA_STRUCT 	*bp;
extern CORR_STRUCT		*cor;

#define ORBIT_DRIFT_LOCK 0      /* Lock to the measured drift at BEX, ROF */
#define ORBIT_DRIFT_PREDICT 1   /* Try to predict and allow for orbit drift */
#define ORBIT_DRIFT_SUPRESS 2   /* Try to "zero-out" orbit drift */ 

extern "C" int mio_kbi(short wid, int row, int col);
extern "C" void mio_trm(void);
extern "C" void corr_trm(void);
extern "C" void util_trm(void);
extern "C" void misc(void);
/*void bpmdiropt(void);
void corropt(void);*/
extern "C" void obc_terminate(void);

#endif

