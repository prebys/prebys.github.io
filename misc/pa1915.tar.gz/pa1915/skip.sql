$isql/server=adbs/user="herrup"/pass="bob_dole"
use appdb
go
insert b_db_longs values ( 'skip',0,0,0,0,0,0,'12345678901234567890', 0,0,0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0)
go
select * from b_db_longs
go
  
