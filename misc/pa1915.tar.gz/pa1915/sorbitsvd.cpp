/*
**	Copyright 1997,	Universities Research Association.  All	rights reserved.
**++
**  FACILITY:
**
**	smooth orbit least squares algorithm using SVD algorithm
**
**  AUTHORS:
**
**	W. Marsh
**
**
**  CREATION DATE:	18-Apr-1997
**
**
**
**  MODIFICATION HISTORY:
**
**
**--
*******************************************************************************/

/*******************************************************************************
*
*	Include Files
*
*******************************************************************************/

#include "gen.h"		/* generic console constants */
#include "sorbitsvd.h"
#include "nrroutines.h"

/*******************************************************************************
*
*	Local definitions and types
*
*******************************************************************************/
#define	SVD_THRESHOLD	1.0e-6


/*******************************************************************************
*
*	Module variables
*
*******************************************************************************/

/*******************************************************************************
*
*	Global variables
*
*******************************************************************************/

static int ncorrectorss[2] = {0,0};	/* save of number of correctors for
						horz vert */
static int npositionss[2] = {0,0};	/* save of number of positions for
						horz vert */
static int npositionsse[2] = {0,0};	/* save of number of expanded positions
						for horz vert (positions
						 are expanded with zeros if
						 ncorrectors > npositions */

static float **tmatrixs[2] = {NULL, NULL};
					/* save of pointers to the corrector
					    theta to position transfer 
						matrix for horz vert */
static float **vmatrixs[2] = {NULL,NULL};
					/* save of the pointers to the
						SVD v matrix for horz vert */
static float **umatrixs[2] = {NULL,NULL};
					/* save of the pointers to the
						SVD u matrix for horz vert */
static float *wvectors[2] = {NULL, NULL};
					/* save of the pointers to the 
						SVD w matrix diagonal vector
						for horz vert */

static char sorbit_messbuff[128];

/*******************************************************************************
*
*	Module internal routines
*
*******************************************************************************/

/******************************************************************************/
/*+ sorbit_ls_svd__setup
*	sets up the SVD (singular value decomposition) matrices and the
*	  transfer matrix (internally kept in the module) for smoothing
*	   the orbit via the least squares method so that
*	  sorbit_ls_svd_compute can be called to compute
*	  the new corrector delta angles and the new predicted orbit positions
*	note that if one changes the number of correctors or the number
*	  of positions or the lattice then one must recall this routine
*	  However, if one just has new positions then one can just
*	  call the compute function
*
*	plane			whether horz or vertical 
*				  (SORBITSVD_HORZ, SORBITSVD_VERT)
*				  (this is needed so that both the horz, vert
*				   matrices can be stored for later calculation)
*	ncorrectors		number of correctors
*	npositions		number of positions
*	singularity_threshold	singularity threshold in units of the fraction
*				  of the maximum element of the diagonal
*				  SVD W matrix vector.  Elements of the
*				  diagonal W matrix vector below this will
*				  be set to 0.  This according to SVD theory
*				  will give a better answer.  See the
*				  Numerical Recpipes book.  If this value
*				  is negative then a default value of
*				  1.0e-6 is taken.
*	betacorrectors		beta function ( in meters) at the correctors
*				 this is an array ncorrectors long
*	betapositions		beta function ( in meters) at the positions
*				 this is an array npositions long
*	phasecorrectors		beta phase (in radians) at the correctors
*				 this is an array ncorrectors long
*	phasepositions		beta phase (in radians) at the positions
*				 this is an array npositions long
*	tune			the tune
*	genericerror		a pointer to an integer to receive an
*				  error code if the function returns
*				  CBS_GENERR---this may be null if one
*				  does not care.  Note that if the solution
*				  has singulariites then CBS_GENERR will
*				  be returned.  In particular the types
*				  of generic errors returned are
*				    SORBITSVD_ERROR_UNDETERMINED for the
*				  	case where there are more correctors
*					than positions (the internal matrixes
*					are zero filled so that one gets
*					the SVD singularity solutions)
*				    SORBITSVD_ERROR_SINGULARITY for the case
*					where there are explicit singularities
*					in the solution.
*				  In both of these case the "best" SVD 
*				   solution is returned.
*	numsingular		a pointer to an integer to receive the
*				  number of singular w matrix elements
*				  (either calculated to be zero or set
*				   to zero by the singularity_threshold)
*				  This may be NULL if one does not care
*	singularindex		a pointer to an array of integers to receive
*				  the indices of the singular elements
*			          (could be ncorrectors long if w is
*				   completly zero)  note that both the
*				   the array index and the indexes returned
*				   follow the c standard starting with index
*				   0.
*				  This may be NULL if one does not care
*
* returns acnet error
*
*	input output arrays start at index 0;
*	all internal arrays,matrices start at index 1
*
*
*	the svd algorithm solves the matrix equation
*
*		A*x = b  (actually we minimize |A*x-b|)
*
*		where A is a the closed orbit transfer matrix of size
*			m x n where m = number of bpms and 
*			n = number of correctors.
*		where x is the n vector delta corrector values (changes
*			of angle)
*		where b is the m vector bpm values
*
*	the svd algorithm decomposes A into
*	  A = (U)*(W)*(Vtranspose)
*		where U is an m x n column orthogonal matrix
*		W is a n x n diagonal matrix whose diagonal elements w(j) >= 0
*		V is a n x n othogonal matrix
*
*	   x is solved for by the equation
*
*	  x = (V)*(W')*(Utranspose)b
*		where W' is a n x n diagonal matrix where the diagonal elements
*		 w'(j) = 1/w(j) when w(j) != 0 
*		  and w'(j) = 0 when w(j) == 0 (or very small)	
*	
-*/
/******************************************************************************/
extern "C" int sorbit_ls_svd_setup(int plane, int ncorrectors, int npositions,
  float singularity_threshold, float *betacorrectors, float *betapositions,
  float *phasecorrectors, float *phasepositions, float tune,
  int *genericerror, int *numsingular, int *singularindex)


    {

    int returncode;
    int genericerrorl;
    float sthreshold;
    int sts;
    float wmax,wthreshold;
    int ii;
    int nsingular;
    float sinfactor;

    int ncorrectorsl;
    int npositionsl;

    float **u;
    float **v;
    float **t;
    float *w;


    int row,col;

    void uvwprint(int npos, int ncor, float **u, float **v, float *w);




/*
	defaults
*/
    
    returncode = CBS_OK;
    genericerrorl = 0;		/* no error */
    if(singularity_threshold < 0.)
	{
	sthreshold = SVD_THRESHOLD;
	}
    else
	{
	sthreshold = singularity_threshold;
	}


/*
	make sure plane number is ok
*/
    if(plane != SORBITSVD_HORZ && plane != SORBITSVD_VERT)return CBS_INVARG;
/*
	deallocate previous matrices
*/
    sorbit_ls_svd_release(plane);
/*
	allocate matrices
*/
    ncorrectorss[plane] = ncorrectors;
    npositionss[plane] = npositions;
    npositionsse[plane] = npositions;
    if(npositions < ncorrectors)
	{
			/* underdetermined case---will zero fill to get
				a solution */
	npositionsse[plane] = ncorrectors;
	returncode = CBS_GENERR;
	genericerrorl = SORBITSVD_ERROR_UNDETERMINED;    
	}
    ncorrectorsl = ncorrectorss[plane];
    npositionsl = npositionsse[plane];
    tmatrixs[plane] = create_matrix(1,npositionsse[plane],
      1,ncorrectorss[plane]);
    if(tmatrixs[plane] == NULL)
	{
	sorbit_ls_svd_release(plane);
	return CBS_MEMFAIL;
	}
    umatrixs[plane] = create_matrix(1,npositionsse[plane],
      1,ncorrectorss[plane]);
    if(umatrixs[plane] == NULL)
	{
	sorbit_ls_svd_release(plane);
	return CBS_MEMFAIL;
	}
    vmatrixs[plane] = create_matrix(1,ncorrectorss[plane],
      1,ncorrectorss[plane]);
    if(vmatrixs[plane] == NULL)
	{
	sorbit_ls_svd_release(plane);
	return CBS_MEMFAIL;
	}
    wvectors[plane] = vector( 1,ncorrectorss[plane]);
    if(wvectors[plane] == NULL)
	{
	sorbit_ls_svd_release(plane);
	return CBS_MEMFAIL;
	}
    t = tmatrixs[plane];
    u = umatrixs[plane];
    v = vmatrixs[plane];
    w = wvectors[plane];


/*
	create transfer matrix (angle to position)
*/
    sinfactor = 1./(2.*sin(PI*tune));
    for(row=1;row<=npositionsl;row++)
	{
	for(col=1;col<=ncorrectorsl;col++)
	    {
	    if(row>npositionss[plane])
		{
		t[row][col] = 0.;	/* undetermined case--zero fill */
		}
	    else
		{
		t[row][col] = 
		  sqrt(betapositions[row-1]*betacorrectors[col-1]) *
		   cos(fabs(phasepositions[row-1]-phasecorrectors[col-1])
		    - PI*tune) * sinfactor;
/*			note that input arrays start with index 0 */
		}
	    u[row][col] = t[row][col];
	    }
	}
/*
	get u,v,w matrices via SVD (singular value decomposition)
*/
    sts = svdcmp(u,npositionsl,ncorrectorsl,w,v);
    if(sts != CBS_OK)
	{
	sorbit_ls_svd_release(plane);
	return sts;
	}
/*    uvwprint(npositionsl,ncorrectorsl,u,v,w); */  
/*
	check for singularities (w[ii] == 0) or
	 almost singular (w[ii] < sthreshold)---if almost singular set
	 w[ii] to zero----this will give a "better" solution
*/
    wmax = 0.;
    for(ii=1;ii<=ncorrectorsl;ii++)
	{
	if(w[ii] > wmax)wmax=w[ii];
	}
    nsingular = 0;
    wthreshold = sthreshold*wmax;
    for(ii=1;ii<=ncorrectorsl;ii++)
	{
	if(w[ii] == 0. || w[ii] < wthreshold)
	    {
	    if(returncode == CBS_OK)
		{
		returncode = CBS_GENERR;
		genericerrorl = SORBITSVD_ERROR_SINGULARITY;
		}
	    w[ii] = 0.;
	    if(singularindex != NULL)
		{
		singularindex[nsingular] = ii-1;	/* start with index
							    zero */
		}
	    nsingular++;
	    }
	}    
    if(numsingular != NULL)
	{
	*numsingular = nsingular;
	}
    if(genericerror != NULL)
	{
	*genericerror = genericerrorl;
	}
    return returncode;

    }

/******************************************************************************/
/*+ sorbit_ls_svd_setup_measured
*
*       This is a modified version of sorbit_ls_svd_setup(), added by
*       Eric Prebys on 11/26/01. It is similar to the original version, 
*       except that it sets up the
*       the internal matrices based on the MEASURED transfer matrix (i.e.
*       the matrix determined by inverting the bump matrix.
*	sets up the SVD (singular value decomposition) matrices and the
*	  transfer matrix (internally kept in the module) for smoothing
*	   the orbit via the least squares method so that
*	  sorbit_ls_svd_compute can be called to compute
*	  the new corrector delta angles and the new predicted orbit positions
*	note that if one changes the number of correctors or the number
*	  of positions or the lattice then one must recall this routine
*	  However, if one just has new positions then one can just
*	  call the compute function
*
*	plane			whether horz or vertical 
*				  (SORBITSVD_HORZ, SORBITSVD_VERT)
*				  (this is needed so that both the horz, vert
*				   matrices can be stored for later calculation)
*	maxcorrectors		maximum number of correctors
*	maxpositions		maximum number of positions
*	singularity_threshold	singularity threshold in units of the fraction
*				  of the maximum element of the diagonal
*				  SVD W matrix vector.  Elements of the
*				  diagonal W matrix vector below this will
*				  be set to 0.  This according to SVD theory
*				  will give a better answer.  See the
*				  Numerical Recpipes book.  If this value
*				  is negative then a default value of
*				  1.0e-6 is taken.
*       ameas                   measured transfer array.  Must be dimensioned
*                               ameas[maxpositions][maxcorrectors]
*                               Indices run from zero!
*       usecor                  array of dimension maxcorrectors. For each
*                               entry:  1= use corrector, 0=skip.  Index
*                               runs from zero.
*       usepos                  array of dimension maxpositions. For each
*                               entry:  1= use position, 0=skip. Index runs
*                               from zero.
*	genericerror		a pointer to an integer to receive an
*				  error code if the function returns
*				  CBS_GENERR---this may be null if one
*				  does not care.  Note that if the solution
*				  has singulariites then CBS_GENERR will
*				  be returned.  In particular the types
*				  of generic errors returned are
*				    SORBITSVD_ERROR_UNDETERMINED for the
*				  	case where there are more correctors
*					than positions (the internal matrixes
*					are zero filled so that one gets
*					the SVD singularity solutions)
*				    SORBITSVD_ERROR_SINGULARITY for the case
*					where there are explicit singularities
*					in the solution.
*				  In both of these case the "best" SVD 
*				   solution is returned.
*	numsingular		a pointer to an integer to receive the
*				  number of singular w matrix elements
*				  (either calculated to be zero or set
*				   to zero by the singularity_threshold)
*				  This may be NULL if one does not care
*	singularindex		a pointer to an array of integers to receive
*				  the indices of the singular elements
*			          (could be ncorrectors long if w is
*				   completly zero)  note that both the
*				   the array index and the indexes returned
*				   follow the c standard starting with index
*				   0.
*				  This may be NULL if one does not care
*
* returns acnet error
*
*	input output arrays start at index 0;
*	all internal arrays,matrices start at index 1
*
*
*	the svd algorithm solves the matrix equation
*
*		A*x = b  (actually we minimize |A*x-b|)
*
*		where A is a the closed orbit transfer matrix of size
*			m x n where m = number of bpms and 
*			n = number of correctors.
*		where x is the n vector delta corrector values (changes
*			of angle)
*		where b is the m vector bpm values
*
*	the svd algorithm decomposes A into
*	  A = (U)*(W)*(Vtranspose)
*		where U is an m x n column orthogonal matrix
*		W is a n x n diagonal matrix whose diagonal elements w(j) >= 0
*		V is a n x n othogonal matrix
*
*	   x is solved for by the equation
*
*	  x = (V)*(W')*(Utranspose)b
*		where W' is a n x n diagonal matrix where the diagonal elements
*		 w'(j) = 1/w(j) when w(j) != 0 
*		  and w'(j) = 0 when w(j) == 0 (or very small)	
*	
-*/
/******************************************************************************/
extern "C" int sorbit_ls_svd_setup_measured(int plane, int maxcorrectors, int maxpositions,
  float singularity_threshold, float *ameasured, int *usecor, int *usepos,
  int *ncorr, int *npos, int *genericerror, int *numsingular, int *singularindex)
    {

    int returncode;
    int genericerrorl;
    float sthreshold;
    int sts;
    float wmax,wthreshold;
    int ii;
    int nsingular;

    int ncorrectorsl;
    int npositionsl;

    float **u;
    float **v;
    float **t;
    float *w;
    static int firstcall=TRUE;
    
    static float *asave;
    static int *corsave;
    static int *possave;


    int row,col,rowpnt,colpnt,apnt;

/* These will be pointers to the useable correctors in the list */
    int ncorrectors,npositions;
    int *corrpnt;
    int *pospnt;






/*
	defaults
*/


    if(firstcall) {
      asave = ameasured;
      corsave = usecor;
      possave = usepos;
      firstcall = FALSE;
    } 
    
    if((asave!= ameasured)||
       (corsave!= usecor)||
       (possave!= usepos)) {
       sprintf(sorbit_messbuff,"ERROR: %f %d %d", *ameasured,
         *usecor,*usepos);
       error_message_c(sorbit_messbuff);
    }
    
    returncode = CBS_OK;
    genericerrorl = 0;		/* no error */
    if(singularity_threshold < 0.)
	{
	sthreshold = SVD_THRESHOLD;
	}
    else
	{
	sthreshold = singularity_threshold;
	}


/*
	make sure plane number is ok
*/
    if(plane != SORBITSVD_HORZ && plane != SORBITSVD_VERT)return CBS_INVARG;
/*
	deallocate previous matrices
*/
    sorbit_ls_svd_release(plane);
/*
	allocate matrices
*/
    /* Calculate the total number of correctors and positions */
    corrpnt = (int *) malloc(maxcorrectors*sizeof(int));
    pospnt = (int *) malloc(maxpositions*sizeof(int));
    if((corrpnt==NULL)||(pospnt==NULL)) return CBS_MEMFAIL;

    ncorrectors = 0;
    for(ii=0;ii<maxcorrectors;ii++) {
       if(usecor[ii]) corrpnt[ncorrectors++] = ii;
    }
    npositions = 0;
    for(ii=0;ii<maxpositions;ii++) {
       if(usepos[ii]) pospnt[npositions++] = ii;
    }
    if(ncorr != NULL) (*ncorr) = ncorrectors;
    if(npos!= NULL) (*npos) = npositions;
    
    ncorrectorss[plane] = ncorrectors;
    npositionss[plane] = npositions;
    npositionsse[plane] = npositions;
    if(npositions < ncorrectors)
	{
			/* underdetermined case---will zero fill to get
				a solution */
	npositionsse[plane] = ncorrectors;
	returncode = CBS_GENERR;
	genericerrorl = SORBITSVD_ERROR_UNDETERMINED;    
	}
    ncorrectorsl = ncorrectorss[plane];
    npositionsl = npositionsse[plane];
    tmatrixs[plane] = create_matrix(1,npositionsse[plane],
      1,ncorrectorss[plane]);
    if(tmatrixs[plane] == NULL)
	{
	sorbit_ls_svd_release(plane);
	return CBS_MEMFAIL;
	}
    umatrixs[plane] = create_matrix(1,npositionsse[plane],
      1,ncorrectorss[plane]);
    if(umatrixs[plane] == NULL)
	{
	sorbit_ls_svd_release(plane);
	return CBS_MEMFAIL;
	}
    vmatrixs[plane] = create_matrix(1,ncorrectorss[plane],
      1,ncorrectorss[plane]);
    if(vmatrixs[plane] == NULL)
	{
	sorbit_ls_svd_release(plane);
	return CBS_MEMFAIL;
	}
    wvectors[plane] = vector( 1,ncorrectorss[plane]);
    if(wvectors[plane] == NULL)
	{
	sorbit_ls_svd_release(plane);
	return CBS_MEMFAIL;
	}
    t = tmatrixs[plane];
    u = umatrixs[plane];
    v = vmatrixs[plane];
    w = wvectors[plane];


/*
        This is my big change!!  I replace the calculation of
        the transfer matrix with the filling from the calculated
        matrix, leaving out the rows and columns which have been
        turned off.  -EjP
*/
    for(row=1;row<=npositionsl;row++)
	{
	for(col=1;col<=ncorrectorsl;col++)
	    {
	    if(row>npositionss[plane])
		{
		t[row][col] = 0.;	/* undetermined case--zero fill */
		}
	    else
		{
                /* Note, internal matrix starts with 1.  Go figure ! */
		rowpnt = pospnt[row-1];  /* pointers into original matrix */
		colpnt = corrpnt[col-1];
		apnt = rowpnt*maxcorrectors + colpnt;
		t[row][col] = ameasured[apnt];
		}
	    u[row][col] = t[row][col];
	    }
	}

      free(pospnt);
      free(corrpnt);


/*************** From here on, I left the same! ************************/
/*
	get u,v,w matrices via SVD (singular value decomposition)
*/
    sts = svdcmp(u,npositionsl,ncorrectorsl,w,v);
    

    if(sts != CBS_OK)
	{
	sorbit_ls_svd_release(plane);
	return sts;
	}
/*
	check for singularities (w[ii] == 0) or
	 almost singular (w[ii] < sthreshold)---if almost singular set
	 w[ii] to zero----this will give a "better" solution
*/
    wmax = 0.;
    for(ii=1;ii<=ncorrectorsl;ii++)
	{
	if(w[ii] > wmax)wmax=w[ii];
	}
    nsingular = 0;
    wthreshold = sthreshold*wmax;
    for(ii=1;ii<=ncorrectorsl;ii++)
	{
	if(w[ii] == 0. || w[ii] < wthreshold)
	    {
	    if(returncode == CBS_OK)
		{
		returncode = CBS_GENERR;
		genericerrorl = SORBITSVD_ERROR_SINGULARITY;
		}
	    w[ii] = 0.;
	    if(singularindex != NULL)
		{
		singularindex[nsingular] = ii-1;	/* start with index
							    zero */
		}
	    nsingular++;
	    }
	}    
    if(numsingular != NULL)
	{
	*numsingular = nsingular;
	}
    if(genericerror != NULL)
	{
	*genericerror = genericerrorl;
	}
    return returncode;

    }



/******************************************************************************/
/*+  uvwprint

-*/
/******************************************************************************/
extern "C" void uvwprint(int npos, int ncor, float **u, float **v, float *w)
    {
    int ii,jj,kk;
    FILE *fptr;

    fptr = fopen("uvw.dat","w");

    kk = 0;
    for(ii=1;ii<=npos;ii++)
	{
	for(jj=1;jj<=ncor;jj++)
	    {
	    if(kk == 0)fprintf(fptr,"u[%d][%d]  ",ii,jj);
	    fprintf(fptr,"%f  ",u[ii][jj]);
	    kk++;
	    if(kk >= 5)
		{
		fprintf(fptr,"\n");
		kk = 0;
		}
	    }
	}
    fprintf(fptr,"\n\n");
    kk = 0;
    for(ii=1;ii<=ncor;ii++)
	{
	for(jj=1;jj<=ncor;jj++)
	    {
	    if(kk == 0)fprintf(fptr,"v[%d][%d]  ",ii,jj);
	    fprintf(fptr,"%f  ",v[ii][jj]);
	    kk++;
	    if(kk >= 5)
		{
		fprintf(fptr,"\n");
		kk = 0;
		}
	    }
	}
    fprintf(fptr,"\n\n");
    kk = 0;
    for(jj=1;jj<=ncor;jj++)
	{
	if(kk == 0)fprintf(fptr,"w[%d]  ",jj);
	fprintf(fptr,"%f  ",w[jj]);
	kk++;
	if(kk >= 5)
	    {
	    fprintf(fptr,"\n");
	    kk = 0;
	    }
	}
    fclose(fptr);
//  put in appropriate mail address    
//    mail_send("user@fnal.gov","uvw.dat",NULL,"uvw.dat");

    }

/******************************************************************************/
/*+ sorbit_ls_svd_compute
*	computes a specific solution for the new corrector delta angles
*	  and the new predicted orbit positions via the SVD least squares
*	  method
*	Note that one must call sorbit_ls_svd_setup to set up the
*	  transfer and SVD matrices.
*	note that if one changes the number of correctors or the number
*	  of positions or the lattice then one must recall the setup routine
*	  However, if one just has new positions then one can just
*	  call the compute function over and over.
*
*	plane			whether horz or vertical 
*				  (SORBITSVD_HORZ, SORBITSVD_VERT)
*				  (this is needed so that both the horz, vert
*				   matrices can be stored for later calculation)
*	ncorrectors		number of correctors
*	npositions		number of positions
*	stepcut			factor between 0. and 1. to multiply
*				  deltacorrectors by after solving but
*				  before predicted positions are calculated
*	positions		input array of positions
*	deltacorrectors		output array of the delta angles
*	predictedpositions	output array of the predicted positions
*				this may be NULL if one does not want them
*  note that since the transfer matrix and computed SVD matrices were set
*	up with positions being in meters and angles being in radians that
*	if the input positions are in mm then the output angles and positions
*	are in mrad and mm.
*
* returns acnet error
*
*	input output arrays start at index 0;
*	all internal arrays,matrices start at index 1
*
-*/
/******************************************************************************/
extern "C" int sorbit_ls_svd_compute(int plane, int ncorrectors, int npositions,
  float stepcut, float *positions, float *deltacorrectors,
  float *predictedpositions)

    {
    int ncorrectorsl;
    int npositionsl;

    float **u;
    float **v;
    float **t;
    float *w;

    float *positionsl;
    float *deltacorrectorsl;
    int ii;
    float stepcutl;

    int sts;



/*
	make sure plane number is ok
*/
    if(plane != SORBITSVD_HORZ && plane != SORBITSVD_VERT)return CBS_INVARG;
/*
	check for setup problems
*/
    t = tmatrixs[plane];
    u = umatrixs[plane];
    v = vmatrixs[plane];
    w = wvectors[plane];
    ncorrectorsl = ncorrectorss[plane];
    npositionsl = npositionsse[plane];
    deltacorrectorsl = deltacorrectors-1;	/* start with index 1 */

    if(t==NULL || u==NULL || v==NULL || w==NULL)return CBS_NOINIT;
    if(ncorrectors != ncorrectorsl || npositions != npositionss[plane])
      return CBS_NOINIT;
/*
	create local positions array (may be expanded from input array with
	  zeros if undetermined case (npositions < ncorrectors))
*/
    positionsl = vector(1,npositionsl);
    if(positionsl == NULL)return CBS_MEMFAIL;
    memcpy(&positionsl[1],positions,npositionss[plane]*sizeof(float));
    for(ii=npositionss[plane]+1;ii<=npositionsl;ii++)
	{
	positionsl[ii] = 0.;
	}
/*
	get detacorrectors (do the calculation)
*/
    sts = svbksb(u,w,v,npositionsl,ncorrectorsl,positionsl,deltacorrectorsl);

    if(sts != CBS_OK)
	{
	free_vector(positionsl,1,npositionsl);
	return sts;
	}
/*
	multiply by stepcut and change sign of angles 
		(change sign because have solved for angles which move
		 the orbit from 0 to the positions inputed and we want
		 the angles which move the beam from the positions inputed
		 to 0)
*/
    stepcutl = -stepcut;
    for(ii=1;ii<=ncorrectorsl;ii++)
	{
	deltacorrectorsl[ii] *= stepcutl;
	}
	
/*
	get the predicted positions
*/
    if(predictedpositions != NULL)
	{
	sts = sorbit_ls_svd_predict(plane,ncorrectorsl,
	  npositionss[plane],deltacorrectors,positions,predictedpositions);
	}
    free_vector(positionsl,1,npositionsl);
    return sts;
    }


/******************************************************************************/
/*+ sorbit_ls_svd_predict
*	computes the predicted positions given the deltacorrector angles
*	Note that one must call sorbit_ls_svd_setup to set up the
*	  transfer and SVD matrices.
*	note that if one changes the number of correctors or the number
*	  of positions or the lattice then one must recall the setup routine
*	  However, if one just has new deltacorrectors then one can just
*	  call the this routine over and over.
*
*	plane			whether horz or vertical 
*				  (SORBITSVD_HORZ, SORBITSVD_VERT)
*				  (this is needed so that both the horz, vert
*				   matrices can be stored for later calculation)
*	ncorrectors		number of correctors
*	npositions		number of positions
*	deltacorrectors		input array of the delta angles
*	originalpositions       input array of original positions
*	predictedpositions	output array of the predicted positions
*				this may be NULL if one does not want them
*  note that since the transfer matrix and computed SVD matrices were set
*	up with positions being in meters and angles being in radians that
*	if the input angles are in mrad then the output positions
*	are in mm.
*
* returns acnet error
*
*	input output arrays start at index 0;
*	all internal arrays,matrices start at index 1
*
-*/
/******************************************************************************/
extern "C" int sorbit_ls_svd_predict(int plane, int ncorrectors, int npositions,
  float *deltacorrectors, float *originalpositions, float *predictedpositions)

    {
    int ncorrectorsl;
    int npositionsl;

    float **t;

    int row,col;



/*
	make sure plane number is ok
*/
    if(plane != SORBITSVD_HORZ && plane != SORBITSVD_VERT)return CBS_INVARG;
/*
	check for setup problems
*/
    t = tmatrixs[plane];
    ncorrectorsl = ncorrectorss[plane];
    npositionsl = npositionsse[plane];

    if(t==NULL)return CBS_NOINIT;
    if(ncorrectors != ncorrectorsl || npositions != npositionss[plane])
      return CBS_NOINIT;
/*	note that npositions may be less than npositionsl if in the 
	  setup npositions < ncorrectors resulting in 0 fill  */
    for(row=1;row<=npositions;row++)
	{
	predictedpositions[row-1] = originalpositions[row-1];
						/* index starts with 0 */
	for(col=1;col<=ncorrectors;col++)
	    {
	    predictedpositions[row-1] += t[row][col]*deltacorrectors[col-1];
	    }
	}
    return CBS_OK;
    }

/******************************************************************************/
/*+ sorbit_ls_svd_release
*	releases internal memory allocated through 
*	   sorbit_ls_svd_setup
*
-*/
/******************************************************************************/
extern "C" void sorbit_ls_svd_release(int plane)
    {
/*
	make sure plane number is ok
*/
    if(plane != SORBITSVD_HORZ && plane != SORBITSVD_VERT)return;
/*
	deallocate previous matrices
*/
    if(tmatrixs[plane] != NULL)
	{
	free_matrix(tmatrixs[plane],1,npositionsse[plane],1,
	  ncorrectorss[plane]);
	tmatrixs[plane] = NULL;
	}
    if(umatrixs[plane] != NULL)
	{
	free_matrix(umatrixs[plane],1,npositionsse[plane],1,
	  ncorrectorss[plane]);
	umatrixs[plane] = NULL;
	}
    if(vmatrixs[plane] != NULL)
	{
	free_matrix(vmatrixs[plane],1,ncorrectorss[plane],1,
	  ncorrectorss[plane]);
	vmatrixs[plane] = NULL;
	}
    if(wvectors[plane] != NULL)
	{
	free_vector(wvectors[plane],1,ncorrectorss[plane]);
	wvectors[plane] = NULL;
	}
    ncorrectorss[plane] = 0;
    npositionss[plane] = 0;
    npositionsse[plane] = 0;

    }
#ifdef LINUX
/*
 * Values accepeted for scrub issues are ...
 * not-addressed (issue present and not addressed) or
 * addressed (issue present and verified ok or fixed).
 * No key-value string is to be treated as not-addressed.
 * If there is no such issue at all then no string is
 * needed at all.
 */
static char const * const LcppScrubIssues[] __attribute__((unused)) = {
    "$LcppScrubIssues: fp-flatfiles=addressed $",
    };
#endif
