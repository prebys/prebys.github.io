/******************************************************************************
 ** lib465.c
 ** This is a library of routines for dealing handling 465's.   This part
 ** is fairly generic, but it's being designed with the needs of the
 ** Booster corrector system involved.  Booster specific stuff will be in
 ** lib_correctors.
 **
 ** October 19, 2001 E.Prebys Original, extracted from test465
 ******************************************************************************/


#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>


#include "cnsparam.h"				/* generic console constants */
#include "cns_data_structs.h"			/* generic console data structures */
#include "dbprops.h"				/* database properties */
#include "clib.h"				/* 'old' CLIB constants and prototypes */
#include "cbslib.h"				/* CBS constants and prototypes */
#include "diolib.h"				/* DIO constants and prototypes */
#include "acnet_errors.h"			/* defined constants for ACNET errors */
#include "tclk_events.h"			/* defined constants for TCLK events */
#include "extchrset.h"				/* definitions for special characters */
#include "argument_defs.h"			/* general defined constants for defaulted argument values */
#include "ul_cbsaux/auxlib.h"			/* UL_CBSAUX library defs */
#include "ul_windowlib/windowlib.h"		/* UL_WINDOWLIB library defs */
#include "lib465.h"



/*********************************************************************************************************
** lib465_get_map
**
** Routine to get all the map info from a 465
**
** Oct 10, 2001 E.Prebys Original
**
********************************************************************************************************/
extern "C" int lib465_get_map(int family_di,Map_465 *map) {
  int status, i;
  int num_dis;
  int di;
  int family_dis[MAX_FUNCTIONS];
  short pi_array[MAX_FUNCTIONS];
  short error_array[MAX_FUNCTIONS];
  unsigned char ssdn_array[MAX_FUNCTIONS][SSDN_ARRAY_SIZE];
  int current_function_index;
  int function_code;
  int ison,dum;
  short raw_dac;
  static int  last_di = (-1);
  short property;
  int num_devices;
  int number_functions = NUMBER_FUNCTIONS;

  if(family_di==last_di) return(0);  /* Only read it out once */
  status = dio_family_info(&family_di,&num_dis,family_dis,error_array);
  if(status!=DIO_OK) {
    error_display_c("Error in lib465_get_map (dio_get_family)",ERR_ACNET,status);
    return(status);
  }
 
  if(num_dis != NUMBER_FUNCTIONS) {
    error_display_c("Error in lib465_get_map (function number mismatch)",ERR_ACNET,status);
    return(-1);
  }    

/*
  Using the DIs associated with the various functions, get the SSDN value for
    the "setting" property. Functions which do not have a "setting" property
    will not be used so if nothing is returned due to an error, just a zero (0)
    will be inserted into the appropriate entry in the FUNCTION_MAP structure.
    Here we have to ignore the status and err_array values.
*/
  for( i = 0; i < NUMBER_FUNCTIONS; i++ ) pi_array[ i ] = PRSET;
  status = dio_dev_ssdn( family_dis, (short *)&pi_array, (char *)&ssdn_array,
			 (short *)&error_array, &number_functions );
  if(status!=DIO_OK) {
    error_display_c("Error in lib465_get_map (dio_dev_ssdn, PRSET) ",ERR_ACNET,status);
	  return(status);
  }

  /* Here's some weirdness I don't quite understand. It has something to do
     with dealing with version numbers */
  if(ssdn_array[0][1]==115) current_function_index = 4;
  if(ssdn_array[0][2]==115) current_function_index = 6;

  /* Go through and map the individual function codes */
  for(i = 0; i < NUMBER_FUNCTIONS ; i++ ) {
    di = family_dis[i];
    function_code = (0xFF)& (ssdn_array[i][current_function_index]>>4);
    if(function_code>MAX_FUNCTIONS) {
      error_display_c("Illegal function code. Ignoring ",ERR_ACNET,status);
      continue;
    }
    map->func2dimap[function_code] = di;
    switch(function_code) {
    case P_PAGE_FUNCTION:
      map->p_page_di = di;
      break;
    case FT_TABLE_FUNCTION:   
      map->ft_table_di = di;
      break;
    case G_TABLE_FUNCTION:
      map->g_table_di = di;
      break;
    case H_TABLE_FUNCTION:
      map->h_table_di = di;
      break;
    case MAP_FUNCTION:	    
      map->map_di = di;
      break;
    case  S_FACTORS_FUNCTION:  
      map->s_factors_di = di;
      break;
    case VERSION_FUNCTION:
      map->version_di = di;
      break;
    case REFERENCE_FUNCTION:
      map->reference_di = di;
      break;
    case X_VALUES_FUNCTION:
      map->x_values_di = di;
      break;
    case Y_VALUES_FUNCTION:
      map->y_values_di = di;
      break;
    case C_EVENTS_FUNCTION:
      map->c_events_di = di;
      break;
    case MDAT_FUNCTION:
      map->mdat_di = di;
      break;
    };
  }
  
 
  /* Get the device info */
  status = dio_get_raw_c(map->version_di,PRREAD,map->info,0,INFO_ARRAY_SIZE*2);
  if(status!=DIO_OK) {
    error_display_c("Error in lib465_get_map (dio_get_raw_c)",ERR_ACNET,status);
    return(status);
  }
 
  /* Get the current enable state */
  status = dio_status_c(map->reference_di,&ison,&dum,&dum,&dum);
  if(status!=DIO_OK) {
    error_display_c("Error in lib465_get_map (dio_status_c)",ERR_ACNET,status);
    return(status);
  }
  if(ison==TRUE) map->enable=1;
  else map->enable=0;

  /* Get the scaling info */
  property = PRSET;
  num_devices = 1;
  status = dio_get_pdb(&(map->ft_table_di), &property, &(map->ft_scale) , error_array, &num_devices );
  if(status!=DIO_OK) {
    error_display_c("Error in lib465_get_map (dio_get_pdb)",ERR_ACNET,status);
    return(status);
  }

  /* Get the initial DAC setting and scale it */
  status =
     dio_get_raw_c(map->reference_di,PRSET,&raw_dac,0,sizeof(short));

  map->init_dac = raw_dac;
  /* map->init_dac = PDUDCU( &raw_dac,
	&(map->ft_scale), &error_array); */


  if(status!=DIO_OK) {
    error_display_c("Error in lib465_get_map (dio_get_raw_c)",ERR_ACNET,status);
    return(status);
  }
   last_di = family_di;

  return(0);
}

/*********************************************************************************************
** Function to read the FT ramp from a 465, and optionally scale it
**
**
**  October 9, 2001 E.Prebys Oritinal
**********************************************************************************************/

extern "C" int lib465_ft_ramp(int rw,Map_465* map,int ramp_num,short raw_ramp[MAX_SLOTS][2], FT_Ramp *scaled_ramp) {
  int list_id, status, iwait;
  short int error;
  short ramp_num_short;
  short table_types = TIME_TABLE;
  short slot_numbers = 1;
  short num_slots = MAX_SLOTS;
  short slot_uses = SLOT_WHOLE;
  
  ramp_num_short = (short)ramp_num;


  /* If we're sending it then see if we need to unscale it first */
  if((rw==LIB465_SET) && (scaled_ramp!=NULL)) {
    status = unscale_a_ft_ramp(map,raw_ramp,scaled_ramp);
    if(status !=0) {
      error_display_c("Error in td_465_ramp (unscale_a_ft_ramp)",ERR_ACNET,status);
      return(status);
    }
  }

  list_id = 0;
  status = td_build_c(&list_id,1,&(map->ft_table_di),&ramp_num_short,&table_types,
         &slot_numbers,&num_slots,
			 &slot_uses,FALSE,&error);
  if(status!=DIO_OK) {
    error_display_c("Error in lib465_ft_ramp (td_build_c)",ERR_ACNET,status);
    return(status);
  }

  for(iwait=0; iwait<5; iwait++) {
    if(rw==LIB465_SET)
      status = td_set(&list_id,raw_ramp,&error);
    else       
      status = td_read(&list_id,raw_ramp,&error);

    if (status==0) break;
    pause_c(0);
  }

  if(status<0) {
    error_display_c("Error in lib465_ft_ramp (td_read/write)",ERR_ACNET,status);
  }

  td_cancel(&list_id);

  /* If we're setting the ramp, then we're done */
  if(rw==LIB465_SET) return(0);

  if (scaled_ramp != NULL) return(scale_a_ft_ramp(map,raw_ramp,scaled_ramp));
  return 0;
 }
/*********************************************************************************************
** Function to read or write the  G(i) or H(i) tables
**
**
**  October 9, 2001 E.Prebys Oritinal
**********************************************************************************************/

extern "C" int lib465_gi_hi_table(int rw,int gh,Map_465* map,int ramp_num,
  int size, short *ordinate, float *abscissa) {
  int ord_di,abs_di;
  int ord_list_id,abs_list_id, status;
  short int ord_type,abs_type;
  
  short slot_numbers;
  short slot_uses;
  
  short int error;
  short ramp_num_short;
  short size_short;
  

  ramp_num_short = (short)ramp_num;
  size_short = (short)size;

/* decide whether we're addressing a H or G table */
  if(gh==0) {
    ord_di = map->x_values_di;
    abs_di = map->g_table_di;
    ord_type = MDAT_GITABLE;
    abs_type = MDAT_GTABLE;
  } else {
    ord_di = map->y_values_di;
    abs_di = map->h_table_di;
    ord_type = MDAT_HITABLE;
    abs_type = MDAT_HTABLE;
  }
    
  ord_list_id = abs_list_id = 0;
  /* ordinate list ID */
  slot_numbers = 1;
  slot_uses = SLOT_WHOLE;
  status = td_build_c(&ord_list_id,1,&ord_di,&ramp_num_short,&ord_type,
              &slot_numbers,&size_short,&slot_uses,FALSE,&error);
  if(status!=DIO_OK) {
    error_display_c("Error in lib465_gi_hi_table (td_build_c (ord))",
       ERR_ACNET,status);
       return(status);
  }
  /* absicca list ID */ 
    slot_numbers = 1;
  slot_uses = SLOT_WHOLE;           
  status = td_build_c(&abs_list_id,1,&abs_di,&ramp_num_short,&abs_type,
              &slot_numbers,&size_short,&slot_uses,TRUE,&error);
  if(status!=DIO_OK) {
    error_display_c("Error in lib465_gi_hi_table (td_build_c (abs))",
       ERR_ACNET,status);
       return(status);
  }
                

  if(rw==LIB465_SET) {
    status = td_set(&ord_list_id,ordinate,&error);
    if(status>=0) status = td_set(&abs_list_id,abscissa,&error);
  } else {
    status = td_read(&ord_list_id,ordinate,&error);
    if(status>=0) status = td_read(&abs_list_id,abscissa,&error);
  }
  
  
  if(status<0) {
    error_display_c("Error in lib465_gi_hi_table (td_read/write)",ERR_ACNET,status);
  }

  td_cancel(&ord_list_id);
  td_cancel(&abs_list_id);

  return(status);

 }
/*****************************************************************************
 ** lib465_clock_table
 **  read or write the clock table to a 465.
 **
 *****************************************************************************/
extern "C" int lib465_clock_table(int rw,Map_465 *map,short clk[MAX_INTERRUPTS][MAX_EVENTS]){ 
  int list_id;
  short error[MAX_INTERRUPTS][MAX_EVENTS];
  int sts;
  short int size;
  short table_number = 1;
  short table_types = CLOCK_TABLE;
  short slot_numbers = 1;
  short slot_uses = SLOT_WHOLE;

  
  size = MAX_INTERRUPTS*MAX_EVENTS;


  
  sts = td_build_c(&list_id,1,&(map->c_events_di),&table_number,&table_types,&slot_numbers,
		   &size,&slot_uses,FALSE,(short *)&error);

  if(sts!= DIO_OK) {
    error_display_c("Error in lib465_clock_table (td_build_c)",ERR_ACNET,sts);
    return(sts);
  }

  if(rw==LIB465_SET) {
    sts = td_set(&list_id,clk,(short *)&error); 
  }
  else {
    sts = td_read(&list_id,&(clk[0][0]),(short *)&error);
  }

  td_cancel(&list_id);

  if(sts!= DIO_OK) {
    error_display_c("Error in lib465_clock_table (td_read/write)",ERR_ACNET,sts);
    return(sts);
  }
  return sts;
}
/*****************************************************************************
 ** lib465_clock_table
 **  read or write the clock table to a 465.
 **
 *****************************************************************************/
extern "C" int lib465_sf_table(int rw,Map_465 *map,float sf[MAX_RAMPS]){ 
  short s[MAX_RAMPS];
  int i,sts;

  if(map==NULL) return(0);

  if(rw==LIB465_SET) {
    for(i=0;i<MAX_RAMPS;i++) {
       s[i] = (int) (sf[i]*256.);
    }
    
    sts = dio_set_raw_c(map->s_factors_di,PRSET,(char *)s,sizeof(s));
  } else {
    sts = dio_get_raw_c(map->s_factors_di,PRSET,s,0,sizeof(s));
    for(i=0;i<MAX_RAMPS;i++) {
       sf[i] = ((float) s[i])/256.;
    }
  }
  return(sts);
}
/*************************************************************************************************
** lib465_ramp_enable() - set the enable state of a 465 defined by map or list of maps
**  
**  Because unused locations are handled correctly, one can set all with nload=2*MAX_CORRECTOS
**
**************************************************************************************************/
extern "C" int lib465_ramp_enable(Map_465 *maps[],int nload, int state) {
  int i;
  int list_enable,list_set;  /* lists to enable the ramp and set the
                                DAC value */
  int *dis;
  short *error_array;
  short *dacs;
  short int property;
  int sts;
  int nuse;
  short int length;

  dis = (int *)calloc(nload,sizeof(int));
  dacs = (short *)calloc(nload,sizeof(short));
  error_array = (short *)calloc(nload,sizeof(short));

  /* First build a list of the DI's to set the state of the triggers */
  nuse=0;
  sts = 0;
      
  for(i = 0; i<nload ; i++) {
    if(maps[i]==NULL) continue;  /* skip unused correctors */
    /* dacs[nuse] = (short) PDCUUD( &(maps[i]->init_dac), 
                                          &(maps[i]->ft_scale), 
                                            error_array ); */
    dacs[nuse] = (short) maps[i]->init_dac;
    dis[nuse++] = maps[i]->reference_di;
  }
  if(nuse==0) goto getout;   /* quietly exit */
  
  /* Build up a list to set the DAC's */
  property = -PRSET;      /* setting it negative sets all to same */
  length = -sizeof(short); /* length of each data word */
  sts = dio_bld_set_raw_c(&list_set,nuse,dis,&property,error_array,
  	                  &length);
  if(sts != DIO_OK) {
    error_display_c("Error building DAC set list",ERR_ACNET,sts);
    goto getout;
  }
  
  /* Build up a list to enable/disable the ramps */
  property = -PRBCTL;     /* setting it negative sets all to same */
  sts = dio_bld_set_c(&list_enable,nuse,dis,&property,error_array);
  if(sts != DIO_OK) {
    error_display_c("Error building ramp enable",ERR_ACNET,sts);
    goto getout;
  }

  if(state) {
      /* Enable ramping */
      sts = dio_on_lst(&list_enable,error_array);
  } else {
    /* Disable ramping. If here, then restore state of DAC's */
    sts = dio_off_lst(&list_enable,error_array);
    if(sts == DIO_OK) sts = 
             dio_set_lst_raw_c(&list_set,(char *)dacs,error_array);
  }
  td_cancel(&list_enable);
  td_cancel(&list_set);
  
  if(sts != DIO_OK) {
    error_display_c("Error setting ramp state",ERR_ACNET,sts);
    goto getout;
  }
/* Set the states to the new value */
  for(i=0;i<nload;i++) {
     if(maps[i]==NULL) continue;
     /* Seems to be a time lag in the read back.  assume it worked  */
     /* 
      * dio_status_c(maps[i]->reference_di,&ison,&dum,&dum,&dum);
      * if(ison==TRUE) maps[i]->enable = 1;
      * else maps[i]->enable = 0; */
    maps[i]->enable = state;
    
  }
 
  sts = 0;
 getout:
   
  cfree(dis);
  cfree(dacs);
  cfree(error_array);
  
  return(sts);
}

/******************************************************************************/
extern "C" int	scale_a_ft_ramp(
			Map_465 *map,
			short  values_array[ MAX_SLOTS ][ 2 ],
			FT_Ramp	 *FT_ramp_ptr
			) 

  /*
  **++
  **  FUNCTIONAL DESCRIPTION:
  **
  **      Generate the F(t) information for a 465/466 card for the given Booster
  **	 Waveform generator ramps.
  **
  **  FORMAL PARAMETERS:
  **
  **  October 19, 2001 Modified from A. Waller's routine of the same name
  **--
  */

{
/*
    Massage F(t) segement of ramp for plotting or other visual interface.

    Using the supplied info from where ever it comes, formulate the
    accumulated time in Msecs, and scale the waveform values with the
    appropriate scale factor and MDAT data. Put the appropriate information
    about the FT segement of the ramp into structures in dynamic memory.
*/
    short  error;
    int	    point;
    float	    scale_factor, time_scale, MDAT_mult;
    float	    current_value, accumulated_time, min_value, max_value;
    float	    Msec_mult[ 3 ] = { 1.0, 0.2, 0.1 };

    
    if(FT_ramp_ptr == NULL) return(-1);

/*
    Get proper scaling information for the device.
*/
    time_scale = Msec_mult[ map->info[ CLOCK_INFO ] ];
/*
    Set scale factor and MDAT_mult to 1.0
*/
    scale_factor = MDAT_mult = 1.0;
/*
    The FT_Ramp structure will have accumulated time for the ramp plots.
*/
    accumulated_time = min_value = max_value = 0.0;
/*
    Scale time into Msecs based on clock frequency and generate the appropriate
     F(t) value based on the F(t) segment algorithm for a 46x card.

    Keep track of minimum and maximum values for the FT_Ramp structure.
*/
    FT_ramp_ptr->Max_Slots = 0;
    for( point = 0; point < MAX_SLOTS; point++ )
    {
      if((point==0)||values_array[point][0]>0){
	accumulated_time = (float) values_array[ point ][ 0 ] * time_scale + accumulated_time;
	current_value = scale_factor * MDAT_mult * PDUDCU( &values_array[ point ][ 1 ],
							   &(map->ft_scale), &error );
	FT_ramp_ptr->Time_Value[ point ][ 0 ] = accumulated_time;
	FT_ramp_ptr->Time_Value[ point ][ 1 ] = current_value;
	if( current_value < min_value ) min_value = current_value;
	if( current_value > max_value ) max_value = current_value;
	FT_ramp_ptr->Max_Slots++; 
      } else {
	FT_ramp_ptr->Time_Value[point][0] =
	FT_ramp_ptr->Time_Value[point][1] =
	  0.;
      }
    }
/*
    Now stuff away statistics into the FT_Ramp structure.
*/
    FT_ramp_ptr->Max_Time  = accumulated_time;
    if( fabs( max_value - min_value ) > 0.5 ) 
    {
	FT_ramp_ptr->Min_Value = min_value;
	FT_ramp_ptr->Max_Value = max_value;
    }
    else
    {
	FT_ramp_ptr->Min_Value = min_value - 0.25;
	FT_ramp_ptr->Max_Value = max_value + 0.25;
    }
/*
    Cache away the dependent variable label text.
*/
    map->info[ FT_RAMP_END ] = FT_ramp_ptr->Max_Slots;
    strncpy((char *) &(FT_ramp_ptr->y_label), (const char *)&(map->ft_scale.pdb_ctxt), LABEL_TEXT_SIZE );
    return(0);
}

/******************************************************************************/
extern "C"   int	unscale_a_ft_ramp(  Map_465  *map,
			    short		values_array[ MAX_SLOTS ][ 2 ],
			    FT_Ramp		*FT_ramp_ptr)

/*
**++
**  FUNCTIONAL DESCRIPTION:
**
**      Generate the raw data from the F(t) information for a 465/466 card for
**	 the given Booster Waveform generator ramps.
**
**  FORMAL PARAMETERS:
**   
**
**--
*/

{
/*
    Take the Massaged F(t) segement of ramp and generate the raw data values
    for the given ramp.

    Using the supplied info from where ever it comes, formulate the
    delta time in Msecs, and unscale the waveform values with the
    appropriate scale factor and MDAT data.
*/
  short  error;
  int	    point;
  float	    scale_factor, time_scale, MDAT_mult;
  float	    current_value, delta_time, last_time;
  float	    Msec_mult[ 3 ] = { 1.0, 0.2, 0.1 };

  if( FT_ramp_ptr == NULL ) return(0);
/*
    Get proper scaling information for the device.
*/
  time_scale = Msec_mult[ map->info[ CLOCK_INFO ] ];
  /*
    Set scale factor and MDAT_mult to 1.0
*/
  scale_factor = MDAT_mult = 1.0;
/*
    The FT_Ramp structure will have accumulated time for the ramp plots. Turn
     into delta time. Save last time value to calculate next delta time.
*/
  delta_time = 0.0;
  last_time = 0.0;
/*
    Unscale time into ticks based on clock frequency and generate the appropriate
     raw value based on the F(t) segment algorithm for a 46x card.
*/
  FT_ramp_ptr->Max_Slots = 0;
  for( point = 0; point < MAX_SLOTS; point++ )
    {
      if((point==0)||FT_ramp_ptr->Time_Value[point][0]!=0.) {
	delta_time = FT_ramp_ptr->Time_Value[ point ][ 0 ] - last_time;
	last_time = FT_ramp_ptr->Time_Value[ point ][ 0 ];
	current_value = FT_ramp_ptr->Time_Value[ point ][ 1 ];
	values_array[ point ][ 0 ] = (short)( ( delta_time / time_scale ) + 0.0001 );
	values_array[ point ][ 1 ] = (short)( PDCUUD( &current_value, &(map->ft_scale), &error )
					      / ( scale_factor * MDAT_mult ) );
	FT_ramp_ptr->Max_Slots++;
      } else {
	values_array[point][0] = values_array[point][1] = 0;
      }
    }
/*
    Clear out the rest of the points in the table.
*/
  map->info[ FT_RAMP_END ] = FT_ramp_ptr->Max_Slots;
  return(0);
}

/******************************************************************
 * Decode trigger string
 *****************************************************************/
extern "C" int lib465_decode_trigger_string(char *string, short *list, int *n) {
  char *s;
  int val;
  int i;  

  *n = 0;
  
  /* init to null event */
  for(i=0;i<MAX_EVENTS;i++) list[i]=NULL_EVENT;
  
  s = strtok(string," /$,\n\t");
  if(s==NULL) return(0);
  if(strlen(s)==0) return(0);
  
  while(s!=NULL) {
    sscanf(s,"%x",&val);
    if((val!=0)&&(val!=NULL_EVENT)) {
      list[(*n)++] = val;
    }
    s = strtok(NULL," /$,\n\t");
  }
  return(0);
}
/*******************************************************************
 * Encode trigger string
 ******************************************************************/
extern "C" int lib465_encode_trigger_string(short *list, int n, char *string) {
  char nbuff[20];
  int i;
  /* Blank out the string */
  string[0]=string[TRIG_STRING_LEN-1]='\0';

  for (i=1;i<(TRIG_STRING_LEN-1);i++) string[i] = ' ';

  string[TRIG_STRING_LEN-1] = '\0';
  for(i = 0; i<n; i++) {
    if((list[i]==0)||(list[i]==NULL_EVENT)) continue;
    if(i!=0) strcat(string,",");
    sprintf(nbuff,"%X",list[i]);
    strcat(string,nbuff);
  }
  /* Eliminate the internal 0, so the whole blank line will print */
  i = strlen(string);
  string[i] = ' ';

  return(0);
}
/*********************************************************************
* lib465_map_table - 
*   load the maps into 465
*
***********************************************************************/
extern "C" int lib465_map_table(int rw, Map_465 *map, 
      short *f_map, short *g_map, short *h_map, short *f_mult,
      short *g_mult, short *h_mult, short *f_scale, short *g_scale, 
      short *h_scale) {
  int size,sts,i;
  ramp_map_t *map_buffer;
  short map_word;

  map_buffer = (ramp_map_t *)  malloc(sizeof(ramp_map_t));
  
  /* read in the existing table, no matter what */
  size = sizeof(ramp_map_t);
  sts = dio_get_raw_c(map->map_di,PRSET,map_buffer,0,size);
  if(sts != DIO_OK) {
     error_display_c("Error reading map table",ERR_ACNET,sts);
     free(map_buffer);
     return(sts);
  }
  if(rw == LIB465_GET) {  /* Load data into return buffers */
    size = MAX_INTERRUPTS*sizeof(short);
    for(i=0;i<MAX_INTERRUPTS;i++) {
       map_word = map_buffer->ramp_map[i];
       if(f_map!=NULL) f_map[i] = (map_word>>4)&0xF;
       if(g_map!=NULL) g_map[i] = (map_word>>8)&0xF;
       if(h_map!=NULL) h_map[i] = (map_word>>12)&0xF;
    }
    if(f_mult != NULL) memcpy(f_mult,map_buffer->f_mult,size);
    if(g_mult != NULL) memcpy(g_mult,map_buffer->g_mult,size);
    if(h_mult != NULL) memcpy(h_mult,map_buffer->h_mult,size);
    if(f_scale != NULL) memcpy(f_scale,map_buffer->f_scale,size);
    if(g_scale != NULL) memcpy(g_scale,map_buffer->g_scale,size);
    if(h_scale != NULL) memcpy(h_scale,map_buffer->h_scale,size);
   } else {       /* Load data for writing */
     for(i=0;i<MAX_INTERRUPTS;i++) {
       map_word = (map_buffer->ramp_map[i])&0xFFF0;
       if(f_map!=NULL) {
         map_word &= 0xFF0F;  /* mask of second nibble */
         map_word |= (f_map[i]<<4);
       }
       if(g_map!=NULL) {
         map_word &= 0xF0FF;  /* mask off next nibble */
         map_word |= (g_map[i]<<8);
       }
       if(h_map!=NULL) {
         map_word &= 0x0FFF;
         map_word |= (h_map[i]<<12);
       }
       map_buffer->ramp_map[i]=map_word;
     }  
    size = MAX_INTERRUPTS*sizeof(short);
    if(f_mult != NULL) memcpy(map_buffer->f_mult,f_mult,size);
    if(g_mult != NULL) memcpy(map_buffer->g_mult,g_mult,size);
    if(h_mult != NULL) memcpy(map_buffer->h_mult,h_mult,size);
    if(f_scale != NULL) memcpy(map_buffer->f_scale,f_scale,size);
    if(g_scale != NULL) memcpy(map_buffer->g_scale,g_scale,size);
    if(h_scale != NULL) memcpy(map_buffer->h_scale,h_scale,size);
    size = sizeof(ramp_map_t);
    sts = dio_set_raw_c(map->map_di,PRSET,(char *)map_buffer,size);
    if(sts != DIO_OK) {
     error_display_c("Error writing map table",ERR_ACNET,sts);
     free(map_buffer);
     return(sts);
    }
  }
  free(map_buffer);
  return(0);
}          
/***************************************************************************
*
* lib465_default_maps(Map_465 *map)
*
*  Set up the default mapping
*
**************************************************************************/
extern "C" int lib465_default_maps(Map_465 *map) {
   short f_mult[MAX_INTERRUPTS],g_mult[MAX_INTERRUPTS],h_mult[MAX_INTERRUPTS];
   short f_scale[MAX_INTERRUPTS],g_scale[MAX_INTERRUPTS],
      h_scale[MAX_INTERRUPTS];  
   int i;
   
   for(i=0;i<MAX_INTERRUPTS;i++) {
     f_mult[i] = g_mult[i] = h_mult[i] = 0;  /* MDAT factor = 1 */
     if(i<MAX_RAMPS) {
       f_scale[i] = 1;
       g_scale[i] = 2;
       h_scale[i] = 3;
     } else {
       f_scale[i] = g_scale[i] = h_scale[i] = 0;
     }
   }
   return(lib465_map_table(LIB465_SET,map,NULL,NULL,NULL,f_mult,g_mult,h_mult,
      f_scale,g_scale,h_scale));

}   
/**************************************************************************
* lib465_mdat
*  Mdat select words 
***************************************************************************/
extern "C" int lib465_mdat(int rw,Map_465 *map, int *g_word, int *h_word) {
   unsigned short mdat_word;
   int sts;
   
   sts = dio_get_raw_c(map->mdat_di,PRSET,&mdat_word,0,sizeof(short));
   if(sts != DIO_OK) {
     error_display_c("Error reading MDAT word",ERR_ACNET,sts);
     return(sts);
   }
   
   if(rw==LIB465_GET) {
     if(h_word!=NULL) (*h_word) = mdat_word&0xFF;
     if(g_word!=NULL) (*g_word) = (mdat_word>>8)&0xFF;
     return(0);
   } else {
     if(h_word!=NULL) {
       mdat_word &= 0xFF00;    /* clear low byte */
       mdat_word |= (*h_word); /* set to h_word */
     }
     if(g_word!=NULL) { 
       mdat_word &= 0x00FF;    /* clear high byte */
       mdat_word |= ((*g_word)<<8);  /* set to g_word */
     }
     sts = dio_set_raw_c(map->mdat_di,PRSET,(char *)&mdat_word,sizeof(short));
     if(sts != DIO_OK) {
       error_display_c("Error setting MDAT word",ERR_ACNET,sts);
       return(sts);
     }
   }
   return(0);
}
/**************************************************************************/
/* lib465_dac_val(Map_465 *map) - return the floating DC value associated */ 
/*          with the initialization DAC of this ramp                      */
/**************************************************************************/
extern "C" float lib465_dac_val(Map_465 *map) {
   short raw_dac,err;
   
   raw_dac = (short) map->init_dac;
   return(PDUDCU( &raw_dac,&(map->ft_scale), &err)); 
}
#ifdef LINUX
/*
 * Values accepeted for scrub issues are ...
 * not-addressed (issue present and not addressed) or
 * addressed (issue present and verified ok or fixed).
 * No key-value string is to be treated as not-addressed.
 * If there is no such issue at all then no string is
 * needed at all.
 */
static char const * const LcppScrubIssues[] __attribute__((unused)) = {
    "$LcppScrubIssues: fp-network-use=addressed $",
    };
#endif
