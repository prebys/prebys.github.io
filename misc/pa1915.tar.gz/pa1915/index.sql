$isql/server=adbs/user="herrup"/pass="bob_dole"
use appdb
go
drop index b_db_floats.idx
go
create unique clustered index idx on b_db_floats(name,tclk,plane,slot,fid,
date)
go

drop index b_db_longs.idx
go
create unique clustered index idx on b_db_longs(name,tclk,plane,slot,fid,
date)
go

drop index b_db_shorts.idx
go
create unique clustered index idx on b_db_shorts(name,tclk,plane,slot,fid,
date)
go
