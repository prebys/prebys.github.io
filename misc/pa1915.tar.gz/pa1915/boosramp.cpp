#ifndef __BOOSRAMP_H__
#define __BOOSRAMP_H__
/********************************************************************/
/* Fill the Booster ramp tables                                     */
/********************************************************************/

#include "gen.h"
#include <math.h>
#include "boosramp.h"

static BOOSTER_RAMP s_bramp;

/* for now, the time breaks are hardcoded */
/* Changed next to last from 36.->33. 12/11/01 EjP */
/* Changed the last time back to 36, even though it's */
/* sampled at 33, so that it carries the final ramp point */
/* past the end of the cycle. 4/22/02 EjP */
static float time_breaks[MAX_BREAKPOINTS] = 
    {2.2,2.3,2.4,2.5,2.6,2.7,2.8,2.9,3.0,3.1,3.2,
     3.3,3.4,3.5,3.6,3.7,3.8,3.9,4.0,4.1,4.2,4.3,4.4,
     4.5,4.6,4.7,4.8,4.9,5.0,5.1,5.2,5.3,5.4,5.5,5.6,
     5.7,5.8,5.9,6.0,6.2,6.4,6.6,6.8,7.0,7.2,
     7.4,7.6,7.8,8.0,8.3,8.6,8.9,9.2,9.5,9.8,10.3,
     10.8,11.5,12.5,15.0,20.0,25.0,36.0,60.0};
static int turn_breaks[MAX_BREAKPOINTS] =
   {103,145,188,231,274,318,362,401,450,495,540,585,
    630,676,721,768,814,861,907,955,1002,1049,1097,1145,
    1193,1242,1291,1339,1389,1438,1487,1537,1587,1637,
    1688,1738,1789,1840,1891,1994,2098,2202,2307,2413,2520,
    2627,2735,2843,2952,3117,3283,3451,3619,3789,3960,4247,
    4537,4948,5542,7059,10176,13326,18374,40000};
static int use_breaks[MAX_BREAKPOINTS] = 
 {1,0,0,0,0,0,0,0,1,0,
   0,0,0,0,0,0,0,0,1,0,
   0,0,0,0,0,0,0,0,1,0,
   0,0,0,0,0,0,0,0,1,0,
   0,0,0,1,0,0,0,0,1,0,
   0,0,0,0,0,1,0,0,1,1,
   1,1,1,1}; 
 /* {0,0,0,0,0,0,0,0,0,0,
   1,1,1,1,1,1,1,1,1,1,
   1,1,1,1,1,1,1,1,1,1,
   1,1,1,1,1,1,1,1,1,1,
   1,1,1,1,1,1,1,1,1,1,
   1,1,1,1,1,1,1,1,1,1,
   1,1,1,1}; */
 

BOOSTER_RAMP *get_booster_ramp() {
  static int firstcall = 1;
  int i;
  if(!firstcall) return(&s_bramp);
  
  s_bramp.num_brkpts=0;
  for(i=0;i<MAX_BREAKPOINTS;i++) {
     s_bramp.time_breaks[i] = time_breaks[i];
     s_bramp.turn_breaks[i] = turn_breaks[i];
     s_bramp.use_breaks[i] = use_breaks[i];
     if(s_bramp.use_breaks[i]) {
        s_bramp.ipnt[s_bramp.num_brkpts] = i;
        s_bramp.t[s_bramp.num_brkpts] = time_breaks[i];
        s_bramp.turn[s_bramp.num_brkpts] = turn_breaks[i];
        s_bramp.p[s_bramp.num_brkpts] = booster_t2p(
              s_bramp.t[s_bramp.num_brkpts]);
        s_bramp.num_brkpts++;
     }
  }
  firstcall=0;
  return (&s_bramp);
}
/************************************************************/
/* Return the momentum for any time in the cycle.  Is there */
/* a better way to do this?                                 */
/************************************************************/
extern "C" float booster_t2p(float t) {
  static float pinit = .95426;   /* p @ KE = 400 MeV */
  static float pfinal = 8.88889; /* p@ KE = 8 GeV */
  static float t0 = 2.0;         /* 2 ms injection offset */
  float p;
  p = ((pfinal-pinit)/2.)*(1.-cos(2*PI*.015*(t-t0))) + pinit;
  return (p);
}
#endif  /* __BOOSRAMP_H__ */
  


  
