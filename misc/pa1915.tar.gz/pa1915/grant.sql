$isql/server=adbs/user="prebys"/pass="thatdawg"
use appdb
grant select,insert,update,delete on b_db_floats to PA1915
grant select,insert,update,delete on b_db_longs to PA1915
grant select,insert,update,delete on b_db_shorts to PA1915
grant select,insert,update,delete on b_bpm_data to pa1915
grant select,insert,update,delete on b_465_ftable to PA1915
go

