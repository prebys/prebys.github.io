#ifndef GEN_DEF_DEFINED
#define GEN_DEF_DEFINED

/****************************/
/*** System Include Files ***/
/****************************/

#include <stdio.h>			/* LF: for fgets */
#include <stdlib.h>			/* LF: for malloc and free */
#include <string.h>
#include <time.h>			/* LF: for time calls */
#include <psldef.h>			/* for timer calls */
#include <math.h>
#include "cnsparam.h"
#include "cns_data_structs.h"
#include "extchrset.h"
#include "acnet_errors.h"
#include "tclk_events.h"                            
#include "dbprops.h"
#include "ul_cbsaux/auxlib.h"		/* AUX defs */
#include "diolib.h"			/* DIO defs */
#include "cbslib.h"			/* CBS defs */
#include "clib.h"			/* CLIB defs */
#include "macro.h"
#include "context.h"

#define RING_SIZE 48
#define NUM_CORRECTORS 24
#define HORZ 0
#define VERT 1
#define	GET	0
#define	SET	1
#define	INVALID	-1
#define MAX_BREAKPOINTS 64
#define MAX_PASSES  20

#define MYERR 1

#endif




