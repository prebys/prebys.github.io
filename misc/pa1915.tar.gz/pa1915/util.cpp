#include "gen.h"
#include "lib465.h"
#include "otable.h"
#include "obc.h"
#include "util.h"
#include "corr.h"
#include "model.h"

#define NUM_SEC 6
int		pickit[4];
int		gpd;

static int	bkgd_wid[2];
static  int	gmdat = 0x30;
static short	prop[NUM_CORRECTORS] = { PRSET, PRSET, PRSET, PRSET,
				  PRSET, PRSET, PRSET, PRSET,
				  PRSET, PRSET, PRSET, PRSET,
				  PRSET, PRSET, PRSET, PRSET,
				  PRSET, PRSET, PRSET, PRSET,
				  PRSET, PRSET, PRSET, PRSET };
static short		last_wid;

static int 			gx_screen[2] = {GXPA_1,GXPA_2};




//  definitions of extern variables in util.h


char	h_correctors[NUM_CORRECTORS][DEVICE_NAME_LEN + 1] = {
  		"B:HS1   ", "B:HS2   ",
  		"B:HS3   ", "B:HS4   ",
  		"B:HS5   ", "B:HS6   ",
  		"B:HS7   ", "B:HS8   ",
  		"B:HS9   ", "B:HS10  ",
  		"B:HS11  ", "B:HS12  ",
  		"B:HS13  ", "B:HS14  ",
  		"B:HS15  ", "B:HS16  ",
  		"B:HS17  ", "B:HS18  ",
  		"B:HS19  ", "B:HS20  ",
  		"B:HS21  ", "B:HS22  ",
  		"B:HS23  ", "B:HS24  " };
char	v_correctors[RING_SIZE][DEVICE_NAME_LEN + 1] = {
  		"B:VL1   ", "B:VL2   ",
  		"B:VL3   ", "B:VL4   ",
  		"B:VL5   ", "B:VL6   ",
  		"B:VL7   ", "B:VL8   ",
  		"B:VL9   ", "B:VL10  ",
  		"B:VL11  ", "B:VL12  ",
  		"B:VL13  ", "B:VL14  ",
  		"B:VL15  ", "B:VL16  ",
  		"B:VL17  ", "B:VL18  ",
  		"B:VL19  ", "B:VL20  ",
  		"B:VL21  ", "B:VL22  ",
  		"B:VL23  ", "B:VL24  " };
char	h_diff_pos[RING_SIZE][DEVICE_NAME_LEN + 1] = {
  		"B:HP1SD ", "B:HP2SD ",
		"B:HP3SD ", "B:HP4SD ",
		"B:HP5SD ", "B:HP6SD ",
		"B:HP7SD ", "B:HP8SD ",
		"B:HP9SD ", "B:HP10SD",
		"B:HP11SD", "B:HP12SD",
		"B:HP13SD", "B:HP14SD",
		"B:HP15SD", "B:HP16SD",
		"B:HP17SD", "B:HP18SD",
		"B:HP19SD", "B:HP20SD",
		"B:HP21SD", "B:HP22SD",
		"B:HP23SD", "B:HP24SD" };
char	v_diff_pos[RING_SIZE][DEVICE_NAME_LEN + 1] = {
		"B:VP1LD ", "B:VP2LD ",
		"B:VP3LD ", "B:VP4LD ",
		"B:VP5LD ", "B:VP6LD ",
		"B:VP7LD ", "B:VP8LD ",
		"B:VP9LD ", "B:VP10LD",
		"B:VP11LD", "B:VP12LD",
		"B:VP13LD", "B:VP14LD",
		"B:VP15LD", "B:VP16LD",
		"B:VP17LD", "B:VP18LD",
		"B:VP19LD", "B:VP20LD",
		"B:VP21LD", "B:VP22LD",
		"B:VP23LD", "B:VP24LD" };


/* Taken from the B11 parameter page.  Verified 11/5/01 EjP */
float	h_ratios[24][3] = { {2.468, 1.0, 2.915},
			    {1.762, 1.0, 2.0},
			    {2.479, 1.0, 2.0},
			    {2.304, 1.0, 2.304},
			    {2.71, 1.0, 2.84},
			    {2.74, 1.0, 2.74},
			    {2.35, 1.0, 2.31},
			    {2.97, 1.0, 2.98},
			    {3.89, 1.0, 3.89},
			    {2.76, 1.0, 2.76},
			    {2.12,1.0, 2.11},
			    {1.6, 1.0, 1.94},
			    {2.49, 1.0, 2.12},
			    {2.3,1.0, 2.3},
			    {2.73, 1.0, 2.73},
			    {3.68, 1.0, 3.68},
			    {2.74, 1.0, 2.74},
			    {2.74, 1.0, 2.74},
			    {2.88, 1.0, 2.88},
			    {3.46, 1.0, 3.46},
			    {2.65, 1.0, 2.65},
			    {2.14, 1.0, 2.14},
			    {3.37, 1.0, 3.41},
			    {2.74, 1.0, 2.74} };
float	v_ratios[24][3] = { {2.08, 1.0, 2.08},
			    {2.73, 1.0, 2.0},
			    {3.31, 1.0, 3.36},
			    {2.09, 1.0, 2.04},
			    {2.04, 1.0, 2.04},
			    {2.63, 1.0, 2.65},
			    {2.94, 1.0, 2.90},
			    {2.31, 1.0, 2.31},
			    {2.16, 1.0, 2.16},
			    {2.4, 1.0, 2.4},
			    {2.98, 1.0, 2.98},
			    {1.96, 1.0, 1.96},
			    {2.71, 1.0, 2.9},
			    {3.1, 1.0, 2.88},
			    {2.09, 1.0, 2.09},
			    {1.96, 1.0, 1.96},
			    {2.4, 1.0, 2.4},
			    {2.4, 1.0, 2.4},
			    {2.09, 1.0, 2.09},
			    {2.16, 1.0, 2.06},
			    {2.24, 1.0, 2.34},
			    {2.22, 1.0, 2.22},
			    {2.14, 1.0, 2.4},
			    {2.15, 1.0, 2.22} };

/* These bump calibrartions (in A/mm) were measured by E.Prebys
   at injection on 12/6/01. See Booster logs for details*/
   
float h_amps_to_mm[24] = {0.04276977,0.058041674,0.049077346,0.043252595,
                          0.037973722,0.039500711,0.041137027,0.035066802,
                          0.026097395,0.031707781,0.053126494,0.069939852,
                          0.044361636,0.045345304,0.037260601,0.030022817,
                          0.081017581,0.048395683,0.037169194,0.029004844,
                          0.038886296,0.051376901,0.030274591,0.03753472};
float v_amps_to_mm[24] = {-0.098202887,-0.10414497,-0.056993047,-0.153303695,
                          -0.155351872,-0.105708245,-0.106213489,-0.12704866,
                          -0.14114326,-0.114442664,-0.096144601,-0.105351875,
                          -0.075261534,-0.09237022,-0.15339776,-0.163158753,
                          -0.117096019,-0.122669284,-0.161629223,-0.145687646,
                          -0.124719381,-0.132855055,-0.129416332,-0.157133878};

/* Below are the old numbers which Herrup used.  I don't know where
   they came from, but some - particularly in the vertical plane -
   are off by almost a factor of two. EjP 12/7/01 */
   
/* float	h_amps_to_mm[24] = { 0.0356, 0.05742, 0.05378, 0.04473,
			     0.04076, 0.04, 0.04909, 0.03686,
			     0.02064, 0.03824, 0.0504, 0.05885,
			     0.03224, 0.04139, 0.03367, 0.02841,
			     0.033, 0.039, 0.03821, 0.02532,
			     0.0404, 0.04886, 0.03189, 0.03686 };
float	v_amps_to_mm[24] = { -0.15, -0.1641, -0.09943, -0.149,
			     -0.13883, -0.11875, -0.1175, -0.13316,
			     -0.14126, -0.12304, -0.11081, -0.13208,
			     -0.10288, -0.11672, -0.13443, -0.14091,
			     -0.1184, -0.12473, -0.14607, -0.14307,
			     -0.12784, -0.13267, -0.12211, -0.1479 }; */

int	bf[3] = {YELLOW, YELLOW*8+BLACK, YELLOW+blink};

short	cyc_num[MAX_CYC] = {0x14};


short		wi3 = -1;








extern "C" float fround(int num_digit_after_point, float x);

extern "C" int steer_scale_function(CURVE_LIMIT_DATA *);
extern "C" void steer_range_bounds(CURVE_LIMIT_DATA *);
extern "C" void init_steer(CURVE_POINT *,int *, int *, float *);
extern "C" void add_steer(CURVE_POINT *,int, float *);


/******************************************************************************/
/*+ void pltopt(void)
-*/	                     
/******************************************************************************/
extern "C" void pltopt(void)
{
 int		sts, row, col, num = 15;
 static char	gx[2][4] = {"GX1","GX2"};
 static char	symtyp[7][8] = {"POINT  ","CIRCLE ","SQUARE ","TRIANGL", 
                                "LXOBJ  ","CROSS  ","DIAMOND"};
 static int	valtype[15] = 
            {INP_LOGICAL,INP_LONG,INP_LONG,INP_LOGICAL,INP_LOGICAL,INP_LOGICAL,
             INP_LOGICAL,INP_LONG,INP_LONG,INP_LOGICAL,INP_COLOR,INP_COLOR,
             INP_LONG,INP_LONG,INP_LOGICAL};
 int		inp_gx, inp_symtyp;
 static  float	min[15] = {0.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0,
                        0., 0., 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
 static  float	max[15] = {1.0, 8.0, 8.0, 1.0, 1.0, 1.0, 1.0,
                        10.,10.,1.0, 7.0, 7.0, 12., 50.0, 1.};
 static void *ptr[] = 
     {(void *)&pltpar.gx, (void *)&pltpar.hmaxplts, (void*)&pltpar.vmaxplts,
      (void *)&pltpar.pile, (void *)&pltpar.bar, (void *)&pltpar.connect, 
      (void *)&pltpar.sym, (void *)&pltpar.symtyp, (void *)&pltpar.symsiz, 
      (void *)&pltpar.symfill, (void *)&pltpar.colors[0], 
      (void*)&pltpar.colors[1],
      (void *)&pltpar.amplim, (void *)&pltpar.mmlim, (void *)&pltpar.autolim};

static char	prompt[] =
"Graphics screen      \
no.plots in horizotal\
no.plots in vertical \
pile plots (no erase)\
plot style,bar       \
plot style,connect   \
plot style,symbol    \
plot symbol type(0:6)\
plot symbol size(0:9)\
plot symbol fill     \
plot primary color   \
plot secondary color \
corr plot limit(AMPS)\
BPM plot limit(MM)   \
Automatic calc limits";

  /* these call work behind the screen to make enum type */

 set_enumerated_strings_c(2, (char *)gx, 4, &inp_gx);
 valtype[0] = inp_gx;
 set_enumerated_strings_c(7, (char *)symtyp, 8, &inp_symtyp);
 valtype[7] = inp_symtyp;

 row = num; col = 21; cursor(0, &row, &col);
 sts = winput_c("Plot Options",row,col,prompt,21,min,max,ptr,num,valtype);
 return;
}


/******************************************************************************/
/*+ void cursor(short wid, int *h, int *w)
-*/                     
/******************************************************************************/
extern "C" void cursor(short wid, int *h, int *w)
{
 int row, col;
 if (window_interrupt_cursor(&wid, &row, &col) == CBS_OK)
  {
   if ((row + *h) < PA_MAXROW) *h = row + 1;
   else *h = PA_MAXROW - *h;
   col -= *w / 2;
   if (col < 1) col=1;
   if ((col + *w) < PA_MAXCOL) *w = col;
   else *w = PA_MAXCOL - *w;
  }
 else *h = *w = WMNGR_CENTER;
}


/******************************************************************************/
/*+ float maxi(int n, float *data)
-*/                     
/******************************************************************************/
extern "C" float maxi(int n, float *data)
{
 int 	i;
 float 	max = -999999.;
 for (i = 0; i < n; i++)
  {
   if (data[i] > max)max = data[i];
  }
 return(max);
}


/******************************************************************************/
/*+ float mini(int n, float *data)
-*/                     
/******************************************************************************/
extern "C" float mini(int n, float *data)
{
 int 	i;
 float 	min = 999999.;
 for (i = 0; i < n; i++)
  {
   if (data[i] < min)min = data[i];
  }
 return(min);
}


/******************************************************************************/
/*+ void plt_limits(int ndat, float *data, float *limits)
-*/                     
/******************************************************************************/
extern "C" void plt_limits(int ndat, float *data, float *limits)
{
 float		dx;
 limits[0] = mini(ndat, data);
 limits[1] = maxi(ndat, data);
 dx = (limits[1] - limits[0]) * 0.1;
 if (dx < 0.01) dx = 0.01;
 limits[0] -= dx;
 limits[1] += dx;
 return;
}


/******************************************************************************/
/*+ float calc_ave(int n, char *stat, float *data)
-*/                     
/******************************************************************************/
extern "C" float calc_ave(int n, char *stat, float *data)
{
 int 		i, m = 0;
 float 		sum = 0.;
 for (i = 0; i < n; i++) {
    if (!stat[i]) {
       sum += data[i];
       m++;
     }
  }
 if (m > 0)return(sum / m);
 else return(0.);
}


/******************************************************************************/
/*+ float calc_rms(int n, char *stat, float *data)
-*/                     
/******************************************************************************/
extern "C" float calc_rms(int n, char *stat, float *data)
{
 int 		i, m = 0;
 float 		sum = 0.;
 for (i = 0; i < n; i++) {
    if (!stat[i]) {
       sum += data[i] * data[i];
       m++;
     }
  }
 if (m > 0) return(sqrt(sum / m));
 else return(0.);
}


/******************************************************************************/
/*+ char test_bit(int jbit, char w)
-*/                     
/******************************************************************************/
extern "C" char test_bit(int jbit, char w)
{
 unsigned char x = 1, y, ww;
 ww = w;
 x <<= jbit;
 y = ww & x;
 y >>= jbit;
 return(y);
}


/******************************************************************************/
/*+ short rounding(float x)
-*/                     
/******************************************************************************/
extern "C" short rounding(float x)
{
 short		i;
 float		dif;

 i = (short)x;
 dif = x - (float)i; 
 if (fabs(dif) < 0.5)return(i);
 else return(i + ((dif > 0) ? 1 : -1));
}


/******************************************************************************/
/*+ void del_window(short *wid)
-*/                     
/******************************************************************************/
extern "C" void del_window(short *wid)
{
 int	last_row, last_col;
 short	wi;
 hilite_window_delete_c(*wid);
 if (*wid > 0)
  {
   window_menu_bar_delete_c(*wid);
   window_delete_c(*wid,-1,-1);
  }
 wi = WMNGR_BACKGROUND;
 if (window_interrupt_cursor(&wi,&last_row,&last_col) == CBS_OK)
  last_wid = WMNGR_BACKGROUND;
 else
  {
   if (window_interrupt_cursor(&last_wid,&last_row,&last_col) != CBS_OK)
    goto none;
  }
 window_set_cursor(&last_wid, &last_row, &last_col);
 none:last_wid = *wid;
 *wid = -1;
 return;
}


/******************************************************************************/
/*+ int edit_desire(int pl)
	skip file always go together with desire orbit file. File number is
	identified by desire file number.
-*/                     
/******************************************************************************/
extern "C" int edit_desire(void)
{
 int			i, j, jj, k, n, pl, inbar, sts;
 int			corr_num;
 short 			hwid, win, inwid, intyp;
 int 			inrow, incol, info;
 int	rows = 14;
 int	width;
 int			r2 = 3;
 int			nfile;
 int			displen = 12;
 int			gap = 3;
 int			read=TRUE,disp;
 static  char    	plnam[][5] = {"HORZ","VERT"};
 static  int	bits[] = {1, 2, 4}, co[] = {5, 6, 7};
 static  int	clr[] = {GREEN,RED};
 static  int	c0 = 2, c1 = 8;
 static  char	ny[] = ".B";
 static  char hv[2]     ={'H','V'};
 static  char lshort[2] = {'L','S'}; 
 static char *steer_yaxis[]={"Horzontal Steer (mm)","Vertical Steer (mm)"};
 
 GEN_DB_STRUCT          de_tmp, sk_tmp;
 char			mess[80];

 int	test_col_pos;
 int	test_col_skip;
 static int last_plane = -1;

 static int zero_steer=TRUE;
 static CURVE_POINT steer[RING_SIZE];  /* array of steering deltas */
 static int nsteer;

 pl = setp.plane;
 if(pl!=last_plane) zero_steer=TRUE;
 last_plane = pl;
 
 width = c1 + 4 * ( displen + gap ) - 1;
 sprintf(mess,"Desired Positions and ...(skip loc, bad ced, bad bpm)");
 sprintf(mess,"Desired Positions(and skip loc, bad ced, bad bpm)");
 sts = window_construct_c(2, WMNGR_CENTER_IT,rows+2,width+2,
                          FALSE,BLUE,CYAN,mess,&win);
 if (sts) return(util_errpost(sts, "window_construct",NULL));
 window_set_popup_c(win);
 sts = window_menu_bar_create_c(win,
    "  FILE-           \\ READ \\ SAVE \\ STEER \\ RESTORE \\ RETURN ",
    0,1,WHITE);
 hilite_create_c(win,r2,2,21,width-2,1,&hwid,width-2,0,1,HILITE_ROW_MAJOR,TRUE);
 while (TRUE)
  {
   window_intype(&inwid,&intyp,&inrow, &incol,&info);
   switch (intyp)
    {
     case INTTRM:
      util_trm();
     case INTKBD:
      if (inwid != win) goto ret;
      else if (inrow == 1) {
         inbar = window_menu_bar_update_c(win);
         if (inbar == 1) {
            /* here is the only place to select different des file */
            nfile = gen_hdr_sel(DESOB,0,pl,0,&deso.hdr,&k,FALSE);
            if (nfile > 0 && k >= 0) read = TRUE;
          }
         else if (inbar == 2) {
	    read=TRUE;
          }
         else if (inbar == 3) {
            nfile = gen_hdr_sel(DESOB,0,pl,0,&deso.hdr,&k,TRUE);
            if (nfile > 0 && k >= 0) {
               inptxt_c(WMNGR_CENTER,WMNGR_CENTER,
                        "title",5,deso.hdr.title,-TIT_LEN);
               deso.hdr.fid = k;
               desob_w(&deso,&skip,TRUE);
             }
             /* zero steering array */
             read = zero_steer = TRUE;
            }
         else if (inbar == 4) {
            curve_editor_init(steer_scale_function,steer_range_bounds);
            sts = curve_editor(nsteer,steer,
               RING_SIZE,"Period (L,S)",steer_yaxis[pl],
                 CURVE_OPT_Y_MOVE_ONLY,NULL,NULL);
            /* If the user cancelled out, then rezero the steering array */

            if(sts != DIO_OK) zero_steer = TRUE;
            read=TRUE; /* Reading in will automatically apply the steering */
            disp=TRUE;
           }
         else if (inbar == 5) {
            memcpy(&deso,&de_tmp,sizeof(GEN_DB_STRUCT));
            memcpy(&skip,&sk_tmp,sizeof(GEN_DB_STRUCT));
            disp = TRUE;
          }
         else if (inbar == 6) goto ret;
         else goto out;
       }
      else {
	if ( ( inrow < r2 ) || ( inrow > r2 + 12 ) )goto out;
	for ( i = 0; i < 4; i++ )
	  {
	    n = i * 12 + inrow - r2;
	    test_col_pos = c0 + 4 + i * 16;
	    if ( ( incol > test_col_pos ) &&
		( incol < ( test_col_pos + 5 ) ) )
	      {
               window_input_value_c(win,inrow,test_col_pos + 1,
				    (void *)&deso.x.floats[n],
                                      CNV_FLOAT,5,RED);
               window_display_value_c(win,inrow,test_col_pos + 1,
				      (void *)&deso.x.floats[n],
                                      CNV_FLOAT,4,GREEN);
	      }
	  }
	test_col_skip = ( incol - 1 - 10 ) % 16;
	if ( test_col_skip == 1 )k=0;
	else if ( test_col_skip == 2 )k=1;
	else if ( test_col_skip == 3 )k = 2;
	else goto out;
	if ( ( incol > 11 ) && ( incol < 15 ) )j=0;
	if ( ( incol > 27 ) && ( incol < 31 ) )j=1;	
	if ( ( incol > 43 ) && ( incol < 47 ) )j=2;	
	if ( ( incol > 59 ) && ( incol < 63 ) )j=3;	
	n = inrow - r2 + j * 12;
	cor->plane_svd_setup_flag[setp.plane] = INVALID;
	j = skip.x.longs[n] & bits[k];
	j &= ~bits[k];
	j |= bits[k];
	(((skip.x.longs[n] & bits[k] ) != 0 ) ?
	 (skip.x.longs[n] &= ~bits[k]) : (skip.x.longs[n] |= bits[k]));
	(((skip.x.longs[n] &bits[k]) != 0) ? (jj=1) : (jj=0));
	window_display_value_c ( win, inrow, incol,
				(void *)&ny[jj], CNV_CHAR, 1, clr[jj] );
	desob_w(&deso,&skip,FALSE);
	hilite_resume_c(hwid);
       }
      out:break;

     case INTPER:

      if (read) {
	 read = FALSE;
       	 hilite_delete_c(hwid);
         deso.hdr.plane = INVALID;
         if (!desob_r(pl,deso.hdr.fid,&deso,&skip)) {
            memcpy(&de_tmp, &deso, sizeof(GEN_DB_STRUCT));
            memcpy(&sk_tmp, &skip, sizeof(GEN_DB_STRUCT));
            sprintf(mess,"%.4s",plnam[pl]);
            if (deso.hdr.fid == DESOB_FID_DEF) 
               sprintf(mess,"FILE-%d(default)",deso.hdr.fid);
            else sprintf(mess,"FILE-%d",deso.hdr.fid);
            menu_bar_change_entry_c(win,1,mess);
            if (deso.hdr.fid == DESOB_FID_DEF) 
               sprintf(mess,"DESIRE-FILE-%d(default)",deso.hdr.fid);
            else sprintf(mess,"DESIRE-FILE-%d",deso.hdr.fid);
            menu_bar_change_entry_c(0,2,mess);
            disp = TRUE;
            /* Preserve the current steering */
            if(zero_steer) {
               init_steer(steer,&nsteer,skip.x.longs,NULL);
               zero_steer=FALSE;
            }
            add_steer(steer,nsteer,deso.x.floats);
          }
       }
      if (disp) {
         disp = FALSE;
         table_erase(win,r2,rows,c1,width-c1);
	 n = 0;
	 for ( i = 0; i < 4; i++ )
	   {
	     for ( j = 0; j < 12; j++ )
	       {
	         k = j%2;
		 corr_num = 6 * i + j / 2 + 1;
		 sprintf(mess,"%c%c%2d",hv[pl],lshort[k],corr_num);
		 window_display_value_c ( win, r2 + j, c0 + i * 16, mess,
					 CNV_CHAR, 4, GREEN );
		 window_display_value_c ( win, r2 + j, c0 + 5 + i * 16,
					 (void *)&deso.x.floats[n],
					 CNV_FLOAT, 4, GREEN );
		 for ( k = 0; k < 3; k++ )
		   {
		     ((skip.x.longs[n] & bits[k]) != 0) ? (jj=1) : (jj=0);
		     window_display_value_c ( win, r2 + j,
					     c0 + 5 + i * 16 + co[k],
					     (void *)&ny[jj], CNV_CHAR,
					     1, clr[jj] );
		   }
		 n++;
	       }
	   }
       }
      break;
    }
  }
 ret:hilite_delete_c(hwid);
 window_menu_bar_delete_c(win);
 window_intype_put_data_c(win,0,rows,1,CLIB_DEFAULT_ARG);
 window_delete_c(win,-1,-1);
 /* If we've messed with the desire file, then we need to recalculate the
    rest of stuff */
    
 cor->flag[0]=TRUE;
 cor->flag[1]=cor->flag[2]=cor->flag[3]=FALSE;
 return(0);
}


/******************************************************************************/
/*+ int edit_ring_data(char *title, int pl, int dattyp, int datlen, void *dat, 
               int displen) 
-*/                     
/******************************************************************************/
extern "C" int edit_ring_data(char *title, int pl, int dattyp, int datlen, void *dat, 
               int displen) 
{
 int			i, j, n, sts;
 short 			hwid, win, inwid, intyp;
 int     		inrow, incol, info;
 int			row, col, sec;
 int			rows = 23,  width;
 int		        r2 = 3;
 int   			gap = 2;
 char			*datptr, *datptr0;
 static  char	sec_nam[2][13] = {"H1H2H3H4H5H6","V1V2V3V4V5V6"};
 static  int	sec_ptr[2][6] = {{0,16,32,52,68,84}, {0,15,31,52,67,83}};
 static  int	sec_row1[2][6] = {{0,1,1,0,1,1}, {0,0,0,0,0,0}};
 static  int	sec_rows[2][6] = {{16,16,20,16,16,20}, {15,16,21,15,16,21}};
 static  int	c0 = 2, c1 = 5;
 width = c1+6*(displen+gap)-1;
 sts = window_construct_c(2, WMNGR_CENTER_IT,rows+2,width+2,
                          FALSE,BLUE,CYAN,title,&win);
 if (sts) return(util_errpost(sts, "window_construct",NULL));
 window_set_popup_c(win);
 n = sec_row1[pl][1];
 for (i = 0; i < sec_rows[pl][0]+sec_row1[pl][0]; i++) {
    window_display_value_c(win,r2+i,c0,(void *)&n,
                        CNV_LONG,2,CYAN,gmdat,CNV_LEFT_JUSTIFY);
    n += 2;
  }
 for (i = 0; i < NUM_SEC; i++) {
    window_tvm_c(win,r2-1,c1+2+i*(displen+gap),
                 (char *)&sec_nam[pl][2*i],2,CYAN);
  }

 datptr0 = (char *)dat;
 for (i = 0; i < NUM_SEC; i++) {
    row = r2+sec_row1[pl][i];
    datptr = datptr0 + sec_ptr[pl][i]*datlen;
    col = c1+i*(displen+gap);
    for (j = 0; j < sec_rows[pl][i]; j++) {
       window_display_value_c(win,row+j,col,
                              (void *)datptr,dattyp,displen,GREEN);
       datptr += datlen;
     }
  }
 hilite_create_c(win,r2,2,21,width-2,1,&hwid,width-2,0,1,HILITE_ROW_MAJOR,TRUE);
 while (TRUE)
  {
   window_intype(&inwid,&intyp,&inrow, &incol,&info);
   switch (intyp)
    {
     case INTTRM:
      util_trm();
     case INTKBD:
      if (inwid != win) goto ret;
      else {
         col = (incol - c1) % (displen + gap);
         if (col < displen+1) {
            sec = (incol - c1) / (displen + gap);
            row = inrow - r2;
            if (row < sec_row1[pl][sec]) goto out;
            if (row > sec_row1[pl][sec]+sec_rows[pl][sec]) goto out;
            datptr = datptr0+datlen*(sec_ptr[pl][sec]+row-sec_row1[pl][sec]);
            col = c1+sec*(displen+gap);
            window_input_value_c(win,inrow,col,(void *)datptr, 
                          dattyp, displen, WHITE);
            window_display_value_c(win,inrow,col,(void *)datptr, 
                          dattyp, displen, GREEN);
          }
       }
      out:break;
    }
  }
 ret:hilite_delete_c(hwid);
 window_delete_c(win,-1,-1);
 return(0);
}


/******************************************************************************/
/*+ int my_wmenu_c(int row, int col, int n_items, int txt_len, char *item_txt,
		char *inp_txt, int *item)
	This routine make the item index an longword and counting from 0
        It also automatically calculates the menu staging position if the 
	passed row or col numbers are all 0.
-*/
/******************************************************************************/
extern "C" int my_wmenu_c(int row, int col, int n_items, int txt_len, char *item_txt,
		char *inp_txt, int *item)
{
 int			sts;
 short 			i;

 if (row == 0 && col == 0) {
    row = n_items; col = txt_len; cursor(0, &row, &col);
  }
 i = *item+1;
 sts = wmenu_c(row,col,n_items,txt_len,item_txt,inp_txt,&i);
 if (sts) *item = i-1;
 return(sts);
}



/******************************************************************************/
/*+ int disp_data(char *title, int nrow, int ncol, char *captions, int ndat, 
               void *dat, int dattyp, int displen, int gap, int color)
*	plot data of different type in ncol as a group on one row, total nrow.
-*/
/******************************************************************************/
extern "C" int disp_data(char *title, int nrow, int ncol, char *captions, int ndat, 
              void *dat, int nbyt, int dattyp, int displen, int gap, int color)
{
 int 			i, j, len, sts;
 short 			win, inwid, intyp;
 int 			inrow, incol, info;
 int 			firstrow = 2, lastrow = 18, scroll = FALSE;
 int			co[12];
 char			*datptr;

 if (ndat < ncol) return (util_errpost(DIO_GENERR, "disp_data: no data",NULL));
 for (j = 0; j < ncol+1; j++) co[j] = 1 + j * (displen + gap);
 lastrow = firstrow + nrow - 1;
 if (lastrow > 18) {
    lastrow = 18;
    scroll = TRUE;
  }
 sts = window_construct_c(3, WMNGR_CENTER, lastrow + 2, 
    	           (displen + gap) * (ncol + 1) + 2, FALSE, BLUE, 
                   tv_colors(GREEN,BLACK),
		   title, &win, TRUE, scroll);
 if (sts) return (util_errpost(sts, "disp_data:window construct",NULL));
 window_set_popup_c(win);
 if (scroll) {
    window_enable_scroll_io_c(win);
    window_set_scroll_region_c(win, firstrow, lastrow);
    window_enable_scroll_status_c(win, WMNGR_DISPLAY_WHEN_NEEDED);
  }
 len = strlen(captions) / ncol;
 for (j = 0; j < ncol; j++) 
    window_tvm_c(win, 1, co[1+j], (char *)&captions[len*j], len, WHITE);
 datptr = (char *) dat;
 for (i = 0; i < nrow; i++) {
    window_display_value_c(win, firstrow + i, co[0], &i, CNV_LONG, 3, WHITE);
    for (j = 0; j < ncol; j++) {
       window_display_value_c(win, firstrow + i, co[1+j], 
                           (void *)datptr, dattyp, displen, color);
       datptr += nbyt;
     }
  }
 while (TRUE) {
    window_intype(&inwid,&intyp,&inrow,&incol,&info);
    if (intyp == INTTRM) util_trm();
    if (intyp == INTKBD) {
       if (inwid != win) goto ret;
       else if (incol > co[1] && incol < co[1] + ncol * (displen + gap)) {
         i = window_row_to_entry_c(win, inrow);
         j = window_entry_to_row_c(win, i);
        }
     }
  }
 ret:del_window(&win);
 return(0);
}



/******************************************************************************/
/*+ void ring_wide_cap(short win,int pl,int row1,int col1,int displen,int gap)
-*/                     
/******************************************************************************/
extern "C" void ring_wide_cap(short win,int pl,int row1,int col1,int displen,int gap)
{
 int			i, n;
 static  char	sec_nam[2][13] = {"H1H2H3H4H5H6","V1V2V3V4V5V6"};

 for (i = 0; i < 6; i++) window_tvm_c(win,row1-1,col1+i*(displen+gap)+
                    (displen+gap)/2-1,(char *)&sec_nam[pl][2*i],2,CYAN);
 n = pl;
 for (i = 0; i < 21; i++) {
    window_display_value_c(win,row1+i,2,(void *)&n,
                           CNV_LONG,2,CYAN,gmdat,CNV_LEFT_JUSTIFY);
    n += 2;
  }
 return;
}


/******************************************************************************/
/*+ int ring_wide_input(short win,int inrow,int incol,int pl,char *ptr0,int dattyp,
                    int datlen,int row1,int col1,int displen,int gap)
{
-*/                     
/******************************************************************************/
extern "C" int ring_wide_input(short win,int inrow,int incol,int pl,char *ptr0,int dattyp,
                    int datlen,int row1,int col1,int displen,int gap)
{
 int			sec,row,col;
 char			*datptr;
 static  int	sec_ptr[2][6] = {{0,16,32,52,68,84}, {0,15,31,52,67,83}};
 static  int	sec_row1[2][6] = {{0,1,1,0,1,1}, {0,0,0,0,0,0}};
 static  int	sec_rows[2][6] = {{16,16,20,16,16,20}, {15,16,21,15,16,21}};

 col = (incol - col1) % (displen + gap);
 if (col > displen) return(MYERR);
 sec = (incol - col1) / (displen + gap);
 row = inrow - row1;
 if (row < sec_row1[pl][sec]) return(MYERR);
 if (row > sec_row1[pl][sec]+sec_rows[pl][sec]-1) return(MYERR);
 datptr = ptr0+datlen*(sec_ptr[pl][sec]+row-sec_row1[pl][sec]);
 col = col1+sec*(displen+gap);
 window_input_value_c(win,inrow,col,(void *)datptr,dattyp,displen,WHITE);
 window_display_value_c(win,inrow,col,(void *)datptr,dattyp,displen,GREEN);
 return(0);
}


/******************************************************************************/
/*+ void ring_wide_disp(short win,int pl,char *ptr0,int dattyp,int datlen,
                    int row1,int col1,int displen,int gap)
-*/                     
/******************************************************************************/
extern "C" void ring_wide_disp(short win,int pl,char *ptr0,int dattyp,int datlen,
                    int row1,int col1,int displen,int gap)
{
 int			i,j,row,col;
 char			*datptr;
 static  int	sec_ptr[2][6] = {{0,16,32,52,68,84}, {0,15,31,52,67,83}};
 static  int	sec_row1[2][6] = {{0,1,1,0,1,1}, {0,0,0,0,0,0}};
 static  int	sec_rows[2][6] = {{16,16,20,16,16,20}, {15,16,21,15,16,21}};

 for (i = 0; i < 21; i++) window_blank_c(win,row1+i,col1,(displen+gap)*6);
 for (i = 0; i < 6; i++) {
    row = row1+sec_row1[pl][i];
    datptr = ptr0 + sec_ptr[pl][i]*datlen;
    col = col1+i*(displen+gap);
    for (j = 0; j < sec_rows[pl][i]; j++) {
       window_display_value_c(win,row+j,col,(void *)datptr,dattyp,
                              displen,GREEN);
       datptr += datlen;
     }
  }
 return;
}


/******************************************************************************/
/*+ int table_design(int width,int numlen,int displen,int gap,int ndat,
                     int *cols,int *indent);
	determine data display format. cols - number of cols; indent -
	starting col; return number of rows, 0 if data is too big.
-*/                     
/******************************************************************************/
/*int table_design(int width,int numlen,int displen,int gap,int ndat,
                 int *cols,int *indent)
{
 *cols = width / (numlen+displen+2*gap);
 *indent = (width - *cols * (numlen+displen+2*gap)) / 2;
 return(ndat / *cols + 1);
}*/

/******************************************************************************/
/*+ void table_erase(short win,int row1,int rows,int width)
-*/                     
/******************************************************************************/
extern "C" void table_erase(short win,int row1,int rows,int col1,int cols)
{
 int			i;
 for (i = 0; i < rows; i++) window_blank_c(win,row1+i,col1,cols);
 return;
}


/******************************************************************************/
/*+ int ring_wide_dat(char *title,int pl,char *dat,int dtype,int dlen,
                  int displen,int dgap)
-*/                     
/******************************************************************************/
extern "C" int ring_wide_dat(char *title,int pl,char *dat,int dtype,int dlen,
                  int displen,int dgap)
{
 int			sts;
 short 			hwid, win, inwid, intyp;
 int 			inrow, incol, info;
 static  int	drows=21,drow1=2,dcol1=7;
 int			width;

 width = dcol1+6*(displen+dgap)-1;
 sts = window_construct_c(1, WMNGR_CENTER_IT,drow1+drows+1,width+2,
                          FALSE,BLUE,CYAN,
                          title,&win);
 if (sts) return(util_errpost(sts, "window_construct",NULL));
 window_set_popup_c(win);
 ring_wide_cap(win,pl,drow1,dcol1,displen,dgap);
 hilite_create_c(win,drow1,2,21,width-2,1,&hwid,width-2,0,1,
                 HILITE_ROW_MAJOR,TRUE);
 ring_wide_disp(win,pl,dat,dtype,dlen,drow1,dcol1,displen,dgap);
 while (TRUE)
  {
   window_intype(&inwid,&intyp,&inrow, &incol,&info);
   switch (intyp)
    {
     case INTTRM: util_trm();
     case INTKBD:
      if (inwid != win) goto ret;
      else {
         hilite_suspend_c(hwid,HILITE_ERASE_LAST);
         ring_wide_input(win,inrow,incol,pl,dat,dtype,dlen,
                         drow1,dcol1,displen,dgap);
         hilite_resume_c(hwid);
       }
    }
  }
 ret:hilite_delete_c(hwid);
 window_menu_bar_delete_c(win);
 window_intype_put_data_c(win,0,drows,1,CLIB_DEFAULT_ARG);
 window_delete_c(win,-1,-1);
 return(0);
}


/******************************************************************************/
/*+ void plt_ring_init1(int pl,int init, int screen, int *pid, int trow, int rows,  
                    char *tit, float *ylimits, char *yunit)
-*/                     
/******************************************************************************/
extern "C" void plt_ring_init1(int pl,int init,int last,int screen, int *pid, int trow, 
                    int rows,char *tit,float *ylimits,char *yunit)
{ 
 int 			i,j;
 float			x,xf;
 char			cbuf[6];
 static float		viw[4] = {.09, .08, .96, .97};

 wn_delete_c(*pid);
 if (init != 0) {
    wn_select_screen_c(gx_screen[screen]);
    wn_screen_init_c(tit,WN_HCMODE_DEFAULT,TRUE);
    wn_view_c(&bkgd_wid[screen], 0., 0., 1., 1.);
    wn_world_c(bkgd_wid[screen], 0., 0., 1., 1.);
  }

  /* determine where to plot */
 viw[3] = (WN_MAXROW  - trow) / WN_MAXROW; 
 viw[1] = viw[3] - rows / WN_MAXROW; 

  /* paint plot frame */
 wn_color_c(BLUE);
 wn_view_c(pid, viw[0], viw[1], viw[2], viw[3]-.2*CHY);
 wn_world_c(*pid, 0., ylimits[0], RING_SIZE+1, ylimits[1]);
 /* label axis */
 wn_active_c(*pid);
 wn_axis_label_c(VERT, 4, 2, TRUE, yunit, 1,BLUE, 5, CNV_FLOAT);
  /* write tit and ...*/
 wn_color_c(WHITE);
 wn_active_c(bkgd_wid[screen]);
 wn_text_c(viw[0]+(viw[2]-viw[0]-strlen(tit)*CHX)/2,viw[3],tit,strlen(tit));

 /* paint device name for the first one of each house */
 wn_color_c(BLUE);
/* CDAHadd */
 xf = (viw[2]-viw[0])/(24);
 j=0;
 for ( i = 1 ; i < 25 ; i++ ) {
    x = viw[0]+xf*j;
    wn_vector_c(x, viw[1]-1.2*CHY, x, viw[3]-.2*CHY);
    j += 1;
  }
 wn_vector_c(viw[2],viw[1]-1.2*CHY,viw[2],viw[3]-.2*CHY);
 if (!last) return;
 j=0;
 wn_color_c(WHITE);
 for (i = 1 ; i < 25 ; i++){
   x = viw[0]+xf*j;
   sprintf(cbuf,"%2d",i);
   j +=1;
   wn_text_c(x+.35*CHX,viw[1]-1.3*CHY,cbuf,2);
 }

 return;
}


/******************************************************************************/
/*+ void plt_ring_data1(int screen, int id, float *dat, char *stat, 
                   int *color, char *cap1,char *cap2,char *cap3)
-*/                     
/******************************************************************************/
extern "C" void plt_ring_data1(int screen, int id, float *dat, char *stat, 
                   int *color, char *cap1, char *cap2,char *cap3)
{
 int			i,l1,l2,l3;
 float			x;
 float			viw[4];
 static  int	clr[2] = {GREEN,RED};
 float			xf;


 wn_active_c(id);
 wn_clip_c(TRUE);

 wn_get_view_coords_c(id, &viw[0], &viw[1], &viw[2], &viw[3]);
 
 xf = ( viw[2] - viw[0] ) / 24;

 if (pltpar.bar) {
    for (i = 0; i < RING_SIZE; i++) {
      x = viw[0] + i + 0.5 * (float)(i) * xf + 0.25 * xf * RING_SIZE;
/*      if ( ( i % 2 ) == 0 ) x = i + 1 + xf;
      else if ( ( i % 2 ) == 1 ) x = i + 1 + xf;*/
      wn_color_c(clr[stat[i]]);
      wn_vector_c ( x, 0.0, x, dat[i] );
     }
  }
 if (pltpar.connect) {
    for (i = 0; i < RING_SIZE-1; i++) {
       /*wn_color_c(color[stat[i]]);*/
       wn_vector_c((float)(i+1), dat[i], (float)(i+2), dat[i+1]);
     }
  }
 if (pltpar.sym) {
    wn_set_plot_symbol_c(pltpar.symtyp, pltpar.symsiz); 
    wn_fill_mode_c(pltpar.symfill);
    for (i = 0; i < RING_SIZE; i++) {
       wn_color_c(clr[stat[i]]);
       wn_symbol_c((float)(i+1), dat[i]);
     }
  }

 wn_active_c(bkgd_wid[screen]);
 wn_color_c(WHITE);
 l1 = strlen(cap1);l2 = strlen(cap2);l3 = strlen(cap3);
 wn_text_c(viw[2]-(l1+l2+l3+4)*CHX,viw[1] - 2.* CHY,cap1,l1);
 wn_text_c(viw[2]-(l2+l3+2)*CHX, viw[1] - 2. * CHY,cap2,l2);
 wn_text_c(viw[2]-l3*CHX, viw[1] - 2. * CHY,cap3,l3);
 return;
}


/******************************************************************************/
/*+ void table_ring_data1(int pl,int init, int screen, int trow,int dtyp, 
                      int dlen, void *dat,int displen,char *stat, int *color, 
                      char *tit, char *cap1, char *cap2,char *cap3)
-*/                     
/******************************************************************************/
extern "C" void table_ring_data1(int pl,int init, int screen, int trow,int dtyp, 
                      int dlen, void *dat,int displen,char *stat, int *color, 
                      char *tit,char *cap1,char *cap2,char *cap3)
{
 int			i, j, l1,l2,l3,n;
 float			x, x0, y0, y1, y,collen;
 static  float	viw[4] = {.09, .08, .96, .97};
 char			*datptr;

 int	corr_num;
 int	m;
 char	mess[4];

 datptr = (char *) dat;
 if (init != 0) {
    wn_select_screen_c(gx_screen[screen]);
    wn_screen_init_c(tit,WN_HCMODE_DEFAULT,TRUE);
    wn_view_c(&bkgd_wid[screen], 0., 0., 1., 1.);
    wn_world_c(bkgd_wid[screen], 0., 0., 1., 1.);
  }

  /* determine where to put table */
 y0 = (WN_MAXROW - trow) / WN_MAXROW; 
  /* write tit and section mark*/
 wn_active_c(bkgd_wid[screen]);
 wn_color_c(WHITE);
 wn_text_c(viw[0]-2*CHX,y0,tit,strlen(tit));
 collen = (viw[2]-viw[0]-8*CHX)/4;

 datptr = (char *)dat;
 n = 0;
 x0 = viw[0]+(collen-7*CHX)/2+4*CHX;
 y0 -= 1.02*CHY;
 for ( i = 0 ; i < 4 ; i++ )
   {
     x = x0 + i * collen;
     y1 = y0 - 1.02 * CHY;
     for ( j = 0 ; j < 12 ; j++ )
       {
	 m = 0;
	 if ( ( j % 2 ) == 0 )m=0;
	 else if ( ( j % 2 ) == 1 )m=1;
	 corr_num = 6 * i + j / 2 + 1;
	 y = y1 - j * 1.02 * CHY;
	 wn_color_c ( color[stat[n]] );
	 if ( pl == 0 )
	   {
	     if ( m == 0 )
	       {
		 sprintf ( mess, "HL%2d", corr_num );
	       }
	     else if ( m == 1 )
	       {
		 sprintf ( mess, "HS%2d", corr_num );
	       }
	   }
	 else if ( pl == 1 )
	   {
	     if ( m == 0 )
	       {
		 sprintf ( mess, "VL%2d", corr_num );
	       }
	     else if ( m == 1 )
	       {
		 sprintf ( mess, "VS%2d", corr_num );
	       }
	   }
	 wn_display_value_c ( x, y, mess, CNV_CHAR, 4 );
	 wn_display_value_c ( x + 6.02 * CHX, y, (void *)datptr,
			     dtyp, displen );
	 datptr += dlen;
	 n++;
       }
   }

 wn_color_c(WHITE);
 l1 = strlen(cap1);l2 = strlen(cap2);l3 = strlen(cap3);
 wn_text_c(5.0*collen-(l1+l2+l3+4)*CHX,y-1.2*CHY,cap1,l1);
 wn_text_c(5.0*collen-(l2+l3+2)*CHX,y-1.2*CHY,cap2,l2);
 wn_text_c(5.0*collen-l3*CHX,y-1.2*CHY,cap3,l3);

 return;
}


/******************************************************************************/
/*+ void disp_bpm_1(int pl,BPM_HDR_STRUCT* h,float* dat,char* stat)
	plot type 1: one plane data, upper plot and lower table
-*/                     
/******************************************************************************/
extern "C" void disp_bpm_1(int screen,int pl,BPM_HDR_STRUCT* h,float* dat,char* stat)
{
 int			pid;
 float			limits[2];
 float			x;
 char			title[80],cap1[20],cap2[20],cap3[20];
 char			date[21];
 static  int	clr[2] = {GREEN,RED};
 static  char    	plnam[][5] = {"horz","vert"};
 static  char    	typnam[][9] = {"profile","snapshot","display","flash",
                                      "fake","two-turn"};


 if (get_lattice(1,pl,&lat)) return;
 limits[0] = - (float)pltpar.mmlim;
 limits[1] = (float)pltpar.mmlim;
 if (pltpar.autolim) plt_limits(RING_SIZE,dat,limits);
 clinks_to_date(h->date, date);
 sprintf(title,"%.*s %.4s %.7s %2X %5.3f sec %.20s", strlen(h->title),h->title,
         plnam[pl],typnam[h->type],h->tclk,h->time,date);
 plt_ring_init1(pl,TRUE,TRUE,screen,&pid,2,16,title,limits,"MM");
 x = calc_ave(RING_SIZE,stat,dat);
 sprintf(cap1,"AVG=%7.3f",x);
 x = calc_rms(RING_SIZE,stat,dat);
 sprintf(cap2,"RMS=%7.3f",x);
 x = calc_dpop(RING_SIZE,dat,stat,lat.disp_b);
 sprintf(cap3,"dp/p=%7.4f",x);
 plt_ring_data1(screen,pid,dat,stat,pltpar.colors,cap1,cap2,cap3);
 table_ring_data1(pl,FALSE,screen,21,CNV_FLOAT,4,dat,7,stat,clr,
                  "",cap1,cap2,cap3);
 return;
}


/******************************************************************************/
/*+ void disp_bpm_2(int screen,BPM_HDR_STRUCT* h,float* x,char* xstat,
                float* y,char* ystat)
	plot type 2: plot data for both plane, upper x and lower table
-*/                     
/******************************************************************************/
extern "C" void disp_bpm_2(int screen,BPM_HDR_STRUCT* h,float* x,char* xstat,
                float* y,char* ystat)
{
 int			pid;
 float			limits[2];
 char			cap1[80];
 char			date[21];
 static  char    	plnam[][5] = {"horz","vert"};
 static  char    	typnam[][9] = {"profile","snapshot","display","flash",
                                      "fake","two-turn"}; 


 limits[0] = - (float)pltpar.mmlim; limits[1] = (float)pltpar.mmlim;
 if (pltpar.autolim) plt_limits(RING_SIZE,x,limits);
 clinks_to_date(h->date, date);
 sprintf(cap1,"%.*s %.4s %.7s %2X %5.3f sec %.20s", strlen(h->title),h->title,
         plnam[HORZ],typnam[h->type],h->tclk,h->time,date);
 plt_ring_init1(HORZ,TRUE,TRUE,screen,&pid,2,18,cap1,limits,"MM");
 plt_ring_data1(screen,pid,x,xstat,pltpar.colors,"","","");

 limits[0] = - (float)pltpar.mmlim; limits[1] = (float)pltpar.mmlim;
 if (pltpar.autolim) plt_limits(RING_SIZE,y,limits);
 clinks_to_date(h->date, date);
 sprintf(cap1,"%.*s %.4s %.7s %2X %5.3f sec %.20s", strlen(h->title),h->title,
         plnam[VERT],typnam[h->type],h->tclk,h->time,date);
 plt_ring_init1(VERT,FALSE,TRUE,screen,&pid,24,18,cap1,limits,"MM");
 plt_ring_data1(screen,pid,y,ystat,pltpar.colors,"","","");

 return;
}


/******************************************************************************/
/*+ void disp_bpm_3(int screen,BPM_HDR_STRUCT* h,float* x,char* xstat,
                float* y,char* ystat)
	plot type 2: table data for both plane, upper x and lower table
-*/                     
/******************************************************************************/
extern "C" void disp_bpm_3(int screen,BPM_HDR_STRUCT* h,float* x,char* xstat,
                float* y,char* ystat)
{
 char			cap1[80];
 char			date[21];
 static  char    	plnam[][5] = {"horz","vert"};
 static  char    	typnam[][9] = {"profile","snapshot","display","flash",
                                      "fake","two-turn"}; 
 static  int	clr[2] = {GREEN,RED};

 clinks_to_date(h->date, date);
 sprintf(cap1,"%.*s %.4s %.7s %2X %5.3f sec %.20s", strlen(h->title),h->title,
         plnam[HORZ],typnam[h->type],h->tclk,h->time,date);
 table_ring_data1(HORZ,TRUE,screen,1,CNV_FLOAT,4,x,7,xstat,clr,
                  cap1,"","","");
 sprintf(cap1,"%.*s %.4s %.7s %2X %5.3f sec %.20s", strlen(h->title),h->title,
         plnam[VERT],typnam[h->type],h->tclk,h->time,date);
 table_ring_data1(VERT,FALSE,screen,24,CNV_FLOAT,4,y,7,ystat,clr,
                  cap1,"","","");
 return;
}


/******************************************************************************/
/*+ void disp_bpm_4(int pl,BPM_HDR_STRUCT* h,float* dat,char* stat)
	plot type 4: display all profiles in one plot
-*/                     
/******************************************************************************/
extern "C" void disp_bpm_4(int screen,int pl,int npf,BPM_HDR_STRUCT* h,float* times, 
                float* dat,char* stat)
{
 int			rows;
 int			pid;
 int			plts,gx,k=0,n=0;
 float			limits[2];
 char			cap1[80];
 char			date[21];
 static  char    	plnam[][5] = {"horz","vert"};
 static  char    	typnam[][9] = {"profile","snapshot","display","flash",
                                      "fake","two-turn"}; 

 if (npf <= pltpar.vmaxplts) plts = npf;
 else plts = pltpar.vmaxplts;
 rows = (int)((WN_MAXROW - 2) / plts);
 limits[0] = - (float)pltpar.mmlim/(pl+1); 
 limits[1] = (float)pltpar.mmlim/(pl+1);
 clinks_to_date(h->date, date);
 gx = screen;
 while (n < npf) {
  sprintf(cap1,"%.*s %.4s %.7s %2X %5.3f sec %.20s", strlen(h->title),h->title,
            plnam[pl],typnam[h->type],h->tclk,times[n],date);
    if (pltpar.autolim) plt_limits(RING_SIZE,&dat[n*RING_SIZE],limits);
    plt_ring_init1(pl,(k?0:1),((k==plts-1 || n==npf-1)?1:0),
                   gx,&pid,rows*k+3,rows-2,cap1,limits,"MM");
		   // argument 7 above was "rows-1.3" which produced conversion error
		   //    on linux.  Sow replace with "rows-2" which assumed the vax
		   //     converted the double to int
    plt_ring_data1(screen,pid,&dat[n*RING_SIZE],&stat[n*RING_SIZE],
                   pltpar.colors,"","","");
    n++;
    k = n%pltpar.vmaxplts;
    if (k==0) (gx?(gx=0):(gx=1));
  }
}


/******************************************************************************/
/*+ void disp_corr ( int screen, int opt, int plane, float p_scal )
	display corrections
-*/                     
/******************************************************************************/
extern "C" void disp_corr ( int screen, int opt, int plane, float* data )
{
 int			i;
 int			pid;
 float			limits[2];
 char			cap1[80];
 char			date[21];
 char			stat[RING_SIZE];
 float 			dat[RING_SIZE];
 static  char    	plnam[][5] = {"horz","vert"};
 static  char    	unit[][6] = {"MM","uRAD","Raw-G","Amps"};
 static  int	clr[2] = {GREEN,RED};

 memset(stat,0,RING_SIZE);
 if (opt == 0) {       /* mm */
    limits[0] = - (float)pltpar.mmlim; limits[1] = (float)pltpar.mmlim;
    memcpy(dat,cor->dx1,4*RING_SIZE);
  }
 else if (opt == 1) {   /* uRad */
    limits[0] = - pltpar.glim; limits[1] = pltpar.glim;
    for (i=0;i<RING_SIZE;i++) dat[i] = cor->dthet[cor->curr_brkpt][i]*1000.;
  }
 else if (opt == 2) {   /* raw g */
    limits[0] = - pltpar.glim; limits[1] = pltpar.glim;
    for (i=0;i<RING_SIZE;i++) dat[i] = data[i];
  }
 else {		/* amps */
    limits[0] = - pltpar.amplim; limits[1] = pltpar.amplim;
    for (i=0;i<NUM_CORRECTORS;i++) {
      dat[i] = data[i];
     }
  }

 if (pltpar.autolim) plt_limits(RING_SIZE,dat,limits);
 clinks_to_date(cor->b1.hdr.date, date);
 sprintf(cap1,"corrections(%.*s) %.4s %.20s", strlen(unit[opt]),
         unit[opt],plnam[setp.plane],date);
 plt_ring_init1(setp.plane,TRUE,TRUE,screen,&pid,2,16,cap1,limits,
                unit[opt]);
 plt_ring_corr1(screen,pid,plane,dat,stat,pltpar.colors,"","","");
 table_ring_corr1(setp.plane,FALSE,screen,21,CNV_FLOAT,4,dat,7,stat,
                  clr,"","","","");
 return;
}


/******************************************************************************/
/*+ float calc_dpop(int n, float *x, char *stat, float *disper)
-*/                     
/******************************************************************************/
extern "C" float calc_dpop(int n, float *x, char *stat, float *disper)
{
 int		i;
 float		sum1 = 0., sum2 = 0.;

 for (i = 0; i < n; i++) {
    if (!stat[i]) {
       sum1 += x[i] * disper[i];      /* mm*m */
       sum2 += disper[i] * disper[i]; /* m*m */
     }
  }
  /* the bpm system is defined as outward positive, so need to flip sign */
 if (sum2 != 0.) return(- sum1 / (sum2 * 1000.));
 else return(0.);
}

/**************************************************************************/
/*+ int setup(void)
-*/
/**************************************************************************/
extern "C" int setup(void)
{
 int			iact,sts;
 int 			r1 = 3, c1 = 2;
 int			fid;
 GEN_DB_HDR_STRUCT	hdr;
 static  char	ctxt[][12] = {"  Recall","   Save","Lock/unlock"};

 sts = my_wmenu_c(3,2,3,12,(char *)ctxt,"",&iact);
 if (!sts) return(MYERR);
 if (iact == 0) {
    sts = setup_rw(GET);
    corr_disp_par(wi3,r1,c1);
  }
 else if (iact == 1) sts = setup_rw(SET);
 else if (iact == 2) {
    gen_hdr_sel(SETUP,0,0,0,&hdr,&fid,FALSE);
    if (fid < 0) sts = MYERR;
  }
 else sts = MYERR;

 return(sts);
}


/**************************************************************************/
/*+ int setup_rw(int rw)
	read/write setup pars from/to selected record. The possible number 
	of records has a maximum defined. When writting the routine
	'gen_rec_rw' tabke care of this.
-*/
/**************************************************************************/
extern "C" int setup_rw(int rw)
{
 int			sts;
 int			fid;
 GEN_DB_STRUCT		buf;
 int			GII_SLOTS = 32;


 gen_hdr_def(SETUP,0,0,0,0,&buf.hdr);
 if (rw == GET) {
      /* use .slot value as an indicator .... */
    if (setp.slot >= 0 && setp.slot < GII_SLOTS) {
       gen_hdr_sel(SETUP,0,0,0,&buf.hdr,&fid,FALSE);
       if (fid < 0) return(MYERR);
       sts = gen_rec_r(SETUP,&buf.hdr,(void *)&buf);
       if (sts) return(util_errpost(sts,"Err get setup data",NULL));
     }
    else {
       memset_longword_c(buf.x.longs,0,RING_SIZE);
       sts = gen_recent_rec_r(SETUP,&buf.hdr,(void *)&buf);
       if (sts) return(util_errpost(sts,"Err get setup data",NULL));
     }
    memcpy(&setp,buf.x.longs,sizeof(SETUP_STRUCT));
  }
 else if (rw == SET) {
    memset_longword_c(buf.x.longs,0,RING_SIZE);
    memcpy(buf.x.longs,&setp,sizeof(SETUP_STRUCT));
    memset ( buf.hdr.title, ' ', 20 * sizeof ( char ) );
    inptxt_c(6,2,"title",5,buf.hdr.title,TIT_LEN);
    buf.hdr.lock = 0;
    buf.hdr.tclk = 0;
    buf.hdr.plane = setp.plane;
    buf.hdr.slot = 0;
    buf.hdr.date = clinks_now ();
    buf.hdr.fid = 0;
    sts = gen_rec_w(SETUP,&buf);
    if (sts) return(util_errpost(sts,"Err writting setup data",NULL));
  }
 return(0);
}


/**************************************************************************/
/*+ int misc_par_rw(int rw)
	read/write misc pars from/to the single record.
-*/
/**************************************************************************/
extern "C" int misc_par_rw(int rw)
{
 int			sts;
 GEN_DB_STRUCT		buf;

 gen_hdr_def(MISCPAR,0,0,0,0,&buf.hdr);
 if (rw == GET) {
    sts = gen_rec_r(MISCPAR,&buf.hdr,(void *)&buf);
    if (sts) return(util_errpost(sts,"Err get misc pars",NULL));
    memcpy(&miscpar,buf.x.longs,sizeof(MISC_PAR_STRUCT));
  }
 else if (rw == SET) {
    memset_longword_c(buf.x.longs,0,RING_SIZE);
    memcpy(buf.x.longs,&miscpar,sizeof(MISC_PAR_STRUCT));
    sts = gen_rec_w(MISCPAR,&buf);
    if (sts) return(util_errpost(sts,"Err set misc pars",NULL));
  }
 return(0);
}


/**************************************************************************/
/*+ int plt_par_rw(int rw)
	read/write misc pars from/to the single record.
-*/
/**************************************************************************/
extern "C" int plt_par_rw(int rw)
{
 int			sts;
 GEN_DB_STRUCT		buf;

 gen_hdr_def(PLTPAR,0,0,0,0,&buf.hdr);
 if (rw == GET) {
    sts = gen_rec_r(PLTPAR,&buf.hdr,(void *)&buf);
    if (sts) return(util_errpost(sts,"Err get misc pars",NULL));
    memcpy(&pltpar,buf.x.longs,sizeof(PLT_PAR_STRUCT));
  }
 else if (rw == SET) {
    memset_longword_c(buf.x.longs,0,RING_SIZE);
    memcpy(buf.x.longs,&pltpar,sizeof(PLT_PAR_STRUCT));
    sts = gen_rec_w(PLTPAR,&buf);
    if (sts) return(util_errpost(sts,"Err set misc pars",NULL));
  }
 return(0);
}


/******************************************************************************/
/*+ int edit_lat(void)
-*/                     
/******************************************************************************/
extern "C" int edit_lat(void)
{
 int			i, j, n, inbar, pl, sts;
 static short 		hwid, win, inwid, intyp;
 int			rows = 14;
 int			width;
 int			displen = 12;
 int			gap = 3;
 static	int		l;
 static	int		corr_num;
 int 			inrow, incol, info;
 int			r2 = 3;

 char			*datptr0;
 int			dattyp, datlen;
 static  int	c0 = 2, c1 = 8;
 int			new_plane=TRUE,disp,disp_name=FALSE;
 static  char    	plnam[][5] = {"HORZ","VERT"};
  static	 char	latnm[][12] = {"BETA","PHASE","DISPERS"};
  static  int	be=0;
 int			ilat;
 char			mess[80];

 float	data[RING_SIZE];

 pl = setp.plane;
 ilat = be;
 width = c1+4*(displen+gap)-1;
 sts = window_construct_c(1, WMNGR_CENTER_IT,rows+2,width+2,
                          FALSE,BLUE,CYAN,"Lattice Data",&win);
 if (sts) return(util_errpost(sts, "window_construct",NULL));
 window_set_popup_c(win);
 sts = window_menu_bar_create_c(win,
 "     \\      \\RETURN", 0,1,WHITE);
 hilite_create_c(win,r2,2,21,width-2,1,&hwid,width-2,0,1,HILITE_ROW_MAJOR,TRUE);
 while (TRUE)
  {
   window_intype(&inwid,&intyp,&inrow, &incol,&info);
   switch (intyp)
    {
     case INTTRM:
      util_trm();
     case INTKBD:
      if (inwid != win) goto ret;
      else if (inrow == 1) {   		
         inbar = window_menu_bar_update_c(win);
         if (inbar == 1) {
            pl ? (pl = HORZ) : (pl = VERT);
            new_plane = TRUE;
          }
         else if (inbar == 2) {
            my_wmenu_c(4,12,3,12,(char *)latnm,"",(int*)&ilat);
            if (ilat < 3) disp = TRUE;
          }
         else if (inbar == 3) goto ret;
         else goto out;
       }
      else {
         if (ilat > 2) goto out;
         hilite_suspend_c(hwid,HILITE_ERASE_LAST);
         ring_wide_input(win,inrow,incol,pl,datptr0,dattyp,datlen,
                         r2,c1,displen,gap);
         cor->plane_svd_setup_flag[setp.plane] = INVALID;
         hilite_resume_c(hwid);
       }
      out:break;

     case INTPER:

      if (new_plane) {
	 new_plane = FALSE;
       	 hilite_delete_c(hwid);
	 sprintf ( mess, "%.4s",plnam[pl] );
	 menu_bar_change_entry_c ( win, 1, mess );
	 if ( ilat < 3 )disp=TRUE;
	 else disp_name = TRUE;
	 get_lattice ( 1, pl, &lat );
	 n = 0;
	 for ( i = 0; i < 4; i++ )
	   {
	     for ( j = 0; j < 12; j++ )
	       {
		 if ( ( j % 2 ) == 0 )l=0;
		 else if ( ( j % 2 ) == 1 )l=1;
		 corr_num = 6 * i + j / 2 + 1;
		 if ( pl == 0 )
		   {
		     if ( l == 0 )
		       sprintf ( mess, "HL%2d", corr_num );
		     else if ( l == 1 )
		       sprintf ( mess, "HS%2d", corr_num );
		   }
		 else if ( pl == 1 )
		   {
		     if ( l == 0 )
		       sprintf ( mess, "VL%2d", corr_num );
		     else if ( l == 1 )
		       sprintf ( mess, "VS%2d", corr_num );
		   }
		 window_display_value_c ( win, r2 + j, c0 + i * 16,
					 mess, CNV_CHAR, 4, GREEN );
	       }
	   }

       }

      if (disp) {
         disp = FALSE;
         sprintf(mess,"%.*s",strlen(latnm[ilat]),latnm[ilat]);
         menu_bar_change_entry_c(win,2,mess);
	 n = 0;
	 if ( pl == HORZ )
	   {
	     if ( ilat == 0 )memcpy ( data, lat.beta_c,
				     4 * RING_SIZE );
	     if ( ilat == 1 )memcpy ( data, lat.psi_c,
				     4 * RING_SIZE );
	     if ( ilat == 2 )memcpy ( data, lat.disp_c,
				     4 * RING_SIZE );
	   }
	 if ( pl == VERT )
	   {
	     if ( ilat == 0 )memcpy ( data, lat.beta_c,
				     4 * RING_SIZE );
	     if ( ilat == 1 )memcpy ( data, lat.psi_c,
				     4 * RING_SIZE );
	     if ( ilat == 2 )memcpy ( data, lat.disp_c,
				     4 * RING_SIZE );
	   }
	 for ( i = 0; i < 4; i++ )
	   {
	     for ( j = 0; j < 12; j++ )
	       {
		 if ( ( j % 2 ) == 0 )l=0;
		 else if ( ( j % 2 ) == 1 )l=1;
		 corr_num = 6 * i + j / 2 + 1;
		 if ( pl == 0 )
		   {
		     if ( l == 0 )
		       sprintf ( mess, "HL%2d", corr_num );
		     else if ( l == 1 )
		       sprintf ( mess, "HS%2d", corr_num );
		   }
		 else if ( pl == 1 )
		   {
		     if ( l == 0 )
		       sprintf ( mess, "VL%2d", corr_num );
		     else if ( l == 1 )
		       sprintf ( mess, "VS%2d", corr_num );
		   }
		 window_display_value_c ( win, r2 + j, c0 + i * 16,
					 mess, CNV_CHAR, 4, GREEN );
		 window_display_value_c ( win, r2 + j, c0 + i * 16 + 5,
					 (void *)&data[i * 12 + j],
					 CNV_FLOAT, 6, GREEN );
	       }
	   }
       }

      break;
    }
  }
 ret:hilite_delete_c(hwid);
 window_menu_bar_delete_c(win);
 window_intype_put_data_c(win,0,rows,1,CLIB_DEFAULT_ARG);
 window_delete_c(win,-1,-1);
 return(0);
}



/******************************************************************************/
/*+ float fround(int num_digit_after_point, float x)
*	round off a float number to num of specified digits after
        the decimal point. Maximum(num_digit_after_point) = 6 
-*/
/******************************************************************************/
extern "C" float fround(int num_digit_after_point, float x)
{
 int			i, in;
 float          	f, fr;
 static  float	multplier[7] = {1.,10.,100.,1000.,10000.,
                                        100000.,1000000.};

 in = (int)x;        /* integer part */
 fr = x - in;        /* fractional part */

 /* only work on fractional part, to avoid big number to overflow */

 f = fr * multplier[num_digit_after_point];
 i = (int)f;
 if (f >= 0 && f - i >= .5) i++;
 else if (f < 0 && i - f >= .5) i--;
 return(in + i / multplier[num_digit_after_point]);
}

/******************************************************************************/
/*+ void skip_bits(int plane,int jbit,int* bits)
	extract the flag bit form skip table. The skip table is packed with
	the 3 flags: 
          bit 1 on = skip the location, orbit it not to be changed;
          bit 2 on = bad corrector;
          bit 3 on = bad bpm;
        The returned address must be for an array of RING_SIZE+1 with last
	element used as a flag.
-*/                     
/******************************************************************************/
extern "C" void skip_bits(int jbit,int* bits)
{
 int			i;
 static  int	bit[] = {1, 2, 4};
 for (i = 0; i < RING_SIZE; i++) bits[i] = skip.x.longs[i] & bit[jbit];
 return;
}


/******************************************************************************/
/*+ util_errpost
*	sts.i4.v = util_errpost(err.i4.v, mess.i1a.r, addmess.i1a.r)
*	
*	Check for error in 'err'.  Post/log a message if 'err' is nonzero.
*
*	err		ACNET error code
*                       If DIO_GENERR(a error should be defined by the program)
                        only error message will be displayed.

*	mess		NULL terminated error message
*
*   	addmess  this text (NULL terminated) will be 
*   			added to the end of 'mess' (may be NULL)
*
*	Returns 'err'.
-*/
/******************************************************************************/
extern "C" int util_errpost(int sts, char *mess, char *addmess)
{
 char        errmess[78]; 

 if (sts)
  {
   if (addmess != NULL) 
    sprintf(errmess, "%s %.*s,", mess, 78-strlen(mess)-3, addmess);
   else
    sprintf(errmess, "%.*s ", strlen(mess), mess);
   if (sts != DIO_GENERR && sts != MYERR)
    error_display_c(errmess, ERR_ACNET, sts);
   else error_message_c(errmess,0,RED,TRUE); 
  }
 return (sts);
}


/******************************************************************************/
/*+	int	get_booster_correctors ( int plane, float* currents )
-*/                     
/******************************************************************************/
extern "C" int	get_booster_correctors ( int plane, float* currents )
{

int	sts;
short	corr_status[NUM_CORRECTORS];
int	corr_indices[NUM_CORRECTORS];
char	*corptr;
static	int	corr_list;

if ( plane == 0 )
{
  corptr = h_correctors[0];
}
else if ( plane == 1 )
{
  corptr = v_correctors[0];
}

sts = dio_device_index_c ( corptr, corr_indices, NUM_CORRECTORS,
			  corr_status );
if ( sts != DIO_OK )
  {
    error_display_c ( "Error reading corrector indices", ERR_ACNET, sts );
    return sts;
  }

sts = dio_bld_get_c ( &corr_list, NUM_CORRECTORS, corr_indices, prop,
		     corr_status );
if ( sts != DIO_OK )
  {
    error_display_c ( "Error building list", ERR_ACNET, sts );
    return sts;
  }

sts = dio_get_lst ( &corr_list, currents, corr_status );
if ( sts != DIO_OK )
  {
    error_display_c ( "Error getting list", ERR_ACNET, sts );
    sts = dio_can_get_lst ( &corr_list );
    if ( sts != DIO_OK )
	error_display_c ( "dio_can_get_lst failure for reading correctors",
		ERR_ACNET, sts );			 
    return sts;
  }

 return 0;
}

/******************************************************************************/
/*+ void disp_g_float(int screen,GEN_DB_HDR_STRUCT* h,float* dat)
	display g(c453 g table) for current settings,new settings 
-*/                     
/******************************************************************************/
extern "C" void disp_g_floats(int screen,GEN_DB_HDR_STRUCT* h,float* dat,char* stat1,
	int opt)
{
 int			pid;
 float			limits[2];
 char			title[80],cap1[20],cap2[20];
 float			x;
 char			date[21];
 char			stat[RING_SIZE];
 float			floats[RING_SIZE];
 static  char    	plnam[][5] = {"horz","vert"};
 static  char    	unit[][5] = {"uRAD","AMPS"};
 static  int	clr[2] = {GREEN,RED};

 memset(stat,0,RING_SIZE);
 limits[0] = - pltpar.amplim; limits[1] = pltpar.amplim;

 if (pltpar.autolim) plt_limits(RING_SIZE,floats,limits);
 clinks_to_date(h->date, date);
 str_insert_terminator_c(h->title,20);
 sprintf(title,"%.*s %2X %.4s %1d %.20s", strlen(h->title),h->title,
         h->tclk,plnam[h->plane],h->slot,date);
 plt_ring_init1(h->plane,TRUE,TRUE,screen,&pid,2,16,title,limits,
                unit[opt]);
 x = calc_ave(RING_SIZE,stat1,dat);
 sprintf(cap1,"AVG=%7.2f",x);
 x = calc_rms(RING_SIZE,stat1,dat);
 sprintf(cap2,"RMS=%7.2f",x);
 plt_ring_data1(screen,pid,dat,stat,pltpar.colors,"",cap1,cap2);
 table_ring_data1(h->plane,FALSE,screen,21,CNV_FLOAT,4,dat,7,stat1,clr,
                  "","",cap1,cap2);
 return;
}


/******************************************************************************/
/*+ void plt_ring_corr1(int screen, int id, float *dat, char *stat, 
                   int *color, char *cap1,char *cap2,char *cap3)
-*/                     
/******************************************************************************/
extern "C" void plt_ring_corr1(int screen, int id, int plane, float *dat, char *stat, 
                   int *color, char *cap1, char *cap2,char *cap3)
{
 int			i,l1,l2,l3;
 float			x;
 float			viw[4];
 static  int	clr[2] = {GREEN,RED};
 float			xf;

 
 wn_active_c(id);
 wn_clip_c(TRUE);

 wn_get_view_coords_c(id, &viw[0], &viw[1], &viw[2], &viw[3]);
 
 xf = ( viw[2] - viw[0] ) / 24;

 if (pltpar.bar) {
    for (i = 0; i < NUM_CORRECTORS; i++) {
      x = viw[0] + 2 * i + (float)(i) * xf +
	( 0.25 ) * xf * RING_SIZE;
      if ( plane == 0 )x = x + 1.0 + 0.5 * xf;
/*      x = viw[0] + i + 0.5 * (float)(i) * xf + 0.25 * xf * RING_SIZE;*/
/*      if ( ( i % 2 ) == 0 ) x = i + 1 + xf;
      else if ( ( i % 2 ) == 1 ) x = i + 1 + xf;*/
      wn_color_c(clr[stat[i]]);
      wn_vector_c ( x, 0.0, x, dat[i] );
     }
  }
 if (pltpar.connect) {
    for (i = 0; i < RING_SIZE-1; i++) {
       /*wn_color_c(color[stat[i]]);*/
       wn_vector_c((float)(i+1), dat[i], (float)(i+2), dat[i+1]);
     }
  }
 if (pltpar.sym) {
    wn_set_plot_symbol_c(pltpar.symtyp, pltpar.symsiz); 
    wn_fill_mode_c(pltpar.symfill);
    for (i = 0; i < RING_SIZE; i++) {
       wn_color_c(clr[stat[i]]);
       wn_symbol_c((float)(i+1), dat[i]);
     }
  }

 wn_active_c(bkgd_wid[screen]);
 wn_color_c(WHITE);
 l1 = strlen(cap1);l2 = strlen(cap2);l3 = strlen(cap3);
 wn_text_c(viw[2]-(l1+l2+l3+4)*CHX,viw[1] - 2.* CHY,cap1,l1);
 wn_text_c(viw[2]-(l2+l3+2)*CHX, viw[1] - 2. * CHY,cap2,l2);
 wn_text_c(viw[2]-l3*CHX, viw[1] - 2. * CHY,cap3,l3);
 return;
}


/******************************************************************************/
/*+ void table_ring_corr1(int pl,int init, int screen, int trow,int dtyp, 
                      int dlen, void *dat,int displen,char *stat, int *color, 
                      char *tit, char *cap1, char *cap2,char *cap3)
    Lists the HS/VL correctors	      
-*/                     
/******************************************************************************/
extern "C" void table_ring_corr1(int pl,int init, int screen, int trow,int dtyp, 
                      int dlen, void *dat,int displen,char *stat, int *color, 
                      char *tit,char *cap1,char *cap2,char *cap3)
{
 int			i, j, l1,l2,l3,n;
 float			x, x0, y0, y1, y,collen;
 static  float	viw[4] = {.09, .08, .96, .97};

 char			*datptr;

 int	corr_num;
 char	mess[4];

 datptr = (char *) dat;
 if (init != 0) {
    wn_select_screen_c(gx_screen[screen]);
    wn_screen_init_c(tit,WN_HCMODE_DEFAULT,TRUE);
    wn_view_c(&bkgd_wid[screen], 0., 0., 1., 1.);
    wn_world_c(bkgd_wid[screen], 0., 0., 1., 1.);
  }

  /* determine where to put table */
 y0 = (WN_MAXROW - trow) / WN_MAXROW; 
  /* write tit and section mark*/
 wn_active_c(bkgd_wid[screen]);
 wn_color_c(WHITE);
 wn_text_c(viw[0]-2*CHX,y0,tit,strlen(tit));
 collen = (viw[2]-viw[0]-8*CHX)/4;

 datptr = (char *)dat;
 n = 0;
 x0 = viw[0]+(collen-7*CHX)/2+4*CHX;
 y0 -= 1.02*CHY;
 for ( i = 0 ; i < 4 ; i++ )
   {
     x = x0 + i * collen;
     y1 = y0 - 1.02 * CHY;
     for ( j = 0 ; j < 6 ; j++ )
       {
/*	 m = 0;
	 if ( ( j % 2 ) == 0 )m=0;
	 else if ( ( j % 2 ) == 1 )m=1;
	 corr_num = 6 * i + j / 2 + 1;*/
	 corr_num = i * 6 + j + 1;
	 y = y1 - j * 1.02 * CHY;
	 wn_color_c ( color[stat[n]] );
	 if ( pl == 0 )
	   {
/*	     if ( m == 0 )
	       {
		 sprintf ( mess, "HL%2d", corr_num );
	       }
	     else if ( m == 1 )
	       {*/
		 sprintf ( mess, "HS%2d", corr_num );
/*	       }*/
	   }
	 else if ( pl == 1 )
	   {
/*	     if ( m == 0 )
	       {*/
		 sprintf ( mess, "VL%2d", corr_num );
/*	       }
	     else if ( m == 1 )
	       {
		 sprintf ( mess, "VS%2d", corr_num );
	       }*/
	   }
	 wn_display_value_c ( x, y, mess, CNV_CHAR, 4 );
	 wn_display_value_c ( x + 6.02 * CHX, y, (void *)datptr,
			     dtyp, displen );
	 datptr += dlen;
	 n++;
       }
   }

 wn_color_c(WHITE);
 l1 = strlen(cap1);l2 = strlen(cap2);l3 = strlen(cap3);
 wn_text_c(5.0*collen-(l1+l2+l3+4)*CHX,y-1.2*CHY,cap1,l1);
 wn_text_c(5.0*collen-(l2+l3+2)*CHX,y-1.2*CHY,cap2,l2);
 wn_text_c(5.0*collen-l3*CHX,y-1.2*CHY,cap3,l3);

 return;
}
/******************************************************************************/
/*+ void plt_xy_init(int pl,int init, int screen, int *pid,  
                    char *tit, float *xlimits, float *ylimits, char *xunit, 
                    char *yunit)
-*/                     
/******************************************************************************/
extern "C" void plt_xy_init(int pl,int init,int screen, int *pid, 
        char *tit,float *xlimits, float *ylimits,char *xunit, char *yunit)
{ 
 static float		viw[4] = {.09, .08, .96, .97};

 wn_delete_c(*pid);
 if (init) {
    wn_select_screen_c(gx_screen[screen]);
    wn_screen_init_c(tit,WN_HCMODE_DEFAULT,TRUE);
    wn_view_c(&bkgd_wid[screen], 0., 0., 1., 1.);
    wn_world_c(bkgd_wid[screen], 0., 0., 1., 1.);
 }


  /* paint plot frame */
 wn_color_c(BLUE);
 wn_view_c(pid, viw[0], viw[1], viw[2], viw[3]-.2*CHY);
 wn_world_c(*pid, xlimits[0], ylimits[0], xlimits[1], ylimits[1]);
 /* label axis */
 wn_active_c(*pid);
 wn_erase_c();
 wn_axis_label_c(HORZ, 4, 2, TRUE, xunit, 1,BLUE, 5, CNV_FLOAT);
 wn_axis_label_c(VERT, 4, 2, TRUE, yunit, 1,BLUE, 5, CNV_FLOAT);
  /* write tit and ...*/
 wn_color_c(WHITE);
 wn_active_c(bkgd_wid[screen]);
 wn_text_c(viw[0]+(viw[2]-viw[0]-strlen(tit)*CHX)/2,viw[3],tit,strlen(tit));

}
extern "C" void plt_xy(int id,int n, float *x, float *y, int color) {
 int			i;

 
 wn_active_c(id);
 wn_clip_c(TRUE);

 wn_color_c(color);
 
 for(i=1; i<n ; i++) {
   wn_vector_c(x[i-1],y[i-1],x[i],y[i]);
 }
}
extern "C" void disp_rms_vs_time(int pl, int screen, int n, float *t, float *r1,
   float *r2){
   
   int pid;
   float ylimits[2];
   float xlimits[2];
   
   xlimits[0] = 0.;
   xlimits[1] = t[n-1];
   ylimits[0] = 0.;
   ylimits[1] = (float)pltpar.mmlim;
   
   plt_xy_init(pl, screen, TRUE, &pid, "RMS vs Time", xlimits, ylimits,
    "msec", "MM");
   plt_xy(pid,n,t,r1,RED);
   plt_xy(pid,n,t,r2,GREEN);
}    
extern "C" void disp_dev_vs_time(int pl, int screen, int iper,int n, float *t, float *d1,
   float *d2){
   
   int pid;
   float ylimits[2];
   float xlimits[2];
   char tit[128];
   
   xlimits[0] = 0.;
   xlimits[1] = t[n-1];
   ylimits[0] = -(float) pltpar.mmlim;
   ylimits[1] = (float)pltpar.mmlim;

   sprintf(tit,"deviation vs time, period %d",   iper);
   
   plt_xy_init(pl, screen, TRUE, &pid, tit, xlimits, ylimits,
    "msec", "MM");
   plt_xy(pid,n,t,d1,RED);
   plt_xy(pid,n,t,d2,GREEN);
}    
/********************************************************************
*
* Steering scale function - this returns the scale for the steering
* functio
*
*********************************************************************/
extern "C" int steer_scale_function(CURVE_LIMIT_DATA *cl) {
   steer_range_bounds(cl);  /* Set the range */
   return(FALSE);             /* inhibit autoscaling */
}
/*********************************************************************
*
* Range bounds function for steering program 
**********************************************************************/
extern "C" void steer_range_bounds(CURVE_LIMIT_DATA *cl) {
  cl->minimum_x = 0.;
  cl->minimum_y = -5.;
  cl->maximum_x = 25.;
  cl->maximum_y = 5.;
}
/*****************************************************************/
/* Initialize the steering array                                 */
/*****************************************************************/
extern "C" void init_steer(CURVE_POINT *c,int *n,int *flags,float *init) {
   int i;
   *n = 0;
   for(i=0; i<RING_SIZE ; i++) {
      if((flags!=NULL)&&(flags[i]!=0)) continue;
      c[(*n)].x = ((float) i)/2.+1.;
      c[(*n)].y = 0.;
      if(init!=NULL) c[(*n)].y += init[i];
      (*n)++;
   }
}
/********************************************************************/
/* Add the steering increments onto the desired orbit               */
/********************************************************************/
extern "C" void add_steer(CURVE_POINT *c,int n,float *desob) {
  int i;
  int ielem;
  for(i=0;i<n;i++) {
    ielem = (int) ((c[i].x - .999)*2.);
    if((ielem<0)||(ielem>=RING_SIZE)) {
       error_display_c("Corrupt element in steering array",ERR_ACNET,MYERR);
       continue;
    }
    desob[ielem] += c[i].y;
  }
}
