$isql/server=adbs/user="prebys"/pass="thatdawg"
use appdb
go

/* bpm data table */


go
create table b_bpm_data (
date		int   	  	not null,
tclk		int   	  	not null,
type		int 		not null,
time		real  	  	not null,
fid             int             not null,
my_lock		int   	  	not null,
title		char(20)	not null,
xstat		binary(48)     not null,
ystat		binary(48)     not null,
F1  real,	F2 real,  	F3 real,  	F4 real,  	F5 real,  
F6  real,  	F7 real,  	F8 real,  	F9 real,  	F10 real,  
F11 real,  	F12 real,  	F13 real,  	F14 real,  	F15 real,  
F16 real,  	F17 real,  	F18 real,  	F19 real,  	F20 real,  
F21 real,  	F22 real,  	F23 real,  	F24 real,  	F25 real,  
F26 real,  	F27 real,  	F28 real,  	F29 real,  	F30 real,  
F31 real,  	F32 real,  	F33 real,  	F34 real,  	F35 real,  
F36 real,  	F37 real,  	F38 real,  	F39 real,  	F40 real,  
F41 real,  	F42 real,  	F43 real,  	F44 real,  	F45 real,  
F46 real,  	F47 real,  	F48 real,  	F49 real,  	F50 real,  
F51 real,  	F52 real,  	F53 real,  	F54 real,  	F55 real,  
F56 real,  	F57 real,  	F58 real,  	F59 real,  	F60 real,  
F61 real,  	F62 real,  	F63 real,  	F64 real,  	F65 real,  
F66 real,  	F67 real,  	F68 real,  	F69 real,  	F70 real,  
F71 real,  	F72 real,  	F73 real,  	F74 real,  	F75 real,  
F76 real,  	F77 real,  	F78 real,  	F79 real,  	F80 real,  
F81 real,  	F82 real,  	F83 real,  	F84 real,  	F85 real,  
F86 real,  	F87 real,  	F88 real,  	F89 real,  	F90 real,  
F91 real,  	F92 real,  	F93 real,  	F94 real,  	F95 real,  
F96 real
)
go
create unique clustered index idx1 on b_bpm_data(date,tclk,type,time)
go
grant select,insert,update,delete on b_bpm_data to PA1747
go


