
#include "gen.h"
#include "lib465.h"
#include "otable.h"
#include "obc.h"
#include "util.h"
#include "model.h"


extern "C" int get_lattice_from_disk(int pl,LATTICE_STRUCT *l);
extern "C" int read_disk_lat(int pl,int which,float *beta,float *psi,float *dispers,
                  float *tune);





/******************************************************************************/
/*+ int get_lattice(int source,int plane,LATTICE_STRUCT *l)
	get data from disk if source=TRUE otherwise from model data base.
	put data in cr struct with data re-ordered as going in order of 
  	house 6,1,2,3,4,5. In model people made beam starting at RF, a shfiting
	of 2 elements.
	the sequence is shifted into houseby 2 elements
        For hcorr there is an extra element '522' appears in model that 
	represent 2 identical corr at almost the same place. This is taken out.
	Ordering starts with section 6 followed by 1,2,3,4,5
	>plane is used as a flag, if it is the plane number(0 or 1) the data is
	already exist, reading db is not done.
-*/
/******************************************************************************/
extern "C" int get_lattice(int source,int plane,LATTICE_STRUCT *l)
{
 int		        sts;


 if (l->plane == plane) return(0); /* data already exists */

 if (source) { /* get disk lattice file data */
    sts = get_lattice_from_disk(plane,l);
    if (!sts) l->plane = plane;
    return(sts);
  }


/*CDAHadd*/
return ( 0 );

}




/******************************************************************************/
/*+ int read_disk_lat(int pl,int which,float *beta,float *psi,float *dispers,
                  float *tune)
-*/
/******************************************************************************/
extern "C" int read_disk_lat(int pl,int which,float *beta,float *psi,float *dispers,
                  float *tune)
{
 int			i;

/*CDAHadd*/
 float	hbeta[RING_SIZE] = { 7.4, 33.4, 7.4, 33.4, 7.4, 33.4, 7.4, 33.4,
			       7.4, 33.4, 7.4, 33.4, 7.4, 33.4, 7.4, 33.4,
			       7.4, 33.4, 7.4, 33.4, 7.4, 33.4, 7.4, 33.4,
			       7.4, 33.4, 7.4, 33.4, 7.4, 33.4, 7.4, 33.4,
			       7.4, 33.4, 7.4, 33.4, 7.4, 33.4, 7.4, 33.4,
			       7.4, 33.4, 7.4, 33.4, 7.4, 33.4, 7.4, 33.4 };
 float	vbeta[RING_SIZE] = {	20.4, 5.3, 20.4, 5.3, 20.4, 5.3, 20.4, 5.3,
			  20.4, 5.3, 20.4, 5.3, 20.4, 5.3, 20.4, 5.3,
			  20.4, 5.3, 20.4, 5.3, 20.4, 5.3, 20.4, 5.3,
			  20.4, 5.3, 20.4, 5.3, 20.4, 5.3, 20.4, 5.3,
			  20.4, 5.3, 20.4, 5.3, 20.4, 5.3, 20.4, 5.3,
			  20.4, 5.3, 20.4, 5.3, 20.4, 5.3, 20.4, 5.3 };
 float	disp[RING_SIZE] = { 1.9, 3.3, 1.9, 3.3, 1.9, 3.3, 1.9, 3.3,
		       1.9, 3.3, 1.9, 3.3, 1.9, 3.3, 1.9, 3.3,
		       1.9, 3.3, 1.9, 3.3, 1.9, 3.3, 1.9, 3.3,
		       1.9, 3.3, 1.9, 3.3, 1.9, 3.3, 1.9, 3.3,
		       1.9, 3.3, 1.9, 3.3, 1.9, 3.3, 1.9, 3.3,
		       1.9, 3.3, 1.9, 3.3, 1.9, 3.3, 1.9, 3.3 };
 float	hphase[RING_SIZE] = { 0.212, 0.279, 0.491, 0.558, 0.77, 0.837,
			 1.049, 1.116, 1.328, 1.395, 1.607, 1.674, 
			 1.886, 1.953, 2.165, 2.232, 2.444, 2.511,
			 2.723, 2.790, 3.002, 3.069, 3.281, 3.348, 
			 3.560, 3.627, 3.839, 3.906, 4.118, 4.185,
			 4.397, 4.464, 4.676, 4.743, 4.955, 5.022,
			 5.234, 5.301, 5.513, 5.580, 5.792, 5.859,
			 6.071, 6.138, 6.350, 6.417, 6.629, 6.696 };
 float	vphase[RING_SIZE] = { .165, 0.283, 0.448, 0.566, 0.731, 0.849,
			 1.014, 1.132, 1.297, 1.415, 1.580, 1.698,
			 1.863, 1.981, 2.146, 2.264, 2.429, 2.594, 
			 2.759, 2.877, 3.042, 3.160, 3.325, 3.443,
			 3.608, 3.726, 3.891, 4.009, 4.174, 4.292,
			 4.457, 4.575, 4.740, 4.858, 5.023, 5.141,
			 5.306, 5.424, 5.589, 5.707, 5.872, 5.990,
			 6.155, 6.273, 6.438, 6.556, 6.721, 6.839 };

if ( pl == HORZ )
  {
    memcpy ( beta, hbeta, 4 * RING_SIZE );
    memcpy ( psi, hphase, 4 * RING_SIZE );
    for ( i = 0; i < RING_SIZE; i++ )psi[i] *= TWOPI;
    memcpy ( dispers, disp, 4 * RING_SIZE );
    *tune = hphase[RING_SIZE - 1];
  }
else if ( pl == VERT )
  {
    memcpy ( beta, vbeta, 4 * RING_SIZE );
    memcpy ( psi, vphase, 4 * RING_SIZE );
    for ( i = 0; i < RING_SIZE; i++ )psi[i] *= TWOPI;
    memset ( dispers, 0, 4 * RING_SIZE );
    *tune = vphase[RING_SIZE - 1];
  }


return ( 0 );

}  


/******************************************************************************/
/*+ int get_lattice_from_disk(int pl,LATTICE_STRUCT *l)
	get lattice data from disk ascii file
-*/
/******************************************************************************/
extern "C" int get_lattice_from_disk(int pl,LATTICE_STRUCT *l)
{
 int			sts;
 static  int	ced=0;

/*CDAHadd */
 if ( pl == HORZ)
    	sts = read_disk_lat(pl,ced,l->beta_c,l->psi_c,l->disp_c,
	&l->tune[pl]);
 if ( pl == VERT )
    sts = read_disk_lat ( pl, ced, l->beta_c, l->psi_c, l->disp_c,
	&l->tune[pl] );
 if (sts) return(sts);
 memcpy ( l->beta_b, l->beta_c, 4 * RING_SIZE );
 memcpy ( l->psi_b, l->psi_c, 4 * RING_SIZE );
 memcpy ( l->psi_b, l->psi_c, 4 * RING_SIZE );
 
 return(calc_transfer(pl,l));
 
/* if (tune != l->tune[pl]) return(MYERR);*/


 return(0);
}
/*****************************************************************/
/* Calculate the transfer matrix to be used in corrections       */
/*****************************************************************/
extern "C" int calc_transfer(int pl, LATTICE_STRUCT *lat) {
   int i,j;
   float pitune;
   float denom;
   float sqrtbeta[RING_SIZE];
   
   pitune = PI*lat->tune[pl];
   denom = 2*sin(pitune);

   /* calculate square roots to maybe speed things up */
   for(i=0;i<RING_SIZE;i++) sqrtbeta[i] = sqrt(lat->beta_c[i]);

   
   for(i = 0; i<RING_SIZE; i++ ){
     for(j = 0; j<RING_SIZE; j++) {
        lat->A[i][j] = sqrtbeta[i]*sqrtbeta[j]*
        	sin(lat->psi_c[j]-lat->psi_c[i]-pitune)/denom;
     }
   }
   
   return(0);
}
