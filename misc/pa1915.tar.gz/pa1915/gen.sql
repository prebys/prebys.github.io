$isql/server=adbs/user="prebys"/pass="thatdawg"
use appdb
go
create table b_db_floats (
name		char(8)         not null,
tclk		int        	not null,
plane		int        	not null,
slot		int        	not null,
date		int        	not null,
fid             int             not null,
my_lock		int		not null,
title		char(20)         not null,
r1 real,     r2 real,     r3 real,	 r4 real, 	r5 real,
r6 real,    r7 real,     r8 real,	 r9 real,	
r10 real,   r11 real,    r12 real,  r13 real,	r14 real,
r15 real,   r16 real,    r17 real,  r18 real,	r19 real,
r20 real,   r21 real,    r22 real,  r23 real,	r24 real,
r25 real,   r26 real,    r27 real,  r28 real,	r29 real,
r30 real,   r31 real,    r32 real,  r33 real,	r34 real,
r35 real,   r36 real,    r37 real,  r38 real,	r39 real,
r40 real,   r41 real,    r42 real,  r43 real,	r44 real,
r45 real,   r46 real,    r47 real,  r48 real
)
go
create unique clustered index idx on b_db_floats(name,tclk,plane,slot,fid,
date)
go
grant select,insert,update,delete on b_db_floats to PA1915
go

create table b_db_longs (
name		char(8)         not null,
tclk		int        	not null,
plane		int        	not null,
slot		int        	not null,
date		int        	not null,
fid             int             not null,
my_lock		int		not null,
title		char(20)         not null,
i1 int,     i2 int,     i3 int,	 i4 int, 	i5 int,
i6 int,    i7 int,     i8 int,	 i9 int,	
i10 int,   i11 int,    i12 int,  i13 int,	i14 int,
i15 int,   i16 int,    i17 int,  i18 int,	i19 int,
i20 int,   i21 int,    i22 int,  i23 int,	i24 int,
i25 int,   i26 int,    i27 int,  i28 int,	i29 int,
i30 int,   i31 int,    i32 int,  i33 int,	i34 int,
i35 int,   i36 int,    i37 int,  i38 int,	i39 int,
i40 int,   i41 int,    i42 int,  i43 int,	i44 int,
i45 int,   i46 int,    i47 int,  i48 int
)
go
create unique clustered index idx on b_db_longs(name,tclk,plane,slot,fid,
date)
go
grant select,insert,update,delete on b_db_longs to pa1915
go

create table b_db_shorts (
name		char(8)         not null,
tclk		int        	not null,
plane		int        	not null,
slot		int        	not null,
date		int        	not null,
fid             int             not null,
my_lock		int		not null,
title		char(20)         not null,
s1 smallint,     s2 smallint,     s3 smallint,	 s4 smallint, 	s5 smallint,
s6 smallint,    s7 smallint,     s8 smallint,	 s9 smallint,	
s10 smallint,   s11 smallint,    s12 smallint,  s13 smallint,	s14 smallint,
s15 smallint,   s16 smallint,    s17 smallint,  s18 smallint,	s19 smallint,
s20 smallint,   s21 smallint,    s22 smallint,  s23 smallint,	s24 smallint,
s25 smallint,   s26 smallint,    s27 smallint,  s28 smallint,	s29 smallint,
s30 smallint,   s31 smallint,    s32 smallint,  s33 smallint,	s34 smallint,
s35 smallint,   s36 smallint,    s37 smallint,  s38 smallint,	s39 smallint,
s40 smallint,   s41 smallint,    s42 smallint,  s43 smallint,	s44 smallint,
s45 smallint,   s46 smallint,    s47 smallint,  s48 smallint
)
go
create unique clustered index idx on b_db_shorts(name,tclk,plane,slot,fid,
date)
go
grant select,insert,update,delete on b_db_shorts to pa1915
go

