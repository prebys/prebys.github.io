#ifndef NRROUTINES

#define NRROUTINES



extern "C" int svdcmp(float **a, int m, int n, float *w, float **v);
extern "C" int svbksb(float **u, float *w, float **v, int m, int n, 
  float *b, float *x);
extern "C" float **create_matrix(int nrl, int nrh, int ncl, int nch);
extern "C" void free_matrix(float **data, int nrl, int nrh, int ncl, int nch);
extern "C" float *vector(int nl, int nh);
extern "C" void free_vector(float *data, int nl, int nh);



#endif

