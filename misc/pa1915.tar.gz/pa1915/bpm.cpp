#include "gen.h"
#include "lib465.h"
#include "otable.h"
#include "obc.h"
#include "ul_model/model_config.h"
#include "util.h"
#include "corr.h"
#include "bpm.h"
#include "model.h"

MODEL_ORBIT_STRUCT 		*bpm;


char bpm_messbuff[128];

#define MAX_PF_NUM 10
//   WLM linux conversion note---remove bpm_,bpm_init,bpm_end because
//       does not seem to be used and gives compiler errors on code
//       which makes no sense given the present environment
#ifdef BPM_

/******************************************************************************/
/*+ void bpm_(void)
-*/                     
/******************************************************************************/
extern "C" void bpm_(void)
{
 int 			i, j, sts;
 short 			win, inwid, intyp;
 int 			inrow, incol, info;
 int			row,col;
 int 			pl, width = 29, height = 6;
 static	 int	r1 = 3, r2 = 6;
 static  int	c1 = 2, c2 = 2;
 int			icmd,isrc=0;
 static  char 	cmdt1[][14]={"display frame",
                                     "file data" };
 static  char 	cmdt2[][20]={"get/display bpm",
                                     "save to file" };
 int			disp=FALSE,save=FALSE;
 BPM_TABLE_STRUCT	bdata;
 char			stat[2][MAX_PF_NUM][RING_SIZE];
 BPM_SINGLE_TABLE_STRUCT *tmp;

 bpm_init();
 pl = setp.plane;
 inrow = 8; incol = 21; cursor(0, &inrow, &incol);
 sts = window_construct_c(inrow, incol,
		             height+2, width+2,FALSE,BLUE,WHITE,
			    "BPM", 
		            &win, TRUE, FALSE, WMNGR_MOVE_IT);	
 window_set_popup_c(win);
 window_tvm_c(win,r1-2,c1,"select from 2 options ....",26,CYAN);
 window_hline_c(win,r1-1,c1,width,CYAN);
 for (i = 0; i < 2; i++)
    window_tvm_c(win,r1+i,c1,(char *)cmdt1[i],strlen(cmdt1[i]),bf[0]);
 isrc = 0;
 window_tvm_c(win,r1+i,c1,(char *)cmdt1[i],strlen(cmdt1[i]),bf[1]);
 window_hline_c(win,r2-1,c2,width,CYAN);
 window_tvm_c(win,r2,c2,"*commands",9,bf[0]);
 window_tvm_c(win,r2,width-7,"*return",7,bf[0]);

 while (TRUE)
  {
   window_intype(&inwid,&intyp,&inrow, &incol,&info);
   switch (intyp)
    {
     case INTTRM:util_trm();
     case INTKBD:
      if (inwid != win)goto ret;
      else if (in_window_field_c(win,r2,width-7,7)) goto ret;
      else if (in_window_box_c(win,r1,4,c1,15)) {
	if ( ( inrow == 3 ) || ( inrow == 4 ) )
	  {
	    isrc = inrow-r1;
	    window_tvm_c(win,r1+i,c1,(char *)cmdt1[isrc],
			 strlen(cmdt1[isrc]),bf[0]);
	  }
      else if (in_window_field_c(win,r2,c2,9)) {
         row = 7; col = 20; cursor(0, &row, &col);
         sts = my_wmenu_c(row,col,2,20,(char *)cmdt2,"",&icmd);
         if (!sts) goto out;
         if (icmd == 0) {
            if (isrc == 0) {
               sts = read_bpm(cor->events[0],0,0,1,&bdata);
             }
            else if (isrc == 1) {
	      sts = read_bpm_file(&bdata);
             }
            if (!sts) disp=TRUE;
          }
	 else if ( icmd == 1 )
	   {
	     save = TRUE;
	   }
         else goto out;
       }
      }
      out:break;

    case INTPER:

      if (save) {
	 save = FALSE;
         if (!bdata.hdr.date) goto out2;
         if (isrc == 0) 
	   {
	     inptxt_c(WMNGR_CENTER,WMNGR_CENTER,
		      "title",5,bdata.hdr.title,-TIT_LEN);
	     tmp = (BPM_SINGLE_TABLE_STRUCT *)calloc(1,sizeof(BPM_SINGLE_TABLE_STRUCT));
	     bpm_rec_compress(&bdata,cor->curr_brkpt,tmp);
	     sts = bpm_rec_w(tmp);
	     cfree(tmp);
	   }
         else if (isrc == 1)
	   {
	     error_display_c ( " Can't save file date", ERR_NONE, 0 );
	   }
       }


      if (disp) {
	 disp = FALSE;
            str_insert_terminator_c(bdata.hdr.title,20);
            for (j = 0; j < 2; j++) {
               for (i = 0; i < RING_SIZE; i++) 
                  stat[j][0][i] = test_bit(7,bdata.stat[j][i]) ? 0 : 1;
             }
            disp_bpm_2(pltpar.gx,&bdata.hdr,(float *)bdata.xy[0],stat[0],
		       bdata.xy[1],stat[1]);
            disp_bpm_3((pltpar.gx?0:1),&bdata.hdr,(float *)bdata.xy[0],stat[0],
		       bdata.xy[1],stat[1]);
       }

      out2:break;
    }
  }

ret:del_window(&win);
bpm_end();
return;
}


/******************************************************************************/
/*+ void bpm_init(void)
-*/                     
/******************************************************************************/
extern "C" void bpm_init(void)
{
 if (!bp) {
    bp = (BPM_DATA_STRUCT *)clib_calloc(1,sizeof(BPM_DATA_STRUCT)); 
    if (!bp) util_errpost(MYERR,"clib_calloc bpm data area",NULL);
  }
}


/******************************************************************************/
/*+ void bpm_end(void)
-*/                     
/******************************************************************************/
extern "C" void bpm_end(void)
{
}
#endif



/******************************************************************************/
/*+ int read_bpm_file(BPM_TABLE_STRUCT* b)
-*/                     
/******************************************************************************/
extern "C" int read_bpm_file(BPM_TABLE_STRUCT* b)
{
 BPM_SINGLE_TABLE_STRUCT *tmp;
 if (!bpm_hdr_sel(miscpar.bpmdirtclk,miscpar.bpmdirtype,&b->hdr)) 
   {
    tmp = (BPM_SINGLE_TABLE_STRUCT *)calloc(1,sizeof(BPM_SINGLE_TABLE_STRUCT));
    
    if (!bpm_rec_r(&b->hdr,(void *)tmp)) {
      bpm_rec_expand(tmp,b);
      return(0);
    }
    cfree(tmp);

  }
 return(MYERR);
}


/******************************************************************************/
/*+ int read_bpm(int event, int nwait,int frame, int nframe, BPM_TABLE_STRUCT* b)
-*/                     
/******************************************************************************/
extern "C" int read_bpm(int event,int nwait,int frame, int nframe,BPM_TABLE_STRUCT* b)
{
 int		pl,ibrk,i,sts;
 unsigned int   timestamp;
 char		stat[2][MAX_BREAKPOINTS][RING_SIZE];
 int            type;
 
 type = BPM_DFG_FRAME;

 memset_longword_c((int *)&b->hdr,0,6);
 bpm_arm(event,nwait);  /* initialize BPM houses */

 sts = bpm_get_data_c
         (type,frame,nframe,b->xy[HORZ][0],b->xy[VERT][0],stat[HORZ][0],
	  stat[VERT][0], &timestamp,NULL,NULL,NULL,TRUE);
 if (sts) return(util_errpost(sts,"Err bpm_get_data",NULL));

 for (pl = 0; pl < 2; pl++) {
   /* loop over the frames, if ANY frame is bad, flag the
      status */
   for( ibrk = 0; ibrk < nframe ; ibrk++) {
     
     for (i = 0; i < RING_SIZE; i++) {
       if (stat[pl][ibrk][i] == BPM_OK) b->stat[pl][i] = 0;
       else {
         b->stat[pl][i] = 1;
       }
     }
   }
 }
 b->hdr.date = clinks_now();
 b->hdr.type = type;
 b->hdr.tclk = cyc_num[setp.cycle];

 return(0);
}


/*******************************************************************
* This sets up the BPM's to read the orbit, using the new
* BPM_DFG_FRAME mode.
*  Inputs:
*     event - event to trigger on
*     nwait - number of events to wait after a $12 before triggering
********************************************************************/
extern "C" int bpm_arm(int event, int nwait)  {
  static char *bpm_house[4] = {"B:06CORP","B:12CORP","B:18CORP","B:24CORP"};
  short read_dat[3],setup_dat[2];
  int i,di;
  int sts,ret_sts;
  char buff[80];

  /* For historical reasons, 0 will be set to 1 */
  
  if(nwait<1) nwait=1;

  ret_sts = 0;
  setup_dat[0]=event;
  setup_dat[1]=nwait;
  for(i=0;i<4;i++) {
    sts = dio_device_index_c(bpm_house[i],&di);
    if(sts!=DIO_OK) {
       sprintf(bpm_messbuff,"Error getting index for BPM house %s",
         bpm_house[i]);
       error_display_c(bpm_messbuff,ERR_ACNET,sts);
       ret_sts = sts;
       continue;
    }
    sts = dio_get_raw_c(di,PRSET,read_dat,FTD_ONESHOT,sizeof(read_dat));
    if(sts!=DIO_OK) {
       error_display_c("Error reading data from BPM house",ERR_ACNET,sts);
       ret_sts = sts;
       continue;
    }
    sprintf(buff,"BPM house %s: 0x%X 0x%X 0x%X",bpm_house[i],read_dat[0],
       read_dat[1],read_dat[2]);
    error_message_c(buff);
    
    sts = dio_set_raw_c(di,PRSET,(char *)setup_dat,sizeof(setup_dat));
    if(sts!=DIO_OK) {
       error_display_c("Error writing data to BPM house",ERR_ACNET,sts);
       ret_sts = sts;
       continue;
    }
  }
  return(ret_sts);
}
#ifdef LINUX
/*
 * Values accepeted for scrub issues are ...
 * not-addressed (issue present and not addressed) or
 * addressed (issue present and verified ok or fixed).
 * No key-value string is to be treated as not-addressed.
 * If there is no such issue at all then no string is
 * needed at all.
 */
static char const * const LcppScrubIssues[] __attribute__((unused)) = {
    "$LcppScrubIssues: fp-network-use=addressed $",
    };
#endif
