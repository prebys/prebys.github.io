/*  12-3-99	Herrup		Fixed handling of masks for bad bpm/skip loc */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>

#include "gen.h"
#include "lib465.h"
#include "otable.h"
#include "obc.h"
#include "corr.h"
#include "util.h"
#include "bcorrsys.h"
#include "boosramp.h"
#include "sorbitsvd.h"  
#include "model.h"
#include "bpm.h"

#define MAX_CORRECTORS BOOSTER_MAX_CORRECTORS

/* Initialization modes for the ramps */
#define INIT_MODE_CURRENT 0   /* Current setting (set to DAC if ramp off) */
#define INIT_MODE_DAC 1       /* Initialize to flat ramp at DAC value */
#define INIT_MODE_ZERO 2      /* Set to all zero's (test purposes only) */


/*****************************************************************/
/* Make the command menu global                                  */
/*****************************************************************/
 static  int	ncd = 13, nstp = 10;
 static  char	cdtxt[][21] = { "Plane:", 
                         "Apply p correction?", "Desired orbit:", 
                         "Step cut(%):",
                         "BPM source:",
                         "Correction Type:",
                         "Examine Breakpoint:",
                         "Maximum Passes:",
                         "Ramp Number:",
                         "TCLK: ",
                         "Drift (BEX/RPOS): ",
                         "Trim Headroom: ",
                         "Ramp State: "
                         };
 static  char	actxt[][24] = {"Read desired orbit", 
                         "Read BPMs/Replot", "Init Ramps             ",
                         "Calc corrections", 
                         "Calc predicted orbit", "Diag plots",
                         "Send new settings","",
                         "Save Ramps","Restore Ramps"};
 static  char      diag_plot_list[][15] = {"RMS vs time   ",
                                                "Channel Orbit"};
 static  char      orbit_drift_txt[][9] = {"Lock    ","Predict ",
                                                "Suppress"};
 static  char      *ramp_state_txt[]={"Disabled","Enabled","Multiple",
                                           "Undefined"};                                                  
 static int             ramp_state=ENABLE_STATE_UNDEFINED;


int	dif_orbit = 1;
int	subdes = TRUE;

char	stat1[RING_SIZE];

float	diff_orbit[RING_SIZE];

static	int	replot_switch = 0;

static	int	notch_index;
static int  notch_state_row;
static int notch_state_col;

static char messbuff[128];

/* The following are loaded in the main program */
extern bcorr_info *corrsys;
extern BOOSTER_RAMP *bramp;


float bump_matrix[RING_SIZE/2][RING_SIZE/2];
float bump_inv[RING_SIZE/2][RING_SIZE/2];

FT_Ramp corrector_ramp[MAX_CORRECTORS];      /* This is the array of ramps */
FT_Ramp corrector_init_ramp[MAX_CORRECTORS]; /* Initial ramps (for restore) */
short rawdat[MAX_SLOTS][2];                    /* Workspace */
short clock_table[MAX_INTERRUPTS][MAX_EVENTS]; /* Workspace */

/* These are the things associated with the BEX bumps */

//   eliminate dog 13 and cooresponding bex 12,13  6-sep2006  WLM
//#define NBEX 4
//int bex_period[NBEX] = {2,3,12,13};
// //  bex_ramp, bex_name  does not seem to be used anymore---b:bex13z is obsolete
// //              W Marsh  1-Sep-2006
// // static char *bex_name[NBEX] = {"B:BEX3Z","B:BEX3Z","B:BEX13Z","B:BEX13Z"};
// // FT_Ramp bex_ramp[NBEX];
// float bex_scale[NBEX] = {-11.5,-11.5,-10.1,-10.1};  /* mm/A @ K=400 MeV */
// int bex_dog[NBEX] = {0,0,1,1};  /* Pointer to the dogleg associated with the BEX bump */
//#define NDOG 2
// static char *dog_name[NDOG] = {"B:DOGL3","B:DOG13"};

#define NBEX 2
int bex_period[NBEX] = {2,3};
float bex_scale[NBEX] = {-11.5,-11.5};  /* mm/A @ K=400 MeV */
int bex_dog[NBEX] = {0,0};  /* Pointer to the dogleg associated with
                                   the BEX bump */
#define NDOG 1
static char *dog_name[NDOG] = {"B:DOGL3"};

/* This struct will hold the parameters associated with the
   doglegs. */
typedef struct {
   float current;    /* Current in the dogleg.  Read from device */
   float amps2mm;    /* Conversion from amps to mm at p = p0 */
   float septum_position; /* position of the septum (from CL) */
   float beta;       /* The beta function at the middle of the dogleg */
   float acceptance; /* The desired acceptance (in pi-mm-mrad) */
}  __attribute__((packed)) /* Added by the PACKINATOR(tm) */ dogpar_t;

dogpar_t dogpar[NDOG];



/* This is associated with the ROF currve */
#define NROF 1
int rof_period[NROF] = {18};
static char *rof_name[NROF] = {"B:ROFZ"};
float rof_scale[NROF] = {1.};
FT_Ramp rof_ramp[NROF];

/* We will try to lock the horizontal position at the collimators, and
   let it "breath with the RPOS curve everywhere else */
#define NCOLL_PERIOD 3
int coll_period[NCOLL_PERIOD]={5,6,7};


static short	prop_set[NUM_CORRECTORS] = { PRSET, PRSET, PRSET, PRSET,
				  PRSET, PRSET, PRSET, PRSET,
				  PRSET, PRSET, PRSET, PRSET,
				  PRSET, PRSET, PRSET, PRSET,
				  PRSET, PRSET, PRSET, PRSET,
				  PRSET, PRSET, PRSET, PRSET };
				  
				  
				  
static void	notch_callback_function ( short window_id, void *notch_data,
	WINDOW_FIELD_INTERRUPT_DATA *interrupt_data );				  


extern "C" int 	corr_init(void);
extern "C" int 	corr_end(void);
extern "C" int 	corr_bpm(void);
extern "C" int 	corr_calc(int pl);
extern "C" int 	corr_read_ramps(void);
extern "C" int 	corr_bpm2(void);
extern "C" int 	corr_send(void);
extern "C" int 	corr_restore(void);
extern "C" int     corr_save_ramps(void);
extern "C" int 	corr_load_ramps(void);
extern "C" int 	pre_cons(void);
extern "C" void 	pre_bpm(void);
extern "C" int     corr_read_desire(char *);
extern "C" void	fill_bump_matrices(int);
extern "C" int set_notch(int state);
extern "C" int verify_notch(int state,int *old_state);
extern "C" int     invert_bumps(float A[24][24], float Ainv[24][24]);

extern "C" int 	set_alarm_limits ( int* indices, short* in_status,
	float* currents );

extern "C" void 	corr_init_plane_data(void);

extern "C" void	update_params ( int win, int row, int col );
extern "C" void    rank_bumps(int, float *, int *);
extern "C" int     corr_init_ramps(int);
extern "C" int     corr_disable_ramps(void);
extern "C" void    get_corrector_limits(int, int, float *,float *, float *);
extern "C" int     check_ramp(FT_Ramp *);
extern "C" void    init_ramp(FT_Ramp *, float);
extern "C" int     get_drift_pars(void);
extern "C" int     get_drift_ramps(void);
extern "C" float   orbit_drift(int, int, int);
extern "C" float   ramp_value(FT_Ramp *, float);
extern "C" int     get_dogpars(void) ;
extern "C" float   dog_drift(dogpar_t *d, int ibrk);
extern "C" int     corr_getevents(void);
extern "C" int corr_setevents(void);
extern "C" int     select_breakpoint(int *);

/*********************************************************/
/* circular index.  Like mod, but deals well with        */
/* negative numbers                                      */
/*********************************************************/
extern "C" int cindx(int i, int j) {
  return((i>=0)? i%j : j-1+(i+1)%j);
}


/******************************************************************************/
/*+ void corr_init(void)
-*/
/******************************************************************************/
extern "C" int corr_init(void)
{

 int i,sts;
 if (!cor) {
    cor = (CORR_STRUCT *) malloc(sizeof(CORR_STRUCT)); 
    if (!cor) util_errpost(MYERR,"Err malloc mem for corr",NULL);
  }

 cor->stepcut = setp.stepcut / 100.;
 cor->max_pass = 15;   /* initial value for interative passes */
 cor->ramp_num = 1;
 cor->trim_headroom = 0.;  /* One amp of trim room at limits */
 cor->plane=setp.plane = VERT; /* start with vertical plane */
 setp.alg_type = ALG_TYPE_SVD;
 /* Initialize the trigger event array */
 cor->nevents = 1;
 cor->events[0] = 0x17;  /* Booster reset */
 for(i=1;i<MAX_EVENTS;i++) cor->events[i] = NULL_EVENT;
 
 cor->orbit_drift_mode = ORBIT_DRIFT_PREDICT;
 
 /* Initialize the corrector system */
 sts = bcorrsys_ini(&corrsys);
 if(sts != 0) {
     error_display_c ("Error initializing booster corrector system ",
		      ERR_ACNET,sts);
   return(sts);
 }
 /* Get the ramps which affect the drift */
 sts = get_drift_pars();
 if(sts != 0) {
     error_display_c ("Error reading drift ramps ",
		      ERR_ACNET,sts);
   return(sts);
 }
 
 corr_init_plane_data();
 corr_init_ramps(INIT_MODE_ZERO);
 corr_getevents();   /* Get the trigger events loaded in the clock table */

 return(0);

}


/******************************************************************************/
/*+ void corr_end(void)
-*/
/******************************************************************************/
extern "C" int corr_end(void)
{

 int		sts;
 sts = clib_free((char **)&cor);
 return(sts);

}


/******************************************************************************/
/*+ void corre(void)
-*/
/******************************************************************************/
extern "C" void corre(void)
{

 int 			i,pl,abort;
 short 			inwid, intyp;
 int 			inrow, incol, info, sts;
 int 			r1 = 3, c1 = 2, c2 = 37, c3 =60;
 int 			width = 78, height = 20;
 int			la;
/* float 			x,*addr;*/
/* static	const char	numnam[] = "0123456789";*/
 static int diag_plot_type=0;
 static int diag_per = 1;
 static int *diag_per_pnt;
 
 static  char      algnam[][6] ={ "3BUMP" , " SVD ", "LSSOL"};
 static	 char	algnam_long[][24] = {"        3 bump ",
                                       " least square with SVD",
                                       "least square with LSSOL"};
 static  char    	srcnam[][12] ={"BPM display", "Boos. file " };
 static  char    	dessrc[][12] ={"      all 0","desire file",
                                       "   bpm file"," breakpoint"};
 static  char	utxt[][7] = {"mm-rms","mm-rms","A.-ave","A.-ave",
                                      "A.-ave","mm-rms"};
 static		char	dftxt[][12] = {"Orbit      ", "Des. - Meas" };          

 static  char	plt_def_smb[] = "D.";

 static  char      init_mode_txt[][19] = {"To Current Setting",
                                               "To DC DAC value   ",
                                               "To Zero (Test!!)  "};
 int init_mode;
 static  char      restore_opt_txt[][16] = {"To Last Setting",
                                                 "From File      "};
 int restore_opt;
 static  char      ramp_command_txt[][8]={"Disable",
                                               "Enable "};
 int ramp_command;

 static char trig_string[TRIG_STRING_LEN];

 int			plt_def[10];
 int			step=0;
 int			disp_par = TRUE;
 int			smoo = FALSE;
 float			rms;
 char			stat[RING_SIZE];

 int			oldbpmsource,oldalgtype,oldbrkpt,oldmax_pass;
 int                    oldramp;
 static int             last_ramp_state=ENABLE_STATE_UNDEFINED;
 
 
 int ioffs,ielem;
 
 float dx_before[MAX_BREAKPOINTS],dx_after[MAX_BREAKPOINTS];

 static		char	measdes[][2] = { "M", "D" };


 //static char	plane[][3] = 	{ "HS", "VL" };

 static		char notch_handle[] = "notch_handle";
 int	add_if_exists = TRUE;
 int	notch_id;
 unsigned int	interrupt_mask = WMNGR_INT_KBD;

 void	*notch_data = (void *)NULL;



float periodMin = 1.;
float periodMax = 24.;
int periodInputType = INP_LONG;

 corr_init();
 pl = cor->plane = setp.plane;

 for (i = 0; i < nstp; i++) plt_def[i] = TRUE; 
 la = 1;
 sts = window_construct_c(3, 1, height + 2, width + 2, FALSE,BLUE,WHITE,
			  "", &wi3);

 window_tvm_c(wi3,r1-2,c1+4,"Setup Parameters",16,CYAN);
 window_tvm_c(wi3,r1-2,c2+2,"Commands                Summary    Plot",
	39,CYAN);
 for (i = 0; i < ncd; i++)
    window_tvm_c(wi3,r1+i,c1,(char *)cdtxt[i],strlen(cdtxt[i]),CYAN);

 window_tvm_c ( wi3, r1 + ncd, c1, "B:NOTCH", 7, RED );
 update_params( wi3,r1+ncd,c1);
 sts = window_field_create_c ( wi3, r1 + ncd, c1 + 10, 1, 3,
	(window_field_function)notch_callback_function, notch_data, interrupt_mask,
	add_if_exists, &notch_id, notch_handle );

 for (i = 0; i < nstp; i++)
   { 
       window_tvm_c(wi3,r1+i,c2,(char *)actxt[i],strlen(actxt[i]),CYAN);
     if ( i == 1 )
       {
	 window_tvm_c ( wi3, r1 + i, c2 + 10, "Replot",
		       6, BLUE );
	 window_tvm_c ( wi3, r1 + i, c2 + 9, "/", 1, RED );
       }
   }
 for (i = 0; i < nstp-4; i++) window_tvm_c(wi3,r1+i,c2-4,":::",3,GREEN);
 for (i = 0; i < nstp-5; i++) {
  if ( i != 5 )
     {
       window_tvm_c(wi3,r1+i,width-11,utxt[i],6,CYAN);
       window_tvm_c(wi3,r1+i,width-3,&plt_def_smb[plt_def[i]],1,
                 (plt_def[i]? GREEN:RED));
       window_tvm_c(wi3,r1+i,width-2,".",1,GREEN);
     }
  }
 for (i = 0; i < 6; i++) window_tvm_c(wi3,r1+i,width-1,".",1,GREEN);
 window_tvm_c ( wi3, r1 + 1, width - 1, measdes[dif_orbit], 1, 
	       tv_colors ( YELLOW, BLACK ) );
 window_draw_char_c(wi3,r1+setp.stop_step,c2-5,SYMBOL_UP_ARROW,YELLOW);
 window_hline_c(wi3,r1-1,0,width+2,BLUE,WMNGR_TEES);
 window_vline_c(wi3,r1-1,c2-7,height+2,BLUE,WMNGR_TEES);

 while (TRUE)
  {
   window_intype(&inwid,&intyp,&inrow, &incol,&info);
   switch (intyp)
    {
     case INTTRM:
      corr_trm();
     case INTKBD:

      if (inwid != wi3) {
         window_blank_c(wi3,r1+setp.stop_step,c2-5,1);
         sts = mio_kbi(inwid, inrow, incol);
         window_draw_char_c(wi3,r1+setp.stop_step,c2-5,SYMBOL_UP_ARROW,YELLOW);
         disp_par = TRUE;
         /* never exit from this page 
	 if (sts) goto ret; */
       }
      else if (in_window_box_c(wi3,r1,nstp,c2-4,45)) {
         step = inrow-r1;
         if (incol >= c2 && incol < (int)(c2+strlen(actxt[step]))) {
            smoo = TRUE;
            window_blank_c(wi3,r1+setp.stop_step,c2-5,1);
            if (step < 8) setp.stop_step = step;
            window_draw_char_c(wi3,r1+setp.stop_step,c2-5,SYMBOL_UP_ARROW,YELLOW);
          }
         else if (step < 6 && incol >= c2-4 && incol < c2) {
            if (decide_c(r1+2,c1+15,"Go from here to arrow ?",23)) {
               smoo = TRUE;
               abort_init();
             }
          }
         else if (incol == width-3) {
            plt_def[step] ? (plt_def[step]=FALSE) : (plt_def[step]=TRUE);
            window_tvm_c(wi3,r1+step,width-3,&plt_def_smb[plt_def[step]],1,
                         (plt_def[step]? GREEN:RED));
          }
         else if (incol == width-2) {
            corr_plt(step);
          }
         else if (incol == width-1) {
            if (step == 1) 
	      {
		my_wmenu_c(0,0,2,12,(char *)dftxt,"",&dif_orbit);
		window_tvm_c ( wi3, r1 + 1, width - 1, measdes[dif_orbit],
			1, tv_colors ( YELLOW, BLACK ) );
	      }
            else if (step == 4) 
	      {
	      	window_tvm_c ( wi3, r1 + 4, width - 1, measdes[subdes], 1, 
			      tv_colors ( YELLOW, BLACK ) );
	      }
          }
         if (smoo) {
            for (i = 0; i < nstp-4; i++)
	      window_tvm_c(wi3,r1+i,c2-4,":::",3,GREEN);
         }
       }
      else if (in_window_box_c(wi3,r1,nstp-4,c2-6,2)) {
         window_blank_c(wi3,r1+setp.stop_step,c2-5,1);
         setp.stop_step = inrow-r1;
         window_draw_char_c(wi3,r1+setp.stop_step,c2-5,SYMBOL_UP_ARROW,YELLOW);
         for (i = 0; i < nstp-4; i++)
            window_tvm_c(wi3,r1+i,c2-4,":::",3,GREEN);
       }
      else if (in_window_field_c(wi3,r1,c1+21,4)) {
         (setp.plane==HORZ) ? (setp.plane=VERT) : (setp.plane=HORZ);
         pl = cor->plane = setp.plane;
         corr_init_plane_data();
         corr_getevents();  /* Get the default clock events for this ramp */
         disp_par = TRUE;
	 replot_switch = 0;
	 window_tvm_c ( wi3, r1 + 1, c2 + 10, "Replot",
		       6, BLUE );
       }

      else if (in_window_box_c(wi3,r1+1,12,c1+6,22)) {
         i = inrow-r1;
         if (in_window_field_c(wi3,r1+1,c1+21,3)) {
            (setp.if_p_corr==1) ? (setp.if_p_corr=0) : (setp.if_p_corr=1);
          }
         else if (in_window_field_c(wi3,r1+2,c1+15,12)) {
            my_wmenu_c(0,0,4,12,(char *)dessrc,"",&setp.if_d_orbit);
            window_blank_c(wi3,r1+2,c1+15,12);
            window_tvm_c(wi3,r1+2,c1+15,(char *)dessrc[setp.if_d_orbit],
                      strlen(dessrc[setp.if_d_orbit]),GREEN);
            if (setp.if_d_orbit == DES_DES_FILE) deso.hdr.plane = INVALID;
          }
         else if (in_window_field_c(wi3,r1+3,c1+21,7)) {
            window_input_value_c(wi3,r1+3,c1+21,(void *)&setp.stepcut,
                                 CNV_LONG,3,RED);
          }
         else if (in_window_field_c(wi3,r1+4,c1+15,11)) {
	   oldbpmsource = setp.bpmsource;
            my_wmenu_c(10,c1+15,2,12,(char *)srcnam,"",&setp.bpmsource);
	    if ( ( setp.bpmsource == 0 ) || ( setp.bpmsource == 1 ) )
		{
		  window_blank_c(wi3,r1+4,c1+15,11);
		  window_tvm_c(wi3,r1+4,c1+15,(char *)srcnam[setp.bpmsource],
			       11,GREEN);
		}
	    else
	      {
		setp.bpmsource = oldbpmsource;
		window_blank_c(wi3,r1+10,c1+15,11);
		window_tvm_c(wi3,r1+10,c1+15,(char *)srcnam[setp.bpmsource],
			       11,GREEN);
		error_display_c ( "Illegal option. Source set to Display",
				 ERR_NONE, 0 );
	      }
          }
	 else if (in_window_field_c(wi3,r1+5,c1+21,5)) {
	   oldalgtype = setp.alg_type;
	   my_wmenu_c(11,c1+21,3,24,(char *)algnam_long,"",&setp.alg_type);
	   if(( setp.alg_type<0)||(setp.alg_type>2)) {
	     error_display_c("Illegal algorithm.",ERR_NONE,0);
	     setp.alg_type = oldalgtype;
	   }
	   window_blank_c(wi3,r1+5,c1+21,5);
	   window_tvm_c(wi3,r1+5,c1+21,(char *)algnam[setp.alg_type],5,GREEN);
	 }
	 else if (in_window_field_c(wi3,r1+6,c1+20,3)) {
	   oldbrkpt = cor->curr_brkpt;
	   /* window_input_value_c(wi3,r1+6,c1+20,(void *)&cor->curr_brkpt,
                                 CNV_LONG,2,RED); */
           select_breakpoint(&cor->curr_brkpt);
	   if(cor->curr_brkpt<0||cor->curr_brkpt>=bramp->num_brkpts) {
	     error_display_c("Illegal breakpoint",ERR_NONE,0);
	     cor->curr_brkpt = oldbrkpt;
	   }
	   window_blank_c(wi3,r1+6,c1+20,8);
	   window_display_value_c(wi3,r1+6,c1+20,(void *) &cor->curr_brkpt,CNV_LONG,2,GREEN);
	 }
	 else if (in_window_field_c(wi3,r1+7,c1+21,6)) {
	   oldmax_pass = cor->max_pass;
	   window_input_value_c(wi3,r1+7,c1+21,(void *)&cor->max_pass,
                                 CNV_LONG,2,RED);
	   if((cor->max_pass<0)||(cor->max_pass >= MAX_PASSES)) {
	     error_display_c("Too many passes",ERR_NONE,0);
	     cor->max_pass = oldmax_pass;
	   }
	   window_blank_c(wi3,r1+7,c1+21,2);
	   window_display_value_c(wi3,r1+7,c1+21,(void *) &cor->max_pass,CNV_LONG,2,GREEN);
	 }
	 else if (in_window_field_c(wi3,r1+8,c1+21,6)) {
	   oldramp = cor->ramp_num;
	   window_input_value_c(wi3,r1+8,c1+21,(void *)&cor->ramp_num,
                                 CNV_LONG,2,RED);
	   if((cor->ramp_num<1)||(cor->ramp_num > MAX_RAMPS)) {
	     error_display_c("Illegal Ramp Number",ERR_NONE,0);
	     cor->ramp_num = oldramp;
	   } else {
	     corr_getevents();  /* get the clock events for this ramp */
           }
	   window_blank_c(wi3,r1+8,c1+21,2);
	   window_display_value_c(wi3,r1+8,c1+21,(void *) &cor->ramp_num,CNV_LONG,2,GREEN);
	 }
	 else if (in_window_field_c(wi3,r1+9,c1+6,22)) {
	   window_input_value_c(wi3,r1+9,c1+6,(void *) trig_string,
	        CNV_CHAR,20,RED);
	   lib465_decode_trigger_string(trig_string,cor->events,
	     &cor->nevents);
	   lib465_encode_trigger_string(cor->events,cor->nevents,
	      trig_string);
	   window_display_value_c(wi3,r1+9,c1+6,(void *) trig_string,
	         CNV_CHAR,20,GREEN);
	   if(decide_c(WMNGR_CENTER,WMNGR_CENTER,"Load Clock Table Now?",
	      strlen("Load Clock Table Now?"))) {
	      sts = corr_setevents();
	   }
	 } else if(in_window_field_c(wi3,r1+10,c1+strlen(cdtxt[10]),
	    strlen(orbit_drift_txt[cor->orbit_drift_mode]))) {
	    my_wmenu_c(r1+10,c1+10,3,9,(char *)orbit_drift_txt,"",
	             &cor->orbit_drift_mode);
	    window_display_value_c(wi3,r1+10,c1+strlen(cdtxt[10]),
	     (void *) orbit_drift_txt[cor->orbit_drift_mode],
	     CNV_CHAR,strlen(orbit_drift_txt[cor->orbit_drift_mode]),
	     GREEN);
	 } 
	 else if (in_window_field_c(wi3,r1+11,c1+strlen(cdtxt[11]),6)) {
	   window_input_value_c(wi3,r1+11,c1+strlen(cdtxt[11]),
	         (void *)&cor->trim_headroom,
                                 CNV_FLOAT,5,RED);
	   window_blank_c(wi3,r1+11,c1+strlen(cdtxt[11]),6);
	   window_display_value_c(wi3,r1+11,c1+strlen(cdtxt[11]),
	    (void *) &cor->trim_headroom,CNV_FLOAT,5,GREEN);
	 } 
	 else if (in_window_field_c(wi3,r1+12,c1+strlen(cdtxt[12]), 12)) {
            my_wmenu_c(0,0,2,strlen(ramp_command_txt[0])+1,
                       (char *)ramp_command_txt,"",&ramp_command);
            bcorrsys_plane_ramp_state(LIB465_SET,pl,&ramp_command);
         } else goto out1;
         disp_par = TRUE;
       }
      out1:break;

     case INTPER:
      /* See if anything has changed since last time */
      bcorrsys_plane_ramp_state(LIB465_GET,cor->plane,&ramp_state);
      if(ramp_state!=last_ramp_state) {
        disp_par=TRUE;
        last_ramp_state = ramp_state;
      }

      if (disp_par) {
         disp_par = FALSE;
         corr_disp_par(wi3,r1,c1);
         window_tvm_c(wi3,r1+2,c1+15,(char *)dessrc[setp.if_d_orbit],
                      strlen(dessrc[setp.if_d_orbit]),GREEN);
         window_tvm_c(wi3,r1+4,c1+15,(char *)srcnam[setp.bpmsource],11,GREEN);
       }

      if (smoo) {
         window_tvm_c(wi3,r1+step,c2,(char *)actxt[step],
                        strlen(actxt[step]),bf[2]);
         if (step == 0) {
            sts = corr_read_desire(stat1);
            if(sts!=0) goto out2;
            rms = calc_rms(RING_SIZE,stat1,deso.x.floats);
            memset(stat,FALSE,RING_SIZE);
            window_display_value_c(wi3,r1+step,c3,
                                 (void *)&rms,CNV_FLOAT,6,CYAN);
          }
         else if (step == 1) {
	   if ((incol>= 37)&&(incol<=45)) replot_switch = 0;
           sts = corr_bpm();          /* b0_rms in mm */
           if (!sts) window_display_value_c(wi3,r1+step,c3,
                               (void *)&cor->b0_rms[cor->curr_brkpt],CNV_FLOAT,6,CYAN);
          }
         else if (step == 2) {
             my_wmenu_c(0,0,3,19,(char *)init_mode_txt,"",&init_mode);
             sts = corr_init_ramps(init_mode);
           }
         else if (step == 3) {
            sts = corr_calc(setp.plane);           /* dthet_ave in mRAD */
            if (!sts) window_display_value_c(wi3,r1+step,c3,
                             (void *)&cor->dthet_ave[cor->curr_brkpt],CNV_FLOAT,6,CYAN);
          }
         else if (step == 4) {
            sts = corr_bpm2();          /* b2_rms in mm */
            if (!sts) window_display_value_c(wi3,r1+step,c3,
                             (void *)&cor->b2_rms[cor->curr_brkpt],CNV_FLOAT,6,CYAN);
          }
         else if (step == 5) {
            /* If we haven't calculated the correction, then calculate it */
            if(!cor->flag[4]) {
               sts = corr_bpm2();          /* b2_rms in mm */
               if (!sts) window_display_value_c(wi3,r1+step,c3,
                             (void *)&cor->b2_rms[cor->curr_brkpt],CNV_FLOAT,6,CYAN);
            }
              
            pl = cor->plane;
            my_wmenu_c(0,0,2,15,(char *)diag_plot_list,"",&diag_plot_type);
            switch(diag_plot_type) {
            case 0:
              disp_rms_vs_time(pl,pltpar.gx,bramp->num_brkpts-1,
                 bramp->t,cor->b1_rms,cor->b2_rms);
              break;
            case 1:
              diag_per_pnt = &diag_per;
              winput_c(NULL,inrow,incol,"Period (1-24):",14,&periodMin,&periodMax,(void **)&diag_per_pnt,
                       1,&periodInputType);
              ioffs = (pl==HORZ)? 1: 0;
              ielem = (diag_per-1)*2 + ioffs;
              for(i=0;i<bramp->num_brkpts-1;i++) {
                dx_before[i] = cor->dx1[i][ielem];
                dx_after[i] = cor->dx1[i][ielem]-cor->dx2[i][ielem];
              }
              disp_dev_vs_time(pl,pltpar.gx,diag_per,bramp->num_brkpts-1,
                bramp->t,dx_before,dx_after);
              break;
           }         
              

            sts=0;
         }
         else if (step == 6)  {
           sts = corr_send();
           disp_par=TRUE;
         }
         else if (step == 8) sts = corr_save_ramps();
         else if (step == 9) {
            my_wmenu_c(0,0,2,16,(char *)restore_opt_txt,"",&restore_opt);
            if(restore_opt==0) sts = corr_restore();
            else sts = corr_load_ramps();
            disp_par=TRUE;
         }
         else goto out2;
         window_tvm_c(wi3,r1+step,c2,(char *)actxt[step],
                        strlen(actxt[step]),CYAN);
	 if ( step == 1 )window_tvm_c ( wi3, r1 + step, c2 + 9, "/",
		1, RED );
         if (step < 8) {  /* allow multi-steps and mark status */
            if (!sts) {
               window_tvm_c(wi3,r1+step,c2-3,"OK",2,GREEN);
               if (plt_def[step]) corr_plt(step);
               if (setp.stop_step > step) {
                  abort = abort_check();
                  if (!abort) {
                     step++;
                     goto out2;
                   }
                }
             }
            else window_tvm_c(wi3,r1+step,c2-3,"ER",2,RED);
          }
         abort_cancel();
         smoo = FALSE;
       }
      out2:  break;
 
    }
 }
 del_window(&wi3);
 corr_end();
 return;

}
/*****************************************************************************/
/* Read desired orbit. This was really shit, so I cleaned it up              */
/*****************************************************************************/
extern "C" int corr_read_desire(char *kill) {
    int i,k,nfile,pl,sts,sel,old_notch_state;
    BPM_TABLE_STRUCT obt;
    int n_masked;
    int masked[RING_SIZE];
    char message[256];
    static char *plane[] = {"HS","VL"};
     
    pl = setp.plane;

    /* Initialize the skip record */
    for(i=0;i<RING_SIZE;i++) {
       if(i%2==pl) skip.x.longs[i] = 7;
       else skip.x.longs[i] = 0;
    }
    
    /* Fill the positions */
    sel = setp.if_d_orbit;
    if(sel==DES_CENTER) {              /* Set to middle of ring */
       for (i = 0; i < RING_SIZE; i++) deso.x.floats[i] = 0.;
       
    } else if (sel==DES_DES_FILE) {   /* Read from desire file */
       if ((sts=desob_r(setp.plane,deso.hdr.fid,&deso,&skip))!=DIO_OK) return(sts);
    } else if ((sel==DES_BPM_FILE)||(sel==DES_BREAKPT)) {                         
       if(sel==DES_BPM_FILE) {         /* Read from BPM file */
          sts = read_bpm_file(&obt);
       } else {                          /* Read from real BPM's */
          verify_notch(FALSE,&old_notch_state);
          sts = read_bpm(cor->events[0],0,0,MAX_BREAKPOINTS,&obt);
          if(old_notch_state) set_notch(TRUE);
       }
       if(sts!=DIO_OK) return(sts);
       /* Plug values into the desired orbit structure */
       for(i = 0; i<RING_SIZE ; i++) {
           if (obt.stat[pl][i]==BPM_OK) {
              deso.x.floats[i] =  
		    obt.xy[pl][bramp->ipnt[cor->curr_brkpt]][i];
		         - orbit_drift(pl,cor->curr_brkpt,i);
	   } else {
             deso.x.floats[i]=0.;
	     skip.x.longs[i]=7;
	   }
	}  
        /* Fill out rest of desired orbit header */
        deso.hdr.date = clinks_now();
        deso.hdr.lock = 1;
        deso.hdr.plane = pl;
        deso.hdr.slot = 0;
        deso.hdr.tclk = 0;
        /* Write this to a desire file */
        if(decide_c(WMNGR_CENTER,WMNGR_CENTER, "Save to a desire file?",0)) {
            nfile = gen_hdr_sel(DESOB,0,pl,0,&deso.hdr,&k,TRUE);
	    if (nfile > 0 && k >= 0) {
	       inptxt_c(WMNGR_CENTER,WMNGR_CENTER,
		  "title",5,deso.hdr.title,-TIT_LEN);
	       memcpy ( skip.hdr.title, deso.hdr.title,TIT_LEN * sizeof ( char ) );
	       deso.hdr.fid = k;
	       desob_w(&deso,&skip,TRUE);
	    }
	}
    } else { /* ????? */
       error_display_c("Err: Illegal desired orbit option",ERR_ACNET,MYERR);
       return(MYERR);
    }
    /* Go through and see what was masked */
    n_masked = 0;
    for(i=0;i<RING_SIZE;i++) {
       if(skip.x.longs[i]!=0) kill[i] = 1; 
       else kill[i] = 0; 
       if(i%2 == pl) skip.x.longs[i] = 7;
       else {
          if(skip.x.longs[i]!=0) masked[n_masked++] = i/2 + 1;
       }
    }
    /* tell about any extra masked correctors */
    if ( n_masked != 0 ){
       sprintf (message,
	    "The following BPMs/correctors are masked: %.*s ",
				2, plane[cor->plane] );
       for ( i = 0; i < n_masked; i++ ) {
           sprintf(&message[strlen(message)],"%d",masked[i]);
           if(i<(n_masked-1)) sprintf(&message[strlen(message)],",");
        }
	acknowledge_c ( WMNGR_CENTER, WMNGR_CENTER,
		message, strlen(message) );
    }
    cor->flag[0]=TRUE;
    cor->flag[1]=cor->flag[2]=cor->flag[3]=FALSE;
    return(0);
}  


/******************************************************************************/
/*+ int corr_bpm(void)
	step 1: take bpm data
-*/
/******************************************************************************/
extern "C" int corr_bpm(void)
{

 int		frame,sts;
 int            old_notch_state;
 int		i;

 if(!cor->flag[0]) {
    error_message_c("Haven't read desired orbit yet, so reading now");
    sts = corr_read_desire(stat1);
    if(sts!=0) return(sts);
  }
if ( replot_switch == 0 )
  {
 if ( setp.bpmsource == INPUT_BPM_DISPLAY )
   {
   frame = 0;
   verify_notch(FALSE,&old_notch_state);
   sts = read_bpm(cor->events[0],0,0,MAX_BREAKPOINTS,&cor->b1);
   if(old_notch_state) set_notch(TRUE);
  }                                       
 else if (setp.bpmsource == INPUT_BPM_FILE) {
    sts = read_bpm_file(&cor->b1);
  }
 else return(util_errpost(MYERR,"Err specified a invalid source as input",NULL));
 window_tvm_c ( wi3, 4, 47, "Replot", 6, CYAN );
 }

 replot_switch = 1;
 sts = 0;

 for ( i = 0; i < RING_SIZE; i++ )
   {
     stat1[i] = 0;
     diff_orbit[i] = deso.x.floats[i] - 
         cor->b1.xy[cor->plane][bramp->ipnt[cor->curr_brkpt]][i]+
         orbit_drift(cor->plane,cor->curr_brkpt,i);
     if ( ( skip.x.longs[i] != 0 ) || ( cor->bstat[i] != 0 ) )
       stat1[i] = 1;
   }

 if (!sts) {
    cor->flag[1] = TRUE;
    if ( dif_orbit == 0 )
	cor->b0_rms[cor->curr_brkpt] = 
	calc_rms(RING_SIZE,cor->bstat,
	   cor->b1.xy[cor->plane][bramp->ipnt[cor->curr_brkpt]]);
    if ( dif_orbit == 1 )
	cor->b0_rms[cor->curr_brkpt] = calc_rms ( RING_SIZE, stat1, diff_orbit );
  }

 return sts;

}


/*****************************************************************************/
/* This is the meat of the program.  It will apply a correction based on     */
/* which algorithm has been selected                                         */
/*****************************************************************************/
extern "C" int corr_calc(int pl) 
{
   /* Make sure the necessary steps have been done up to this point */
   if(!cor->flag[1]) {
     error_message_c("Reading BPM's...");
     corr_bpm();
   }
   if(!cor->flag[2]) {
     error_message_c("Initializing ramps...");
     corr_init_ramps(INIT_MODE_CURRENT);
   }
     
   /* Initialize the ramps to the starting value */
   memcpy(corrector_ramp,corrector_init_ramp,MAX_CORRECTORS*sizeof(FT_Ramp));
   switch (setp.alg_type) {
    case ALG_TYPE_3BUMP:
     return(alg_3bump(pl));
    case ALG_TYPE_SVD:
     return(alg_svd(pl));
    case ALG_TYPE_LSSOL:
     return(alg_lssol(pl));
   };
   return(-1);
}
/******************************************************************************/
/*+ int alg_3bump(int pl)
-*/
/*  Oct 31, 2001 E.Prebys Did a major rewrite to clean up                    */
/******************************************************************************/
extern "C" int alg_3bump(int pl)
{
 int		i,j,ic,ipnt,sts,ipass;
 int		bump;
 int            ibrk;
 int            ib[3];      /* pointers to bump elements */
 int            nbump;
 int            ioffs;
 float          *ratios,amps_per_mm;
 float          dx[RING_SIZE/2];  /* array of deviations by bump number */
 float          dx0[RING_SIZE/2];
 float          amps;
 int            use;
 float          dKickI[MAX_CORRECTORS];
 float          kickI[MAX_CORRECTORS];
 float          lastI[MAX_CORRECTORS];
 float          max_dI_lo[MAX_CORRECTORS],max_dI_hi[MAX_CORRECTORS];
 int            use_cor[MAX_CORRECTORS];  /* correctors to use */
 float          dI,tmp,scale;
 int            npass;
 float          pscale,rms_dev[MAX_PASSES];

 
  
 
 sts = pre_cons();
 if (sts) return(sts);
 pre_bpm();


 nbump = RING_SIZE/2;
 fill_bump_matrices(pl);

 if( pl == HORZ ) {
   ioffs = 1;  /* If horizontal, use only odd correctors */
 } else {
   ioffs = 0;  /* If vertical, use only even correctors */
 }

 /* Get pointers to associated correctors. Note, every other one
    will be -1 */
 
 error_message_c("Calculating corrections for all breakpoints ") ;

 /* we'll reserve the last breakpoint to put back the original value */
 for(ibrk = 0; ibrk<(bramp->num_brkpts-1) ; ibrk++) {  
    /* The bumps and inverse bum matrices are all calculated for
     *  400 MeV.  Must scale by actual momentum to do other break 
     *  points
     */  
    pscale = (bramp->p[ibrk])/(bramp->p[0]);
    get_corrector_limits(pl,ibrk,lastI,max_dI_lo,max_dI_hi);  /* Get the limits for this pass */
    /* This will map the existing masks onto an the physical
       correctors.  This array will also be used to flag
       correctors which are at their current limits, so it
       must be reinitialized every time */
       
 
    /* The differential kick for this time slice */    
    memset(kickI,0,sizeof(kickI));
    
    /* Load the deviations by and set the use flags "bump" */
    for (bump = 0; bump<nbump ;bump++) {
       use_cor[bump] = corrsys->isok[pl][bump];
       ipnt = bump*2+ioffs;   /* pointer to the central corrector of bump */
       dx0[bump]=dx[bump] = cor->dx1[ibrk][ipnt];
       use_cor[bump] *= cor->useced[ipnt];
    }

    npass = 0;
    memset(rms_dev,0,MAX_PASSES*sizeof(float));
    
    for (ipass = 0; ipass<cor->max_pass ; ipass++) {
       memset(dKickI,0,sizeof(dKickI));
       for (bump = 0; bump<nbump ;bump++) {
          if(pl==HORZ) {
             ratios = h_ratios[bump];
             amps_per_mm = h_amps_to_mm[bump];
          } else { 
            ratios = v_ratios[bump];
            amps_per_mm = v_amps_to_mm[bump];
          }
          /* Scale by the momentum */
          amps_per_mm *= pscale;
          /* load the pointers to the corrector elements associated with
             the bumps */
          ib[0] = bump-1;
          if(ib[0]<0) ib[0] += nbump;
          ib[1] = bump;
          ib[2] = bump+1;
          if(ib[2]>=nbump) ib[2] -= nbump;
          
          use = 1;
          /* The weakness of 3 bumps is we can only do them if
             ALL three correctors are useable */
          for(j = 0; j<3 ; j++ ) {
            if(!use_cor[ib[j]]) {
             use = 0;
             break;
            }
          } 
          if(!use) continue;   

          amps = dx[bump]*amps_per_mm;   /* amps at center of bump */
          for(j=0;j<3;j++ ) {
            dKickI[ib[j]] += amps*ratios[j];
          } 
        }
 /* Now go through and calculate the worst offenders. Set them to
    the max and reiterate */
        scale = 1.;
        for(i = 0; i<nbump; i++) {
          if(!(use_cor[i])) continue;   
          dI = dKickI[i] - lastI[i];
          if((dI<=max_dI_hi[i])&&(dI>=max_dI_lo[i])) continue;
          if(dI>0.) tmp = max_dI_hi[i]/dI;
          else tmp = max_dI_lo[i]/dI;
          /* If it was at limit to begin with, switch
             it off now */
          if(tmp < scale) scale = tmp;
        }
        if(scale < 1.) {          /* rescale if less than one */  
          for(i = 0; i<nbump; i++) {
             if(!(use_cor[i])) continue;
             dI = dKickI[i] - lastI[i];
             /* take care of the special case where it is already
                at the limit */
             if((dI>0.)&&(max_dI_hi[i]==0.)) use_cor[i] = FALSE;
             if((dI<0.)&&(max_dI_lo[i]==0.)) use_cor[i] = FALSE;
             
             /* Otherwise, scale and move on */
             dI *= scale;
             dKickI[i] = lastI[i] + dI;
             if((dI>0.)&&(dI>=.95*max_dI_hi[i])) use_cor[i] = FALSE;
             if((dI<0.)&&(dI<=.95*max_dI_lo[i])) use_cor[i] = FALSE;
             max_dI_hi[i] -= dI;  /* update limits */
             max_dI_lo[i] -= dI;
          }
        } 
        
        
        /* go through and back calculate the corrections */
        for(ic = 0; ic<MAX_CORRECTORS ; ic++) {
          kickI[ic] += dKickI[ic];
        }
        
        memcpy(dx,dx0,nbump*sizeof(float));
        for(i=0;i<nbump;i++) {
           for(j=0;j<nbump;j++) {
             dx[j] -= bump_inv[j][i]*kickI[i]/pscale;
           }
        }

        rms_dev[npass] = 0.;
        for(i=0;i<nbump;i++) {
           rms_dev[npass] += dx[i]*dx[i];
        }
        rms_dev[npass] /= (nbump);
        rms_dev[npass] = sqrt(rms_dev[npass]);
        npass++;
	if(scale==1.) break;
        memset(lastI,0,sizeof(lastI));
    }
    /* Fill the corrector ramp array */
    for(i=0;i<nbump;i++) 
      corrector_ramp[i].Time_Value[ibrk][1] += kickI[i];
    
     
    sprintf(messbuff,"%d %d: %f %f %f %f %f %f",ibrk,npass,
       rms_dev[0],rms_dev[1],rms_dev[2],rms_dev[3],rms_dev[4],
          rms_dev[npass-1]);
    error_message_c(messbuff);
     
 /* Now put back in the dtheta array */
    for(i=0;i<nbump;i++) {
      ipnt = 2*i+ioffs;
      cor->dthet[ibrk][ipnt] = kickI[i];
    }
    cor->dthet_ave[ibrk] = calc_ave(RING_SIZE,cor->gstat,cor->dthet[ibrk]);
 }

 /** set the last breakpoint = first breakpoint for next ramp */
 ibrk = bramp->num_brkpts-1;
 for(i=0;i<nbump; i++) {
   corrector_ramp[i].Time_Value[ibrk][1] = 
   	      corrector_ramp[i].Time_Value[0][1];
 }
 for(i=0;i<RING_SIZE;i++) {
    cor->dthet[ibrk][i] = cor->dthet[0][i];
 }

 if (sts) return(MYERR);
  /* dthet is angle change required, in mRAD */
 cor->flag[3] = TRUE;   /* Corrections calculated */
 cor->flag[4] = cor->flag[5] = FALSE;  /* Now predictions no longer valid */
 return(sts);

}
/******************************************************************************/
/*+ int alg_svd(int pl)
-*/
/*  Nov 15, 2001 E.Prebys Essentially a wrapper around Bill Marsh's routines  */
/******************************************************************************/
extern "C" int alg_svd(int pl)
{
 int i,ibrk,sts;
 int ipass,npass,ioffs,ic,ielem;
 
 /* In each pass these are the arrays of the useable correctors and
    their parameters */
 int ncorr;
 int icorr[MAX_CORRECTORS];
 float betacorr[MAX_CORRECTORS];
 float phasecorr[MAX_CORRECTORS];
 float dtheta[MAX_CORRECTORS];
 /* Ditto position monitors */
 int nbpm;
 int ibpm[RING_SIZE];
 float betabpm[RING_SIZE];
 float phasebpm[RING_SIZE];
 int ncorr_check,nbpm_check;
 float dx0[RING_SIZE];
 float dx[RING_SIZE];
 float dx_calc[RING_SIZE];
 float zero[RING_SIZE];
 float kickI[MAX_CORRECTORS];
 float dKickI[MAX_CORRECTORS];
 float lastI[MAX_CORRECTORS];
 float max_dI_hi[MAX_CORRECTORS],max_dI_lo[MAX_CORRECTORS];
 int  use_cor[MAX_CORRECTORS];
 int use_pos[MAX_CORRECTORS];
 float rms_dev[MAX_PASSES+1];  /* deviation with each pass */
 float threshold=.0001;
 float scale,dI,tmp;
 
 sts = pre_cons();
 if (sts) return(sts);
 pre_bpm();

 fill_bump_matrices(pl);


 if( pl == HORZ ) {
   ioffs = 1;  /* If horizontal, use only odd correctors */
 } else {
   ioffs = 0;  /* If vertical, use only even correctors */
 }

 memset(zero,0,sizeof(zero));  /* an array of zeros */
 
 error_message_c("Calculating corrections for all breakpoints ") ;

 /* we'll reserve the last breakpoint to put back the original value */
 for(ibrk = 0; ibrk<(bramp->num_brkpts-1) ; ibrk++) {  
    /* The bumps and inverse bum matrices are all calculated for
     *  400 MeV.  Must scale by actual momentum to do other break 
     *  points
     */  
    get_corrector_limits(pl,ibrk,lastI,max_dI_lo,max_dI_hi);  /* Get the limits for this pass */
    
    /* Load the array of BPM's */
    nbpm = 0;
    /* see which BPM's are useable */
    for(i=0; i< RING_SIZE/2; i++) {
      ielem = 2*i + ioffs;
      use_pos[i] = cor->usebpm[ielem];
      if(!use_pos[i]) continue;
      betabpm[nbpm] = lat.beta_b[ielem];
      phasebpm[nbpm] = lat.psi_b[ielem];
      ibpm[nbpm] = ielem;
      dx0[nbpm] = dx[nbpm] = -cor->dx1[ibrk][ielem]; /* the svd alg tries
                                                        to set this to zero */
      nbpm++;
    }         
    /* Use corrector if it's physically OK and if it's not been
       switched off.  This array will be updated as various correctors
       hit limits */
    for(ic=0;ic<MAX_CORRECTORS;ic++) {
       ielem = 2*ic+ioffs;
       use_cor[ic] = corrsys->isok[pl][ic] && cor->useced[ielem]; 
    }
       

    npass = 0;
    memset(rms_dev,0,sizeof(rms_dev));
    memset(kickI,0,sizeof(kickI));

    
    /* calculate the initial RMS */
    rms_dev[0] = 0;
    for(i = 0; i<nbpm; i++ ) {
       rms_dev[0] += dx[i]*dx[i];
    }
    rms_dev[0] = sqrt(rms_dev[0]/nbpm);
    
    for (ipass = 0; ipass<cor->max_pass ; ipass++) {
      memset(dKickI,0,sizeof(dKickI));
      /* Have to fill these arrays inside the loop because
         use_cor changes */
      ncorr = 0;  /* this might change each pass */
      for(ic = 0; ic<MAX_CORRECTORS; ic++) {
        ielem = ic*2+ioffs;  /* HS and VL */
        if(use_cor[ic]) {
          betacorr[ncorr] = lat.beta_c[ielem];
          phasecorr[ncorr] = lat.psi_c[ielem];
          icorr[ncorr] = ic;
          ncorr++;
        }
      }
      
      sts = sorbit_ls_svd_setup_measured(pl,  MAX_CORRECTORS, 
          MAX_CORRECTORS,
          threshold, (float *) bump_inv, use_cor, use_pos,
          &ncorr_check, &nbpm_check, NULL,  NULL,  NULL); 
      if((ncorr_check!=ncorr)||(nbpm_check!=nbpm)) {
        sprintf(messbuff,"ERR: %d %d ",ncorr_check,nbpm_check);
        error_message_c(messbuff);
      }
      

      
      sts = sorbit_ls_svd_compute(pl,ncorr,nbpm,1.,dx,dtheta,
         dx_calc);
      for(i = 0; i<ncorr ; i++) {
         dKickI[icorr[i]] = dtheta[i]
                        *(bramp->p[ibrk]/bramp->p[0]);
      }

 /* Now go through and calculate the worst offenders. Set them to
    the max and reiterate */
      scale = 1.;

      for(ic = 0; ic<MAX_CORRECTORS; ic++) {
        if(!(use_cor[ic])) continue;   
        dI = dKickI[ic] - lastI[ic];
        if((dI<=max_dI_hi[ic])&&(dI>=max_dI_lo[ic])) continue;
        if(dI>0.) tmp = max_dI_hi[ic]/dI;
        else tmp = max_dI_lo[ic]/dI;
        if(tmp < scale) scale = tmp;
        }
      
        
      if(scale < 1.) {          /* rescale if less than one */  
        for(ic = 0; ic<MAX_CORRECTORS; ic++) {
          if(!(use_cor[ic])) continue;
          dI = dKickI[ic] - lastI[ic];
          /* take care of special case where it is already at limit */
          if((dI>0.)&&(max_dI_hi[ic]==0.)) use_cor[ic] = FALSE;
          if((dI<0.)&&(max_dI_lo[ic]==0.)) use_cor[ic] = FALSE;
           
          dI *= scale;
          dKickI[ic] = lastI[ic] + dI;
          if((dI>0.)&&(dI>=.95*max_dI_hi[ic])) use_cor[ic] = FALSE;
          if((dI<0.)&&(dI<=.95*max_dI_lo[ic])) use_cor[ic] = FALSE;
          max_dI_hi[ic] -= dI;
          max_dI_lo[ic] -= dI;
        }
      } 

      for(ic = 0; ic<MAX_CORRECTORS; ic++ ) {
          kickI[ic] += dKickI[ic];
      }

/* Recalculate the orbit */
      for(i = 0; i<ncorr ; i++) {
        ic = icorr[i];
        dtheta[i] = dKickI[ic]*bramp->p[0]/bramp->p[ibrk];
      }
      sts = sorbit_ls_svd_predict(pl,ncorr,nbpm,dtheta,dx,
      	   dx_calc);

      memcpy(dx,dx_calc,nbpm*sizeof(float));
      
      rms_dev[ipass+1] = 0;
      for(i = 0; i<nbpm; i++ ) {
         rms_dev[ipass+1] += dx[i]*dx[i];
      }
      rms_dev[ipass+1] = sqrt(rms_dev[ipass+1]/nbpm);
      npass++;
       
      
      if(scale==1.) break;
      memset(lastI,0,sizeof(lastI));
    }
    /* Fill the corrector ramp array */
    for(ic=0;ic<MAX_CORRECTORS;ic++) 
      corrector_ramp[ic].Time_Value[ibrk][1] += kickI[ic];
    
     
    sprintf(messbuff,"%d %d: %f %f %f %f %f %f",ibrk,npass,
       rms_dev[0],rms_dev[1],rms_dev[2],rms_dev[3],rms_dev[4],
          rms_dev[npass]);
    error_message_c(messbuff);

     
 /* Now put back in the dtheta array */
    for(ic=0;ic<MAX_CORRECTORS;ic++) {
      ielem = 2*ic+ioffs;
      cor->dthet[ibrk][ielem] = kickI[ic];
    }
    cor->dthet_ave[ibrk] = calc_ave(RING_SIZE,cor->gstat,cor->dthet[ibrk]);
 }

 /** set the last breakpoint = first breakpoint for next ramp */
 ibrk = bramp->num_brkpts-1;
 for(ic=0;ic<MAX_CORRECTORS; ic++) {
   corrector_ramp[ic].Time_Value[ibrk][1] = 
   	      corrector_ramp[ic].Time_Value[0][1];
 }
 for(i=0;i<RING_SIZE;i++) {
    cor->dthet[ibrk][i] = cor->dthet[0][i];
 }

 if (sts) return(MYERR);
  /* dthet is angle change required, in mRAD */
 cor->flag[3] = TRUE;
 cor->flag[4] = cor->flag[5] = FALSE;
 return(0);

}
extern "C" int alg_lssol(int pl) {
  error_message_c("LSSOL algorithm not yet supported",0,RED,TRUE);
  return(0);
}
/****************************************************************/
/* non destructive bubble sort algorithm to rank bumps in order */
/* of absolute size                                             */
/****************************************************************/
extern "C" void rank_bumps(int n, float dx[], int idx[]) {
   int i,j;
   int itmp;
   int flipped;
   
   for(i = 0; i<n ; i++ ) idx[i] = i;
   
   for(i = n; i>0 ;i--) {
     flipped = 0;
     for(j=0; j<(i-1) ; j++) {
        if(fabs(dx[idx[j+1]]) > fabs(dx[idx[j]])) {
           itmp = idx[j+1];
           idx[j+1] = idx[j];
           idx[j] = itmp;
           flipped = 1;
        }
     }
     if(!flipped) return;
  }
}  

/******************************************************************************/
/*+ Read in the current values of the correctors
-*/
/******************************************************************************/
extern "C" int corr_read_ramps(void)
{

 int		i,pl,sts,ibrk,icorr,ioffs,on_state,init_to_dac;
 float          dc_val;

 
 ibrk = cor->curr_brkpt;
 pl = setp.plane;
 
 error_message_c("In corr_read_ramps");

 for(i=0;i<MAX_CORRECTORS;i++) {
   if(!corrsys->isok[pl][i]) continue;
   /* See if it's on */
   sts = dio_is_on_c(corrsys->maps[pl][i]->reference_di,&on_state);

   /* If on, then load the ramp */
   init_to_dac = FALSE;
   if(on_state) {
     error_message_c("About to read  ramp");
     sts = lib465_ft_ramp(LIB465_GET,corrsys->maps[pl][i],cor->ramp_num,rawdat,
            &corrector_ramp[i]);
     if(sts!=0) return(sts);
     sprintf(messbuff,"Ramp %d, %d %d %f,%f %f %f %f",
           i,corrector_ramp[i].Max_Slots,
            corrsys->maps[pl][i]->init_dac,
            lib465_dac_val(corrsys->maps[pl][i]),
            corrector_ramp[i].Time_Value[0][0],
            corrector_ramp[i].Time_Value[0][1],
            corrector_ramp[i].Time_Value[63][0],
            corrector_ramp[i].Time_Value[63][1]
           );
     error_message_c(messbuff);
     if(!check_ramp(&corrector_ramp[i]))  {
       sprintf(messbuff,"Warning: Corrector %d ramp corrupted.",
          corrsys->corrector_number[pl][i]);
       error_message(messbuff);
       init_to_dac = TRUE;
       }
   } else {
     init_to_dac = TRUE;
   }
   
   /* At this point, init_to_dac will be true if the card is OFF, or
      if the ramp does not have the correct time breaks */
   if(init_to_dac)  
     {
      sprintf(messbuff,"Initializing corrector %d to DAC setting",
           corrsys->corrector_number[pl][i]);
        error_message(messbuff);
        
        dc_val  =  lib465_dac_val(corrsys->maps[pl][i]); 
        init_ramp(&corrector_ramp[i],dc_val);
   }
 }
 /* Load the clock table from the first good one in the list */
 if(corrsys->num_correctors[pl]>0) {
   icorr = corrsys->corrector_number[pl][0]; /* first good corrector */
   sts=lib465_clock_table(LIB465_GET,corrsys->maps[pl][icorr],clock_table);
 }
 if(sts!=0) return(sts);

 ioffs = (pl==HORZ)? 1:0;
 /* Load into the old arrays */
 for(i=0;i<RING_SIZE;i++) {
   cor->g1.x.floats[i] = 0.;
   if ((i%2)!=ioffs) continue;
   icorr = i/2;  /* The corrector */
   if(!corrsys->isok[pl][icorr]) continue;
   cor->g1.x.floats[i] = corrector_ramp[icorr].Time_Value[ibrk][1];
 }
    
 
 cor->g1.hdr.tclk = 10;
 cor->g1.hdr.plane = cor->plane;
 cor->g1.hdr.slot = 0;
 cor->g1.hdr.date = clinks_now();
 cor->g1.hdr.fid = 0;
 cor->g1.hdr.lock = 0;
 sprintf(cor->g1.hdr.title,"read in curr.");

 if (!sts) cor->flag[2] = TRUE;
 cor->g1_ave[ibrk] = calc_ave(RING_SIZE,cor->gstat,cor->g1.x.floats);

 return(sts);

}
/***************************************************************************
* check_ramp - This checks if a ramp is consistent with the booster ramp
*              That is, it has the right number of points and the
*              time values are right.  If not, then it will return 0
***************************************************************************/
extern "C" int check_ramp(FT_Ramp *r) {
   int i;
   float eps = .01;
   if(r->Max_Slots != bramp->num_brkpts) return(0);
   for(i=0;i<r->Max_Slots;i++) {
      if(fabs(r->Time_Value[i][0]-bramp->t[i])>eps) return(0);
   }
   return(1);  /* If here, then it checks out */
}
/***************************************************************************
* init_ramp - initialize a ramp to a DC value
*
****************************************************************************/
extern "C" void init_ramp(FT_Ramp *r, float v) {
  int i;
  r->Max_Slots = bramp->num_brkpts;
  for(i=0;i<bramp->num_brkpts;i++ ){
     r->Time_Value[i][0] = bramp->t[i];  
     r->Time_Value[i][1] = v;
  }
  if(bramp->num_brkpts<MAX_SLOTS) r->Time_Value[bramp->num_brkpts][0] =
                                r->Time_Value[bramp->num_brkpts][1] = 0.;
}



/******************************************************************************/
/*+ int corr_bpm2()
	step 5: calculate predicted orbits.
-*/
/******************************************************************************/
extern "C" int corr_bpm2(void)
{
  int pl,ioffs,iper,ielem,ic; 
  int ibrk;
  float kickI[MAX_CORRECTORS];
  
  

 /* calculate the new orbit in terms of the corrections calculated */
 pl = cor->plane;

 /* If we have not calculated the correction yet, we must calculate them */
 if(!cor->flag[3]) {
    error_message_c("Calculating corrections...");
    corr_calc(pl);
 }
 
 
 if(pl==HORZ) {
   ioffs=1;
 } else {
   ioffs = 0;
 }
 
 for(ibrk = 0; ibrk < bramp->num_brkpts; ibrk ++) {
   memset(cor->dx2[ibrk],0,RING_SIZE*sizeof(float));
   for(ic=0; ic<MAX_CORRECTORS; ic++) {
     if(corrsys->isok[pl][ic]) {
       kickI[ic] = corrector_ramp[ic].Time_Value[ibrk][1] -
                   corrector_init_ramp[ic].Time_Value[ibrk][1];
     } else {
       kickI[ic] = 0.;
     }
   }
   for(iper=0;iper<RING_SIZE/2; iper++) {
     ielem = iper*2+ioffs;
     for(ic=0;ic<MAX_CORRECTORS;ic++) {
       cor->dx2[ibrk][ielem] += bump_inv[iper][ic]*kickI[ic]*
                                bramp->p[0]/bramp->p[ibrk];
     }
     
   }
   for(ielem=0; ielem<RING_SIZE; ielem++) {
     cor->b2[ibrk][ielem] = 
        cor->b1.xy[pl][bramp->ipnt[ibrk]][ielem]+cor->dx2[ibrk][ielem];
     if(subdes) { cor->b2[ibrk][ielem] -= 
          (deso.x.floats[ielem]+orbit_drift(pl,ibrk,ielem));
     }
   }   
   cor->b2_rms[ibrk] = calc_rms(RING_SIZE,stat1,cor->b2[ibrk]);
 }
 cor->flag[4] = TRUE;
 return(0);
}


/****************************************************************************
* int corr_send (send the ramps)
*****************************************************************************/
extern "C" int corr_send(void) {
  int pl,i,sts;
  float sf[MAX_RAMPS];
  short g_ordinate[MAX_SLOTS];  /* G table values */
  float g_abscissa[MAX_SLOTS];
  short f_map[MAX_INTERRUPTS],g_map[MAX_INTERRUPTS],h_map[MAX_INTERRUPTS];
  static int last_rampnum = -1;
  int full_init;
  int one = 1;

  
  Map_465 *map;

  /* set the default scale factors */  
  for(i=0;i<MAX_RAMPS;i++) sf[i] = (i<1)? 1.:0.;  
  
  /* set up the G table so it will always play slot 0 */
  g_ordinate[0] = 0;  /* max value */
  g_abscissa[0] = 0.;
  for(i=1;i<MAX_SLOTS;i++) {
     g_ordinate[i] = 0;
     g_abscissa[i] = 0.;
  }

  
  pl = cor->plane;
  sts = 0;
  error_message_c("About to send ramps");

  if(cor->ramp_num!= last_rampnum) {
     error_message_c(
     "This is the first call for this ramp, so extra initialization will be done.");
     full_init=TRUE;
  } else {
     full_init=FALSE;
  }
  
                           
  for(i=0;i<MAX_CORRECTORS;i++) {
     if(!(corrsys->isok[pl][i])) continue;
     map = corrsys->maps[pl][i];
     
     /* Do a full init here on first call for a ramp */
     
     if(full_init) {
        /* Load the mapping */
        if(lib465_default_maps(map)!=0) sts = -1;
        /* Set up the specific mapping for this ramp */
        if(lib465_map_table(LIB465_GET,map,f_map,g_map,h_map,NULL,NULL,NULL,
                                                  NULL,NULL,NULL) !=0) sts =
                                                     -1;
        f_map[cor->ramp_num-1] = cor->ramp_num;
        g_map[cor->ramp_num-1] = h_map[cor->ramp_num-1] = 0;
        if(lib465_map_table(LIB465_SET,map,f_map,g_map,h_map,NULL,NULL,NULL,
                                                NULL,NULL,NULL) !=0) sts = 
                                                    -1;
                                                    

        /* setup the G table */
        /* if(lib465_gi_hi_table(LIB465_SET,0,map,cor->ramp_num,MAX_INTERRUPTS,
           g_ordinate,g_abscissa) !=0) sts = -1; */
        
        /* setup the MDAT selection */
        if(lib465_mdat(LIB465_SET,map,&one,&one)!=0) sts = -1;
     

     
        /* Load the scale factors */
        if(lib465_sf_table(LIB465_SET,map,sf)!=0) sts = -1;
     }
     
     /* Load the ramp */
     if(lib465_ft_ramp(LIB465_SET,map,cor->ramp_num,
           rawdat,&corrector_ramp[i])!=0) sts = -1;

     /* Read the clock table and update the clocks for this ramp ONLY */
     if(lib465_clock_table(LIB465_GET,map,clock_table)!=0) sts = -1;
     memcpy(&clock_table[cor->ramp_num-1],cor->events,MAX_EVENTS*sizeof(short));
     if(lib465_clock_table(LIB465_SET,map,clock_table)!=0) sts = -1;
         
     /* Enable ramps */
     /* if(lib465_ramp_enable(&map,1,TRUE)!=0) sts = -1; */
  }
  /* Set the flag */
  cor->flag[5] = TRUE;
  /* Reset the earlier flags */
  cor->flag[1] = cor->flag[2] = FALSE;  /* These are no longer valid */
  last_rampnum = cor->ramp_num;
  return(sts);
}
  
  
/******************************************************************************/
/*+ int corr_send()
*/
/******************************************************************************/
extern "C" int corr6_send_old(void)
{

short	corr_status[NUM_CORRECTORS];
int	corr_indices[NUM_CORRECTORS];
char	*corptr;
short	pseudo_status[NUM_CORRECTORS];
int	pseudo_indices[NUM_CORRECTORS];
char 	*pseudoptr;
float	dat[NUM_CORRECTORS];
int	i;
int	sts;
float	scaled_diff_orbit[RING_SIZE];
static int set_list = DIO_INVALID_LIST_ID;
static int pseudo_list = DIO_INVALID_LIST_ID;


 for ( i = 0; i < NUM_CORRECTORS; i++ )
   {
     if ( cor->plane == HORZ )
       {
	 dat[i] = cor->g2[0][2 * i + 1];
	 // WLM Linux conversion note: orig vax code was
	 //	 dat[i] = (float)cor->g2[2 * i + 1];
       }
     else if ( cor->plane == VERT )
       {
	 dat[i] = cor->g2[0][2 * i];
	 // WLM Linux conversion note: orig vax code was
	 //	 dat[i] = (float)cor->g2[2 * i];
       }
     if ( dat[i] > 7.0 )
       {
	 dat[i] = 7.0;
	 error_display_c ( "Corrector greater than 7.0 A. Set to 7 A.",
			  ERR_NONE, 0 );
       }
     if ( dat[i] < -7.0 )
       {
	 dat[i] = -7;
	 error_display_c ( "Corrector less than -7.0 A. Set to -7 A.",
			  ERR_NONE, 0 );
       }
   }

 if ( cor->plane == 0 )corptr = h_correctors[0];
 else if ( cor->plane == 1 )corptr = v_correctors[0];

 sts = dio_device_index_c ( corptr, corr_indices, NUM_CORRECTORS,
			   corr_status );
 if ( sts != DIO_OK )
   {
     error_display_c ( "Error reading corrector indices", ERR_ACNET, sts );
     return sts;
   }

 sts = dio_bld_set_c ( &set_list, NUM_CORRECTORS, corr_indices, prop_set,
		      corr_status );
 if ( sts != DIO_OK )
   {
     error_display_c ( "Error building list", ERR_ACNET, sts );
     return sts;
   }

sts = dio_set_lst ( &set_list, dat, corr_status );
if ( sts != DIO_OK )
  {
    error_display_c ( "Error setting list", ERR_ACNET, sts );
    sts = dio_can_get_lst  ( &set_list );
    if ( sts != DIO_OK )
      error_display_c ( "dio_can_get_lst failed for setting",
	ERR_ACNET, sts );
    return sts;
  }
else if ( sts == DIO_OK )
  {
    set_list = DIO_INVALID_LIST_ID;
  }

sts = set_alarm_limits ( corr_indices, corr_status, dat );
if ( sts != 0 )return sts;

/* Do the pseudo devices. */
 if ( cor->plane == 0 )pseudoptr = h_diff_pos[0];
 else if ( cor->plane == 1 )pseudoptr = v_diff_pos[0];

 sts = dio_device_index_c ( pseudoptr, pseudo_indices, NUM_CORRECTORS,
			   pseudo_status );
 if ( sts != DIO_OK )
   {
     error_display_c ( "Error reading pseudo device indices",
	ERR_ACNET, sts );
     return sts;
   }

 sts = dio_bld_set_c ( &pseudo_list, NUM_CORRECTORS, pseudo_indices,
	prop_set, pseudo_status );
 if ( sts != DIO_OK )
   {
     error_display_c ( "Error building pseudo device list",
	ERR_ACNET, sts );
     return sts;
   }

 for ( i = 0 ; i < RING_SIZE; i++ )
   {
     if ( cor->plane == HORZ )
       scaled_diff_orbit[i] =  diff_orbit[2 * i + 1];
     else if ( cor->plane == VERT )
       scaled_diff_orbit[i] = diff_orbit[2 * i];
   }

 sts = dio_set_lst ( &pseudo_list, scaled_diff_orbit, pseudo_status );
 if ( sts != DIO_OK )
   {
     error_display_c ( "Error setting pseudo list", ERR_ACNET, sts );
     sts = dio_can_get_lst ( &pseudo_list );
     if ( sts != DIO_OK )
       error_display_c ( "dio_can_get_lst failed for pseudo devices",
			ERR_ACNET, sts );
     return sts;
   }
else if ( sts == DIO_OK )
  {
    pseudo_list = DIO_INVALID_LIST_ID;
  }

 return(sts);

}


/******************************************************************************/
/*+  Restore ramps to their original values
-*/ 
/******************************************************************************/
extern "C" int corr_restore(void)
{
 error_message_c("Restoring initial ramps");
 /* Load them into the ramp arrays */
 memcpy(corrector_ramp,corrector_init_ramp,MAX_CORRECTORS*sizeof(FT_Ramp));

 /* Send them to the cards */
 return(corr_send());

}


/******************************************************************************/
/*+ void pre_bpm(void)
-*/                     
/******************************************************************************/
extern "C" void pre_bpm(void)
{

 int		i,pl,ibrk;


 
 pl = cor->plane;
 
 /* loop over breakpoints and fill all arrays */
 for(ibrk=0;ibrk<bramp->num_brkpts;ibrk++) {
    for (i = 0; i < RING_SIZE; i++) {
       cor->dx1[ibrk][i] = -cor->b1.xy[pl][bramp->ipnt[ibrk]][i];
       cor->dx1[ibrk][i] += deso.x.floats[i];
       cor->dx1[ibrk][i] += orbit_drift(pl,ibrk,i); 
    } 

    /* pre condition, if any loc desired no correction,'skip' or held unchanged */

    for (i = 0; i < RING_SIZE; i++) {
        if (cor->skiploc[i]) cor->dx1[ibrk][i] = 0.0;
        if (cor->usebpm[i] == FALSE) cor->dx1[ibrk][i] = 0.0;
    }

    cor->b1_dpop[ibrk] = calc_dpop(RING_SIZE,
       cor->b1.xy[pl][bramp->ipnt[ibrk]],cor->bstat,lat.disp_b);

    /* pre condition, if apply momentum correction, +/- need to test */

    if (pl == HORZ && setp.if_p_corr) {
       for (i = 0; i < RING_SIZE; i++)
          cor->dx1[ibrk][i] -= cor->b1_dpop[ibrk] * lat.disp_b[i] * 1000.0;
    }

    cor->b1_rms[ibrk] = calc_rms(RING_SIZE,stat1,cor->dx1[ibrk]);
 }
 return;

}



/******************************************************************************/
/*+ int corr_plt(int step)
-*/                     
/******************************************************************************/
extern "C" void corr_plt(int step)
{

 int			i,j,gx,pl,ibrk;
 BPM_HDR_STRUCT		bhdr;
 char			stat[RING_SIZE];
 float			floats[RING_SIZE];


 gx = pltpar.gx;
 pl = cor->plane;
 ibrk = cor->curr_brkpt;
 if ((step == 0)&& cor->flag[0]) {
    memcpy(&bhdr,&cor->b1.hdr,sizeof(BPM_HDR_STRUCT));
    sprintf(bhdr.title,"desired orbit");
    memset(stat,FALSE,RING_SIZE);
    disp_bpm_1(gx,pl,&bhdr,deso.x.floats,stat1);
  }
 else if (step == 1 && cor->flag[step]) {
    memcpy(&bhdr,&cor->b1.hdr,sizeof(BPM_HDR_STRUCT));
    if ( dif_orbit == 0 )
      {
	sprintf(bhdr.title,"current orbit");
	disp_bpm_1(gx,pl,&bhdr,cor->b1.xy[pl][bramp->ipnt[ibrk]],stat1);
      }
    else if ( dif_orbit == 1 )
      {
	sprintf ( bhdr.title, "Difference Orbit" );
	for ( i = 0; i < RING_SIZE; i++ )floats[i] = deso.x.floats[i] +
	  orbit_drift(cor->plane,ibrk,i) -
	  cor->b1.xy[cor->plane][bramp->ipnt[ibrk]][i];
	disp_bpm_1 ( gx, pl, &bhdr, floats, stat1 );
      }
  }
 else if (step == 3 && cor->flag[step]){ 
   for ( i = 0; i < RING_SIZE; i+=2 )
     {
       j = (int)(i/2);
       if ( pl == HORZ )
	 {
	   floats[j] = cor->dthet[ibrk][i + 1];
	 }
       if ( pl == VERT )
	 {
	   floats[j] = cor->dthet[ibrk][i];
	 }
     }
    disp_corr ( gx,3, cor->plane, floats );
  }
  else if (step == 4 && cor->flag[step]) {
    memcpy(&bhdr,&cor->b1.hdr,sizeof(BPM_HDR_STRUCT));
    if ( subdes )sprintf ( bhdr.title, "Predicted Difference Orbit" );
    else sprintf ( bhdr.title, "Predicted Orbit" );
    disp_bpm_1(gx,pl,&bhdr,cor->b2[cor->curr_brkpt],stat1);
  }

}


/******************************************************************************/
/*+ int pre_cons(void)
-*/                     
/******************************************************************************/
extern "C" int pre_cons(void)
{

 int			i,pl,nced,nbpm,ibrk;

  /* make sure all constants are ready and for right plane. These calls don't
     need much time if data is already in place */

 pl = cor->plane;
 ibrk=  cor->curr_brkpt;

  /* read file lattice,skip and desired orbit if have not*/

 if (get_lattice(setp.lattice_data_src,pl,&lat)) return(MYERR);  
 if (setp.if_d_orbit == DES_DES_FILE)
   if (desob_r(setp.plane,deso.hdr.fid,&deso,&skip)) return(MYERR);

  /* determine if use or not. ced flags are same as they are in skip table.
     bpm need to look if data got is invalid */
 nced=nbpm=0;
 memset_longword_c(cor->useced,TRUE,RING_SIZE);
 memset_longword_c(cor->usebpm,TRUE,RING_SIZE);
 for (i = 0; i < RING_SIZE; i++) {
    if (cor->skipced[i]) cor->useced[i] = FALSE;
    if (cor->skipbpm[i]) cor->usebpm[i] = FALSE;  
    if (cor->b1.stat[pl][i] != BPM_OK) cor->usebpm[i] = FALSE; 
    if (cor->useced[i]) nced++;
    if (cor->usebpm[i]) nbpm++;
  }

 if (nced==0) {
    error_message_c("Num of correctors is 0",0,RED,TRUE);
    return(MYERR);
  }
 if (nbpm==0) {
    error_message_c("Num of bpm is 0, maybe invalid bpm data",0,RED,TRUE);
    return(MYERR);
  }

  /* bpm status 0 no problem, is concerned in correction procedures */
 memset(cor->bstat,FALSE,RING_SIZE);
 for (i = 0; i < RING_SIZE; i++) {
    if (!cor->usebpm[i]) cor->bstat[i] = TRUE;
    /*if (cor->skiploc[i]) cor->bstat[i] = TRUE; if skip loc, set correction 0*/
    if (cor->b1.stat[pl][i] != BPM_OK) cor->bstat[i] = TRUE; 
  }

  /* ced status 0 no problem, is concerned in correction procedures */
 memset(cor->gstat,FALSE,RING_SIZE);
 for (i = 0; i < RING_SIZE; i++) {
    if (!cor->useced[i]) cor->gstat[i] = TRUE;
  }

 memset_longword_c(&cor->flag[2],FALSE,8);
 memset_float_c(cor->dx1[ibrk],0,RING_SIZE);
 memset_float_c(cor->dx2[ibrk],0,RING_SIZE);
 memset_float_c(cor->dthet[ibrk],0,RING_SIZE);
 memset_float_c(cor->g2[ibrk],0,RING_SIZE);
 return(0);
}



/******************************************************************************/
/*+ void corr_disp_par(int wn,int r1,int c1);
-*/                     
/******************************************************************************/
extern "C" void corr_disp_par(int wn,int r1,int c1)
{

 static	 char	plnm[][5] = {"HORZ","VERT"};
 static	 char	nynam[][4] = {"NO ","YES"};
 static  char      algnam[][6] ={ "3BUMP" , " SVD ", "LSSOL"};
 char                   trig_string[TRIG_STRING_LEN];

 window_display_value_c(wn,r1,c1+21,
                        (void *)plnm[cor->plane],CNV_CHAR,4,GREEN);
 window_display_value_c(wn,r1+1,c1+21,(void *)nynam[setp.if_p_corr],
                        CNV_CHAR,3,GREEN);
 window_display_value_c(wn,r1+3,c1+21,(void *)&setp.stepcut,CNV_LONG,3,GREEN);
 cor->stepcut = setp.stepcut / 100.;
 window_display_value_c(wn,r1+5,c1+21,(void *)algnam[setp.alg_type],CNV_CHAR,5,GREEN);
 window_display_value_c(wn,r1+6,c1+20,(void *) &cor->curr_brkpt,CNV_LONG,2,GREEN);
 sprintf(messbuff,"(%3.1f)",bramp->t[cor->curr_brkpt]);
 window_blank_c(wi3,r1+6,c1+22,6);
 window_display_value_c(wi3,r1+6,c1+22,(void *) &messbuff,
      CNV_CHAR,strlen(messbuff),CYAN);
 window_display_value_c(wn,r1+7,c1+21,(void *) &cor->max_pass,CNV_LONG,2,GREEN);
 window_display_value_c(wn,r1+8,c1+21,(void *) &cor->ramp_num,CNV_LONG,2,GREEN);
 lib465_encode_trigger_string(cor->events,cor->nevents,trig_string);
 window_display_value_c(wn,r1+9,c1+6,(void *) trig_string,CNV_CHAR,20,GREEN);
 window_display_value_c(wn,r1+10,c1+strlen(cdtxt[10]), 
   (void *) orbit_drift_txt[cor->orbit_drift_mode], CNV_CHAR,
     strlen(orbit_drift_txt[cor->orbit_drift_mode]), GREEN);
 window_display_value_c(wn,r1+11,c1+strlen(cdtxt[11]),
     (void *) &cor->trim_headroom, CNV_FLOAT, 5, GREEN);
 window_blank_c(wi3,r1+12,c1+strlen(cdtxt[12]),12);
 window_display_value_c(wn,r1+12,c1+strlen(cdtxt[12]), 
   (void *) ramp_state_txt[ramp_state], CNV_CHAR,
     strlen(ramp_state_txt[ramp_state]), GREEN);
   
}



/******************************************************************************/
/*+ void corr_init_plane_data
-*/                     
/******************************************************************************/
extern "C" void corr_init_plane_data(void)
{

 lat.plane = INVALID;
 gdis[RING_SIZE] = INVALID;
 clim.hdr.plane = INVALID;
 deso.hdr.plane = INVALID;
 skip.hdr.plane = INVALID;
 cor->sfactors[RING_SIZE]=INVALID;
 cor->plane = setp.plane;
 cor->plane_svd_setup_flag[HORZ] = cor->plane_svd_setup_flag[VERT] = INVALID;
  

}
/**********************************************************************/
/* Initialize the ramps                                               */
/**********************************************************************/
extern "C" int corr_init_ramps(int mode)  {
  int i,j,sts;
  float value;
  
/* If mode = INIT_MODE CURRENT, then initialize to current ramp setting,
   UNLESS the cards are off, in which case it will initialize to 
   DC dac values */
   
  if(mode==INIT_MODE_CURRENT) {
     error_message_c("about to read in ramp cards");
     sts = corr_read_ramps();            /* g1_ave in uRAD */
  } else {
    if(mode==INIT_MODE_DAC) {
        error_message_c("Initializing corrector ramps to DAC value");
    } else {
        error_message_c("Initializing corrector ramps to zero");
    }
    for(i = 0; i<MAX_CORRECTORS; i++ ) {
       if((mode==INIT_MODE_DAC)&&(corrsys->isok[cor->plane][i])) {

         value = lib465_dac_val(corrsys->maps[cor->plane][i]);
       } else {
         value = 0.;
       }
     
       for(j = 0; j<bramp->num_brkpts; j++) {	
           corrector_ramp[i].Time_Value[j][0] = bramp->t[j];
           corrector_ramp[i].Time_Value[j][1] = value; 
       }   
     }
   }
  error_message_c("Copying ramps to init array");
  memcpy(&corrector_init_ramp,&corrector_ramp,sizeof(corrector_ramp));

  return(0);
}
/********************************************************************/
/* Disable all ramps                                                */
/********************************************************************/
extern "C" int corr_disable_ramps(void) {
  error_message_c("Disabling all ramps");
  return(
    lib465_ramp_enable(&corrsys->maps[cor->plane][0],MAX_CORRECTORS,FALSE));
}
/**********************************************************************/
/* Get the limits for this time slice. This sets hi and low limits    */
/* based on hard values and slewing limits. Note that these limits    */
/* will be applied to the differential current, so we must subtract   */
/* off the existing value                                             */
/**********************************************************************/
extern "C" void get_corrector_limits(int pl,int ibrk, float lastI[], float loMax[], 
   float hiMax[] ) {
   float dt,dI;
   int i;
   float hard_limit;
   
   for(i=0;i<MAX_CORRECTORS;i++) {
      /* Set absolute limit, but leave some room for trimming offset */
      hard_limit = corrsys->current_limit[pl][i] - cor->trim_headroom;
      if(hard_limit<0.) hard_limit = 0.;
      if(!corrsys->isok[pl][i]) {
        hiMax[i]=loMax[i]=lastI[i] = 0.;
        continue;
      } else if (ibrk==0) {
        hiMax[i] = hard_limit;
        loMax[i] = -hiMax[i];
        hiMax[i] -= corrector_ramp[i].Time_Value[ibrk][1];
        loMax[i] -= corrector_ramp[i].Time_Value[ibrk][1];
        lastI[i] = 0.;
      } else {
        lastI[i] = corrector_ramp[i].Time_Value[ibrk-1][1];
        dt = bramp->t[ibrk] - bramp->t[ibrk-1];  /* slewing limits */
        dt *= .001;  /* time is in ms */
        dI = corrsys->dIdt_limit[pl][i]*dt;
        hiMax[i] = dI;
        if((lastI[i]+hiMax[i]) > hard_limit)
             hiMax[i] = hard_limit - lastI[i];
             
        loMax[i] = -dI;
        if((lastI[i]+loMax[i]) < -hard_limit)
             loMax[i] = (-hard_limit) - lastI[i];
             
      }
      /* correct for the present setting */
      lastI[i] -= corrector_ramp[i].Time_Value[ibrk][1];
      
    }     
}       
        




/******************************************************************************/
/*+ int set_alarm_limits
  resets the alarm limits after sending new values to the correction dipoles */
/******************************************************************************/
extern "C" int set_alarm_limits ( int* indices, short* in_status,
	float* new_currents )
{

int	i;
int	j = 0;
int	sts;
short	type_alarm = DIO_ANALOG;
short	errors[NUM_CORRECTORS];
float	min[NUM_CORRECTORS];
float	max[NUM_CORRECTORS];
int     index[NUM_CORRECTORS];


/* KDE */
static int list_id = DIO_INVALID_LIST_ID;
if (list_id != DIO_INVALID_LIST_ID)
  {
    error_display_c ( "dio_can_alarm_lst failed", ERR_ACNET, 
		     dio_cancel_alarm_lst(&list_id));
    list_id = DIO_INVALID_LIST_ID;
  }
/* end KDE */

for ( i = 0; i < NUM_CORRECTORS; i++ )
  {
    if ( in_status[i] == DIO_OK )
      {
	index[j] = indices[i];
	min[j] = new_currents[i] - 0.5;
	max[j] = new_currents[i] + 0.5;
	j++;
      }
  }

sts = dio_bld_alrm_lst ( &list_id, &j, index, &type_alarm,
	errors );
if ( sts != DIO_OK )
  {
    error_display_c ( "dio_bld_alrm_lst failed", ERR_ACNET, sts );
    return sts;
  }

sts = dio_salarm_lim_lst ( &list_id, min, max, errors );
if ( sts != DIO_OK )
  {
    error_display_c ( "dio_salarm_lim_lst failed", ERR_ACNET, sts );
    sts = dio_cancel_alarm_lst ( &list_id );
    if ( sts != DIO_OK )
      error_display_c ( "dio_can_alarm_lst failed", ERR_ACNET, sts );
    return sts;
  }

return 0;

}



/******************************************************************************/
/*+ void update_params
	updates B:NOTCH */
/*****************************************************************************/
extern "C" void	update_params ( int wi3, int r1, int c1 )
{

int	sts;
int	on_status;


notch_state_row = r1;
notch_state_col = c1+10;
sts = dio_device_index_c ( "B:NOTCH", &notch_index );
if ( sts != DIO_OK )
  error_display_c ( "Error getting B:NOTCH index", ERR_ACNET, sts );
sts = dio_is_on_c ( notch_index, &on_status );
if ( sts != DIO_OK )
  error_display_c ( "Error reading B:NOTCH status", ERR_ACNET, sts );
else if ( sts == DIO_OK )
  {
    if ( on_status == TRUE )
      window_tvm_c ( wi3, r1, c1 + 10, "ON ", 3, bf[1] );
    else if ( on_status == FALSE )
      window_tvm_c ( wi3, r1, c1 + 10, "OFF", 3, bf[1] );
  }
return;

}



/******************************************************************************/
/*+ void notch_callback_function
	service interrupts for controlling notch*/
/*****************************************************************************/

static void	notch_callback_function ( short window_id, void *callback_data,
	WINDOW_FIELD_INTERRUPT_DATA *interrupt_data )

{

   int	 on_status;
   int	 sts;


   sts = dio_is_on_c ( notch_index, &on_status );
   if ( sts != DIO_OK )
     {
     error_display_c ( "Error reading B:NOTCH status", ERR_ACNET, sts );
     return;
     }
   set_notch(!on_status);  /* toggle notch state */
}

/******************************************************************
  set and display notch state (dummied out)
 ******************************************************************/
extern "C" int set_notch(int state) {   
   int sts;
   static char *offon[2] = {"OFF","ON "};
   return(DIO_OK);
   
   if(state) sts = dio_on(&notch_index);
   else sts = dio_off(&notch_index);

   if ( sts != DIO_OK ) {
      error_display_c ( " Error setting B:NOTCH",
           ERR_ACNET, sts );
	   return(sts);
      }
   window_tvm_c ( wi3, notch_state_row,
	   notch_state_col, offon[state], 3, bf[1] );
      
   return(DIO_OK);
}



/*******************************************************************
  Check to see if the notch is in a particular state
  and change it if it is not.  Will be used primarily for 
  turning notch off prior to reading BPM's
*******************************************************************/
extern "C" int verify_notch(int state,int *old_state) {
  int sts,current_state;
  
  sts = dio_is_on_c(notch_index,&current_state);
  if(old_state!=NULL) *old_state = current_state;
  
  if ( sts != DIO_OK )
  {
    error_display_c ( "Error reading B:NOTCH status", ERR_ACNET, sts );
    return(sts);
  }
  if(current_state!=state) return(set_notch(state));  /* Turn off, if nec. */
  return(DIO_OK);
}
  

/* Fill the matrices corresponding to the bumps and the inverse */
extern "C" void fill_bump_matrices(int pl) {
  int i,j,k,sts;
  float *ratios;
  float amps_per_mm;
  float test_mat[24][24];

  memset((void *) bump_matrix,0,sizeof(bump_matrix));
  memset((void *) bump_inv,0,sizeof(bump_inv));  

  /* Build up an array for the bumps */
  for(i=0;i<24;i++) {
    if(pl==HORZ) {
       ratios = h_ratios[i];
       amps_per_mm = h_amps_to_mm[i];
    } else {
       ratios = v_ratios[i];
       amps_per_mm = v_amps_to_mm[i];
    }
      
    for(j=0;j<3;j++) {
      bump_matrix[cindx(i+j-1,24)][i] += amps_per_mm*ratios[j];
    }
  }  

  sts = invert_bumps(bump_matrix,bump_inv);
  if(sts!=0) {
    error_display_c("Error: bump matrix singular",0,0);
    return;
  }

  /* Test */
  for(i=0;i<24;i++) {
     for(j=0;j<24;j++) {
        test_mat[i][j] = 0.;
        for(k = 0; k<24 ; k++ ) {
           test_mat[i][j] += bump_matrix[i][k]*bump_inv[k][j];
        }
     }
   } 
   
return;
}             

 
 

/*******************************************************************
  Invert a matrix.  

  11/5/01 E.Prebys  Pulled off the web and coverted to C
 *******************************************************************/

extern "C" int invert_bumps(float A[24][24], float Ainv[24][24]) {

  int n=24;
  float D[24][48];
  float alpha, beta;
  int i,j,k,n2;


  /*  initialize the reduction matrix */
  n2 = 2*n;
  for(i = 0; i<n ; i++) {
    for( j = 0; j<n; j++) { 
      D[i][j] = A[i][j];
      D[i][n+j] = (j==i)? 1.:0.;
    }
  }

  /*  do the reduction */ 
  for(i = 0; i<n ; i++ ) {
    alpha = D[i][i];
    if(alpha == 0.) return(-1);
    for (j=0;j<n2;j++) {
      D[i][j] /= alpha; 
    }
    for(k = 0; k<n; k++) {
      if(k==i) continue;
      beta = D[k][i];
      for(j=0;j<n2;j++) {
	D[k][j] -= beta*D[i][j];
      }
    }
  }

  /*  copy result into output matrix */
  for(i=0;i<n;i++) {
    for(j=0;j<n;j++) {
      Ainv[i][j] = D[i][j+n];
    }
  }
  return(0);
}
/*********************************************************************/
/*  int get_drift_pars() - get the parameters needed to calculate    */
/*  the time dependent orbit drift.                                  */
/*********************************************************************/
extern "C" int get_drift_pars(void) {
   int retstat = 0;
   int sts;
   sts = get_drift_ramps();
   if(sts != 0) {
      retstat = sts;
   }
   sts=get_dogpars();
   if(sts != 0) {
      retstat = sts;
   }
   return(retstat);
}
   
/*********************************************************************/
/* get_drift_ramps - Read in the bex bumps and ROF curves            */
/*********************************************************************/
extern "C" int get_drift_ramps(void) {
  int sts,i,di;
  Map_465 map;

//  bex_ramp, bex_name  does not seem to be used anymore---b:bex13z is obsolete
//              W Marsh  1-Sep-2006
//
//  error_message_c("Reading in information from BEXBUMP ramps.");
//  for(i=0; i<NBEX; i++ ) {
//      sts = dio_device_index_c(bex_name[i],&di);
//      if(sts != DIO_OK) {
//         sprintf(messbuff,"Error getting device index for %s",bex_name[i]);
//	 error_display_c(messbuff,ERR_ACNET,sts);
//         return(sts);
//      }
//      sts = lib465_get_map(di,&map);
//      if(sts != DIO_OK) {
//         sprintf(messbuff,"Error getting map for %s",bex_name[i]);
//	 error_display_c(messbuff,ERR_ACNET,sts);
//         return(sts);
//      }
//      sts = lib465_ft_ramp(LIB465_GET,&map,1,rawdat,&bex_ramp[i]);
//      if(sts != DIO_OK) {
//         sprintf(messbuff,"Error reading ramp for %s",bex_name[i]);
//	 error_display_c(messbuff,ERR_ACNET,sts);
//         return(sts);
//      }
//   }      
  error_message_c("Reading in information from ROF ramps.");
  for(i=0; i<NROF; i++ ) {
      sts = dio_device_index_c(rof_name[i],&di);
      if(sts != DIO_OK) {
         sprintf(messbuff,"Error getting device index for %s",rof_name[i]);
	 error_display_c(messbuff,ERR_ACNET,sts);
         return(sts);
      }
      sts = lib465_get_map(di,&map);
      if(sts != DIO_OK) {
         sprintf(messbuff,"Error getting map for %s",rof_name[i]);
	 error_display_c(messbuff,ERR_ACNET,sts);
         return(sts);
      }
      sts = lib465_ft_ramp(LIB465_GET,&map,1,rawdat,&rof_ramp[i]);
      if(sts != DIO_OK) {
         sprintf(messbuff,"Error reading ramp for %s",rof_name[i]);
	 error_display_c(messbuff,ERR_ACNET,sts);
         return(sts);
      }
   }      
   return(0);
}      

/****************************************************************/
/* orbit_drift(int pl, int ibrk, int elem) - This is the time dependent*/
/*          orbit correction in each plane.  Currently contains */
/*          BEX bump correctors and ROF curve                   */
/****************************************************************/
extern "C" float orbit_drift(int pl, int ibrk, int ielem) {
  int iper,i;
  float A,dx;
  float t_use;

  /* See of we ignore (supress) drift */
  if(cor->orbit_drift_mode == ORBIT_DRIFT_SUPRESS) return(0.);
  
  if(pl==HORZ) {
    if((ielem%2)!=1) return(0.);  /* only worry about HS */
    iper = 1+(ielem/2); 

    for(i=0;i<NCOLL_PERIOD;i++) {
      if(iper==coll_period[i]) return(0.);  /* suppress drift at collimator */
    }
    i = 0;  /* only look at the first ROF curve */
         
    t_use = bramp->t[ibrk]; 
    if(t_use>32.) t_use = 32.;  /* gets weird at the end */
    A = ramp_value(&rof_ramp[i],t_use);  /* interpolate ramp to 
                                                        time t*/
    A -= ramp_value(&rof_ramp[i],bramp->t[0]);  /* diff position relative
                                                         to start of ramp */
    A *= -1.;  /* sign convention difference */
    dx = A*rof_scale[i]; /* position */
    return(dx); 
         
      
    
 
  } else {
    if((ielem%2)!=0) return(0.);  /* only worry about VL */
    iper = 1+(ielem/2); 

    for(i=0;i<NBEX;i++) {
      /* This is really kludgy.  BEX seems to effect VL2, VL3, VL12, and VL13 */
          // VL12,VL13 eliminated6-sep-2006 because dog13 eliminated---wlm 
      if(iper == bex_period[i]) {
         if(cor->orbit_drift_mode == ORBIT_DRIFT_LOCK) {
           dx = cor->b1.xy[pl][bramp->ipnt[ibrk]][ielem]-
                cor->b1.xy[pl][bramp->ipnt[0]][ielem];
           return(dx);
         }
         /* Correct orbit based on predicted behavior of the
            dogleg */
            
         return(dog_drift(&dogpar[bex_dog[i]],ibrk));         
         /* Old way.  No longer used */
         /* t_use = bramp->t[ibrk]; */
         /* if(t_use>32.) t_use = 32.; */ /* gets weird at the end */
         /* A = ramp_value(&bex_ramp[i],t_use); */ /* interpolate ramp to 
                                                          time t*/
         /* A -= ramp_value(&bex_ramp[i],bramp->t[0]); */ /* diff current relative
                                                         to start of ramp */
         /* dx = A*bex_scale[i]*bramp->p[0]/bramp->p[ibrk]; */ /* position */
        return(dx);
      }
    }
  }
  return(0.);
}
/****************************************************************/
/* ramp_value - interpolated ramp value                         */
/****************************************************************/
extern "C" float ramp_value(FT_Ramp *r, float t) {  
  int i,n;
  float f;
  
  /* Return extrema if out of bounds */
  if(t<=r->Time_Value[0][0]) return(r->Time_Value[0][1]);
  n = r->Max_Slots;
  if(t>=r->Time_Value[n-1][0]) return(r->Time_Value[n-1][1]);
  
  /* find interval and interpolate */
  for(i=0;i<(n-1);i++) {
    if(t>r->Time_Value[i+1][0]) continue;
    f = (t-r->Time_Value[i][0])/(r->Time_Value[i+1][0]-r->Time_Value[i][0]);
    return(r->Time_Value[i][1] +
                       f*(r->Time_Value[i+1][1]-r->Time_Value[i][1]));
  }
  return(r->Time_Value[0][1]); 
}               
/*****************************************************************/
/* float dog_drift(dogpar_t *d,int ibrk)                         */
/* This will calculate the needed steering to keep the beam      */
/* just below the extraction septum in terms of the displacement */
/* just outside the doglegs                                      */
/*****************************************************************/
extern "C" float dog_drift(dogpar_t *d, int ibrk) {
   float p0,p,betagamma0,betagamma,rmin,rmin0,
      ydog0,ydog;
   float m = .935;  /* mass of proton (GeV) */ 

   /* calculate some basic kinematics */
   p0 = bramp->p[0];
   p = bramp->p[ibrk];
   betagamma0 = p0/m;  /* beta*gamma, used to calculate emmitance */
   betagamma = p/m;
   
   /* calculate the minimum radius of the beam, based on
      maintaining a certain acceptance */
   rmin0 = sqrt(d->acceptance*d->beta/betagamma0);
   rmin = sqrt(d->acceptance*d->beta/betagamma);

   ydog0 = (d->amps2mm)*(d->current);  /* the amount that the dogs push the
                                      beam down at injection */
   ydog = ydog0*p0/p;              /* amount that they are pushing the
                                      beam down now */
                                      
   
   /* There are two competing effects here.  The shrinking beam
      radius will allow the beam to go higher, but the dog it
      less effective at pushing the beam down */
      
   return((rmin0-rmin)-(ydog0-ydog)); 
}
/****************************************************************/
/* int get_dogpars() Get the parameters associated with the    */
/* doglegs                                                      */
/****************************************************************/
extern "C" int get_dogpars(void) {
    int i,di, sts,retstat;
    /* Dogleg scale parameters (2.1 inches @893 Amps) */
    dogpar[0].amps2mm = dogpar[1].amps2mm = 2.103*25.4/893.0;
    dogpar[0].acceptance = dogpar[1].acceptance = 40.; /* Acceptance in
                                                         pi-mm-mrad */
    dogpar[0].beta = dogpar[1].beta = 20.4; /* Need to double check this */
    error_message_c("Reading the dogleg currents");
    retstat = 0;
    for(i=0;i<NDOG;i++) {
        sts = dio_device_index_c(dog_name[i],&di);
        if(sts != DIO_OK) {
          error_display_c("Error getting dogleg index",ERR_ACNET,sts);
          retstat = sts;

        } else {
           sts = dio_get_dev_c(di,PRREAD,&dogpar[i].current);
           if(sts != DIO_OK ) {
           error_display_c("Error reading dogleg setting",ERR_ACNET,sts);
           retstat = sts;
           }
        }
    }
    return(retstat);
}
/************************************************************************/
/* corr_save_ramps() - Save the ramps for this plane to a data record   */
/************************************************************************/
extern "C" int corr_save_ramps(void) {
   int pl;
   FTABLE_DB_HDR_STRUCT hdr;
   int sts;     

   pl = cor->plane;
   sts = ftable_hdr_sel(pl,TRUE,&hdr);
   if(sts != DIO_OK) return(util_errpost(sts,"Err: corr save ramps",NULL));
   
   ftable_rec_del(&hdr);  /* Delete any records with that handle */
   /* Update the title and date */
   inptxt_c(WMNGR_CENTER,WMNGR_CENTER,"title",0,hdr.title,-TIT_LEN);
   hdr.date = clinks_now();
   
   return(ftable_write(&hdr,MAX_CORRECTORS,corrector_ramp,corrsys->maps[pl]));
}
/***********************************************************************/
/* corr_load_ramps() - Load and send stored ramps                      */
/***********************************************************************/
extern "C" int corr_load_ramps(void) {
  int pl;
  FTABLE_DB_HDR_STRUCT hdr;
  int sts,nread;
  
  pl = cor->plane;
  sts = ftable_hdr_sel(pl,FALSE,&hdr);
  if(sts!=DIO_OK) return(util_errpost(sts,"Err: corr read ramps dir",NULL));
  
  sts =
       ftable_read(&hdr,MAX_CORRECTORS,&nread,
       corrector_ramp,corrsys->maps[pl]);
       
  if(sts!=DIO_OK) return(util_errpost(sts,"Err: corr read ramps",NULL));
  
  return(corr_send());
}     
/**********************************************************************/
/* corr_getevents() - get the current clock events for this plane and */
/* ramp                                                               */
/**********************************************************************/
extern "C" int corr_getevents(void) {
  int pl,icorr;
  Map_465 *map;
  
  pl = cor->plane;
  icorr = corrsys->reference_corrector[pl];
  map = corrsys->maps[pl][icorr]; /* Read clock table from first legit */
  
  if(map==NULL) return(MYERR);
  if(lib465_clock_table(LIB465_GET,map,clock_table)!=0) return(MYERR);
  
  memcpy(cor->events,&clock_table[cor->ramp_num-1],MAX_EVENTS*sizeof(short));
  cor->nevents = MAX_EVENTS;  /* set to max.  Decoder will ignore $FE's */
  return(0);
}
 
/*******************************************************************/
/* corr_setevents() - set the clock events for this plane and ramp */
/*******************************************************************/
extern "C" int corr_setevents(void) {
  int pl,icorr,sts;
  Map_465 *map;
  
  pl = cor->plane;
  icorr = corrsys->reference_corrector[pl];
  map = corrsys->maps[pl][icorr];
  
  /* Get the existing clock table from the reference card */
  if(map==NULL) return(MYERR);
  if((sts=lib465_clock_table(LIB465_GET,map,clock_table))!=0)  {
    error_display_c("Error reading clock table from reference corrector",
       ERR_ACNET,sts);
    return(sts);
  }
  
  /* Update the clock table for this ramp and load it to all other cards */
  memcpy(&clock_table[cor->ramp_num-1],cor->events,MAX_EVENTS*sizeof(short));
  
  sprintf(messbuff,"Sending clock table for ramp %d",cor->ramp_num);
  error_message_c(messbuff);
  
  for(icorr=0;icorr<MAX_CORRECTORS;icorr++) {
     map = corrsys->maps[pl][icorr];
     if(map==NULL) continue;
     if((sts=lib465_clock_table(LIB465_SET,map,clock_table))!=0)  {
       error_display_c("Error setting clock table",ERR_ACNET,sts);
       return(sts);
     }
  }   
  return(0);
}
/*********************************************************************/
/* select_breakpoint - select a particular breakpoint to view        */
/*********************************************************************/
extern "C" int select_breakpoint(int *ibrk) {
  int i;
  static char breaklist[MAX_BREAKPOINTS][14];
    
  for(i=0;i<bramp->num_brkpts;i++) {
     sprintf(breaklist[i],"%2d (%.1f ms)",i,bramp->t[i]);
  }
    
  my_wmenu_c(0,0,bramp->num_brkpts,14,(char *)breaklist,"",ibrk);
  return(0);
}
