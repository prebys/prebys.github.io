#ifndef SORBITSVD

#define SORBITSVD
/*
	definitions
*/
#define SORBITSVD_HORZ	0	/* horizontal plane */
#define SORBITSVD_VERT	1	/* vertical plane */
/*
	generic errors
*/
#define SORBITSVD_ERROR_UNDETERMINED	1	/* fewer equations then
							unknowns --- will
						        zero fill to get
							a solution -- there
							will be singularities */
#define SORBITSVD_ERROR_SINGULARITY	2	/* there are singularities
							or almost singularities
							in the solution */
/*
	sorbitsvd (smooth orbit least squares routines via svd)
*/
extern "C" int sorbit_ls_svd_setup(int plane, int ncorrectors, int npositions,
  float singularity_threshold, float *betacorrectors, float *betapositions,
  float *phasecorrectors, float *phasepositions, float tune,
  int *genericerror, int *numsingular, int *singularindex);
extern "C" int sorbit_ls_svd_setup_measured(int plane, int maxcorrectors, int maxpositions,
  float singularity_threshold, float *ameasured, int *usecor, int *usepos,
  int *ncorr, int *npos, int *genericerror, int *numsingular, int *singularindex);
extern "C" int sorbit_ls_svd_compute(int plane, int ncorrectors, int npositions,
  float stepcut, float *positions, float *deltacorrectors,
  float *predictedpositions);
extern "C" int sorbit_ls_svd_predict(int plane, int ncorrectors, int npositions,
  float *deltacorrectors, float *originalpositions, float *predictedpositions);
extern "C" void sorbit_ls_svd_release(int plane);
#endif
